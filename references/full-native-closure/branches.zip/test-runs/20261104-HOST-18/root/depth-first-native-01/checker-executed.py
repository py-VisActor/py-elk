import hashlib,json,sys
from pathlib import Path
source,request,original,output,probe=map(Path,sys.argv[1:6]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reference=json.loads(original.read_bytes());assert reference['workerSha256']=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86'
assert reference['requestSha256']==sha(request)and reference['probeSha256']==sha(probe)
assert reference['actualDepthFirstExecuted']and reference['observerReverseDelegatesOriginal']
sys.path.insert(0,str(source.resolve()));sys.path.insert(0,str(Path('scripts').resolve()))
from pyelk.algorithms.layered import cycles_general as algorithm
from pyelk.algorithms.layered.graph import LGraph,LNode,LPort,LEdge,Vec2,set_port_owner,set_source,set_target
from pyelk.algorithms.layered.native_import import LLabel
from pyelk.algorithms.layered.native_properties import CanonicalPropertyMap
from pyelk.algorithms.layered.ports import set_side
from pyelk.algorithms.layered.property_access import read_layered_scalar
from pyelk.execution.diagnostics import BasicProgressMonitor
from layout_checks import diff
def hashes():return{p.relative_to(source).as_posix():sha(p)for p in source.rglob('*')if p.is_file()and '__pycache__'not in p.parts}
before=hashes();data=json.loads(request.read_bytes());g=LGraph(None,None,None,properties=CanonicalPropertyMap())
nodes={};names={};ports={};edges=[];old_chains=[];old_points=[];xy=lambda v:[v.x,v.y]
for item in data['nodes']:
 node=LNode(g,properties=CanonicalPropertyMap());node.size=Vec2(item['width'],item['height']);g.layerless_nodes.append(node);nodes[item['name']]=node;names[id(node)]=item['name']
 for kind in('in','out'):
  p=LPort(properties=CanonicalPropertyMap());set_port_owner(p,node);set_side(p,'WEST'if kind=='in'else'EAST');p.pos.x=2 if kind=='in'else item['width']-2;p.pos.y=3;ports[item['name']+':'+kind]=p
 if item.get('inputCollect'):ports[item['name']+':in'].properties['INPUT_COLLECT']=True
 if item.get('outputCollect'):ports[item['name']+':out'].properties['OUTPUT_COLLECT']=True
 for kind in('Input','Output'):
  if item.get('reuse'+kind):
   p=LPort(properties=CanonicalPropertyMap());set_port_owner(p,node);set_side(p,'NORTH');p.pos.x=999;p.pos.y=-33;p.properties['INPUT_COLLECT'if kind=='Input'else'OUTPUT_COLLECT']=True
for index,item in enumerate(data['edges']):
 e=LEdge(id=index,properties=CanonicalPropertyMap());set_source(e,ports[item['source']+':out']);set_target(e,ports[item['target']+':in'])
 e.bend_points.extend(Vec2(*v)for v in item.get('bends',[]))
 for placement in item.get('labels',[]):
  label=LLabel(properties=CanonicalPropertyMap())
  if placement is not None:label.properties['EDGE_LABELS_PLACEMENT']=placement
  e.labels.append(label)
 edges.append(e);old_chains.append(e.bend_points);old_points.append(list(e.bend_points))
owner=algorithm.DepthFirstCycleBreaker();monitor=BasicProgressMonitor(False,False);order=[];reverse=algorithm.reverse_edge
def observing_reverse(edge,adapt_ports=True):order.append(edge.id);return reverse(edge,adapt_ports)
algorithm.reverse_edge=observing_reverse
try:owner.process(g,monitor)
finally:algorithm.reverse_edge=reverse
endpoint=lambda p:[names[id(p.owner)],next(i for i,v in enumerate(p.owner.ports)if v is p)]
def monitor_info(m):return{'name':m.task_name,'running':m.is_running(),'closed':m._closed}
def cleared():return all(getattr(owner,k)is None for k in('sources','visited','active','edges_to_be_reversed'))
cfg=owner.get_layout_processor_configuration(g)
actual={'reversedOrder':order,'cyclicHas':'CYCLIC'in g.properties,'cyclic':algorithm._boolean(g,'CYCLIC'),
 'nodes':[{'name':name,'id':node.id,'size':xy(node.size),'ports':[{'side':p.side,'position':xy(p.pos),'anchor':xy(p.anchor),
 'inputHas':'INPUT_COLLECT'in p.properties,'input':algorithm._boolean(p,'INPUT_COLLECT'),
 'outputHas':'OUTPUT_COLLECT'in p.properties,'output':algorithm._boolean(p,'OUTPUT_COLLECT'),
 'incoming':[e.id for e in p.incoming_edges],'outgoing':[e.id for e in p.outgoing_edges]}for p in node.ports]}for name,node in nodes.items()],
 'edges':[{'id':i,'source':endpoint(e.source),'target':endpoint(e.target),'reversedHas':'REVERSED'in e.properties,
 'reversed':algorithm._boolean(e,'REVERSED'),'bends':list(map(xy,e.bend_points)),
 'sameBendChain':e.bend_points is old_chains[i],'oldPointsUnchanged':list(map(xy,old_points[i])),
 'newPointOldIndices':[next((j for j,old in enumerate(old_points[i])if old is p),-1)for p in e.bend_points],
 'labels':[{'placement':read_layered_scalar(l,'EDGE_LABELS_PLACEMENT','EDGE_LABELS_PLACEMENT'),'has':'EDGE_LABELS_PLACEMENT'in l.properties}for l in e.labels]}for i,e in enumerate(edges)],
 'ownerCleared':cleared(),'monitor':monitor_info(monitor),'configurationByOrdinal':[[p.name for p in sorted(slot,key=lambda p:p.ordinal)]for slot in cfg.list]}
empty=LGraph(None,None,None,properties=CanonicalPropertyMap());empty_monitor=BasicProgressMonitor(False,False);owner.process(empty,empty_monitor)
actual['reusedEmpty']={'cyclicHas':'CYCLIC'in empty.properties,'cyclic':algorithm._boolean(empty,'CYCLIC'),
 'ownerCleared':cleared(),'monitor':monitor_info(empty_monitor),'sameClassConfiguration':owner.get_layout_processor_configuration(empty)is cfg and algorithm.DepthFirstCycleBreaker().get_layout_processor_configuration(empty)is cfg}
expected=dict(reference['value']);raw_configuration=expected.pop('rawConfiguration');comparison=diff(expected,actual);assert hashes()==before
output.write_text(json.dumps({'passed':comparison['passed'],'comparison':comparison,'actual':actual,'expected':expected,
 'rawSourceConfiguration':raw_configuration,'rawConfigurationOrderEquivalenceClaimed':False,'sourceFilesSha256':before,
 'sourceTreeUnchanged':True,'originalSha256':sha(original),'scope':'One independently defined seven-node working graph plus same-owner empty. Actual DFS/source order/parallel/selfloop/delayed collector reversal/full DTO/old-chain refs/labels/config/monitor; no whole layout or old group execution.'},indent=2)+'\n',encoding='utf8')
print(json.dumps({'passed':comparison['passed'],'differences':len(comparison['differences'])}));raise SystemExit(0 if comparison['passed']else 1)
