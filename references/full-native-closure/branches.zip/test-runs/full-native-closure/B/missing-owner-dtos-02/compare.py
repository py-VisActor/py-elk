from pathlib import Path
import copy,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'scripts'))
from pyelk.algorithms.layered.cycles_general import GreedyModelOrderCycleBreaker,InteractiveCycleBreaker
from pyelk.algorithms.layered.interactive_layering import InteractiveLayerer
from pyelk.algorithms.layered.width_layering import MinWidthLayerer
from pyelk.algorithms.layered.utility_processors import InteractiveExternalPortPositioner
from pyelk.algorithms.layered.graph import LGraph,LNode,LPort,LEdge,Vec2,set_source,set_target,set_port_owner
from pyelk.algorithms.layered.native_properties import CanonicalPropertyMap
from pyelk.algorithms.layered.ports import set_side
from pyelk.algorithms.layered.integer_box_tokens import value_of_integer_box
from pyelk.execution.diagnostics import BasicProgressMonitor
from layout_checks import diff

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def hashes():return {p.relative_to(ROOT/'src/pyelk').as_posix():sha(p)for p in (ROOT/'src/pyelk').rglob('*.py')}
def execute(case):
    graph=LGraph(None,None,None,properties=CanonicalPropertyMap());nodes={};names={};ports={};edges=[]
    graph.properties.set_property('MAX_MODEL_ORDER_NODES',len(case['nodes']),integer_box=value_of_integer_box(len(case['nodes'])))
    graph.properties.set_property('CB_NUM_MODEL_ORDER_GROUPS',0,integer_box=value_of_integer_box(0))
    graph.properties['INTERACTIVE_REFERENCE_POINT']=case['referencePoint']
    if case.get('external'):graph.properties['GRAPH_PROPERTIES']={'EXTERNAL_PORTS'}
    for index,item in enumerate(case['nodes']):
        node=LNode(graph,properties=CanonicalPropertyMap());node.type=item.get('type','NORMAL');node.pos=Vec2(item['x'],item['y']);node.size=Vec2(item['width'],item['height']);graph.layerless_nodes.append(node);nodes[item['name']]=node;names[id(node)]=item['name']
        node.properties.set_property('MODEL_ORDER',index,integer_box=value_of_integer_box(index))
        if item.get('constraint'):node.properties['LAYER_CONSTRAINT']=item['constraint']
        if item.get('inLayer'):node.properties['IN_LAYER_CONSTRAINT']=item['inLayer']
        for kind in ('in','out'):
            port=LPort(properties=CanonicalPropertyMap());set_port_owner(port,node);set_side(port,'WEST'if kind=='in'else'EAST');ports[item['name']+':'+kind]=port
    for index,(first,second)in enumerate(case['edges']):
        edge=LEdge(id=index,properties=CanonicalPropertyMap());set_source(edge,ports[first+':out']);set_target(edge,ports[second+':in']);edges.append(edge)
    def snapshot():
        return {'layerless':[names[id(n)]for n in graph.layerless_nodes],'layers':[[names[id(n)]for n in layer.nodes]for layer in graph.layers],'nodes':[{'name':name,'type':n.type,'id':n.id,'xy':[n.pos.x,n.pos.y],'wh':[n.size.x,n.size.y],'layer':graph.layers.index(n.layer)if n.layer in graph.layers else -1,'incoming':[e.id for p in n.ports for e in p.incoming_edges],'outgoing':[e.id for p in n.ports for e in p.outgoing_edges]}for name,n in nodes.items()],'edges':[{'id':e.id,'source':names[id(e.source.owner)],'target':names[id(e.target.owner)],'reversed':e.properties.get('REVERSED',False)}for e in edges]}
    constructors={cls.__name__:cls for cls in (GreedyModelOrderCycleBreaker,InteractiveCycleBreaker,InteractiveLayerer,MinWidthLayerer,InteractiveExternalPortPositioner)}
    owner=constructors[case['className']]();monitor=BasicProgressMonitor(False,False);before=snapshot();events=[{'event':'before-owner.process','className':case['className']}]
    try:
        owner.process(graph,monitor);events.append({'event':'after-owner.process','className':case['className']})
        return {'id':case['id'],'className':case['className'],'outcome':'returned','before':before,'after':snapshot(),'monitor':{'name':monitor.task_name,'running':monitor.is_running(),'closed':monitor._closed},'events':events}
    except Exception as error:
        return {'id':case['id'],'className':case['className'],'outcome':'threw','before':before,'after':snapshot(),'error':{'name':type(error).__name__,'message':str(error)},'events':events}

request_path,source_path,output,selection=map(str,sys.argv[1:5]);request=json.loads(Path(request_path).read_bytes());source=json.loads(Path(source_path).read_bytes())
assert source['workerSha256']=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86' and source['requestSha256']==sha(request_path)
assert source['probeSha256']==sha(Path(request_path).with_name('probe.cjs'))
indices=[0]if selection=='pilot'else list(range(1,len(request['cases'])))
before=hashes();actual=[execute(request['cases'][i])for i in indices];expected=[source['value'][i]for i in indices]
comparison=diff(expected,actual,tolerant=False);assert hashes()==before
record={'schema':'pyelk-missing-owner-state-native/v1','passed':comparison['passed'],'actual':actual,'expected':expected,'comparison':comparison,'requestSha256':sha(request_path),'sourceRawSha256':sha(source_path),'checkerSha256':sha(__file__),'sourceFilesSha256':before,'sourceUnchanged':True,'actualOwnerProcessCalls':len(indices),'publicLayoutExecuted':False}
Path(output).write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps({'passed':comparison['passed'],'differences':comparison['differences'],'outcomes':[r['outcome']for r in actual]}))
raise SystemExit(0 if comparison['passed']else 1)
