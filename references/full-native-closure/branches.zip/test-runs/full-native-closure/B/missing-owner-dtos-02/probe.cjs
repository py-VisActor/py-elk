const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),Module=require('node:module');
const [pkgArg,requestPath,outDir]=process.argv.slice(2),pkg=path.resolve(pkgArg),worker=path.join(pkg,'lib/elk-worker.js'),raw=fs.readFileSync(worker),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),requestRaw=fs.readFileSync(requestPath),request=JSON.parse(requestRaw);
if(sha(raw)!=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86')throw Error('Worker differs');
const bridge=String.raw`
global.__ownerState=function(input){
 $clinit_LayeredOptions();$clinit_InternalProperties_1();$clinit_LNode$NodeType();$clinit_PortSide();$clinit_InteractiveReferencePoint();$clinit_LayerConstraint();$clinit_InLayerConstraint();$clinit_GraphProperties();
 const graph=new LGraph,nodes=new Map,names=new Map,ports=new Map,edges=[],arr=list=>{const values=[],it=list.iterator_0();while(it.hasNext_0())values.push(it.next_1());return values;};
 $setProperty_0(graph,MAX_MODEL_ORDER_NODES,valueOf_3(input.nodes.length));$setProperty_0(graph,CB_NUM_MODEL_ORDER_GROUPS,valueOf_3(0));
 $setProperty_0(graph,INTERACTIVE_REFERENCE_POINT_0,input.referencePoint==='TOP_LEFT'?TOP_LEFT:CENTER_3);
 if(input.external)$getProperty(graph,GRAPH_PROPERTIES).add_2(EXTERNAL_PORTS);
 for(let index=0;index<input.nodes.length;index++){
  const item=input.nodes[index],n=new LNode(graph);n.type_0=item.type==='EXTERNAL_PORT'?EXTERNAL_PORT:NORMAL;n.pos.x_0=item.x;n.pos.y_0=item.y;n.size_0.x_0=item.width;n.size_0.y_0=item.height;$add_3(graph.layerlessNodes,n);nodes.set(item.name,n);names.set(n,item.name);$setProperty_0(n,MODEL_ORDER_2,valueOf_3(index));
  if(item.constraint)$setProperty_0(n,LAYERING_LAYER_CONSTRAINT_0,item.constraint==='FIRST_SEPARATE'?FIRST_SEPARATE_0:LAST_SEPARATE_0);
  if(item.inLayer)$setProperty_0(n,IN_LAYER_CONSTRAINT,item.inLayer==='TOP'?TOP_1:BOTTOM_0);
  for(const kind of ['in','out']){const p=new LPort;$setNode(p,n);$setSide(p,kind==='in'?WEST_2:EAST_2);ports.set(item.name+':'+kind,p);}
 }
 input.edges.forEach(([a,b],i)=>{const e=new LEdge;e.id_0=i;$setSource_0(e,ports.get(a+':out'));$setTarget_0(e,ports.get(b+':in'));edges.push(e);});
 function snapshot(){return {layerless:graph.layerlessNodes.array.map(n=>names.get(n)),layers:graph.layers.array.map(l=>l.nodes.array.map(n=>names.get(n))),nodes:[...nodes].map(([name,n])=>({name,type:n.type_0.name_0,id:n.id_0,xy:[n.pos.x_0,n.pos.y_0],wh:[n.size_0.x_0,n.size_0.y_0],layer:graph.layers.array.indexOf(n.layer),incoming:n.ports.array.flatMap(p=>p.incomingEdges.array.map(e=>e.id_0)),outgoing:n.ports.array.flatMap(p=>p.outgoingEdges.array.map(e=>e.id_0))})),edges:edges.map(e=>({id:e.id_0,source:names.get(e.source.owner),target:names.get(e.target.owner),reversed:$booleanValue(castToBoolean($getProperty(e,REVERSED)))}))};}
 const constructors={GreedyModelOrderCycleBreaker,InteractiveCycleBreaker,InteractiveLayerer,MinWidthLayerer,InteractiveExternalPortPositioner},owner=new constructors[input.className],monitor=new BasicProgressMonitor,before=snapshot(),events=[{event:'before-owner.process',className:input.className}];
 try{owner.process(graph,monitor);events.push({event:'after-owner.process',className:input.className});return {id:input.id,className:input.className,outcome:'returned',before,after:snapshot(),monitor:{name:monitor.getTaskName()??null,running:monitor.isRunning(),closed:monitor.closed_0},events};}
 catch(error){return{id:input.id,className:input.className,outcome:'threw',before,after:snapshot(),error:{name:String(error.name||'Error'),message:String(error.message||error)},events};}
};`;
const m=new Module(worker,module);m.filename=worker;m.paths=Module._nodeModulePaths(pkg);m._compile(raw.toString()+bridge,worker);
const values=[];
function record(name){fs.writeFileSync(path.join(outDir,name),JSON.stringify({workerSha256:sha(raw),probeSha256:sha(fs.readFileSync(__filename)),requestSha256:sha(requestRaw),pid:process.pid,parentPid:process.ppid,logging:false,measureExecutionTime:false,value:values,publicLayoutExecuted:false},null,2)+'\n',{flag:'wx'});}
values.push(global.__ownerState(request.cases[0]));record('source-pilot.json');console.log(JSON.stringify({stage:'pilot',outcome:values[0].outcome}));
const start=Date.now(),timer=setInterval(()=>{if(fs.existsSync(path.join(outDir,'continue.signal'))){clearInterval(timer);for(const row of request.cases.slice(1))values.push(global.__ownerState(row));record('source-final.json');console.log(JSON.stringify({stage:'final',outcomes:values.map(v=>({id:v.id,outcome:v.outcome}))}));}else if(Date.now()-start>120000){clearInterval(timer);process.exitCode=3;}},20);
