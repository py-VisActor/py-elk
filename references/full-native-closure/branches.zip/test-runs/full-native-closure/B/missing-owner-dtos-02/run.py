from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
env={k:v for k,v in os.environ.items()if k not in ('PYTHONPATH','PYTHONHOME','NODE_PATH','NODE_OPTIONS')};env['PATH']=''
def run_native(stage,source):
    argv=[sys.executable,'-I',str(OUT/'compare.py'),str(OUT/'request.json'),str(source),str(OUT/('native-'+stage+'.json')),stage]
    start=time.perf_counter();p=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=p.communicate(timeout=30)
    (OUT/('native-'+stage+'.stdout.log')).write_bytes(stdout);(OUT/('native-'+stage+'.stderr.log')).write_bytes(stderr)
    record={'argv':argv,'pid':p.pid,'exitCode':p.returncode,'timedOut':False,'elapsedSeconds':time.perf_counter()-start,'stdoutSha256':hashlib.sha256(stdout).hexdigest(),'stderrSha256':hashlib.sha256(stderr).hexdigest()}
    save(OUT/('native-'+stage+'-command.json'),record);print(stdout.decode(),flush=True)
    assert p.returncode==0,(stage,stderr.decode())
argv=['C:/Program Files/nodejs/node.exe',str(OUT/'probe.cjs'),str(ROOT/'.local/npm-elkjs/package'),str(OUT/'request.json'),str(OUT)]
start=time.perf_counter();source=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
    deadline=time.monotonic()+10
    while not(OUT/'source-pilot.json').exists():
        if source.poll()is not None or time.monotonic()>deadline:raise RuntimeError('Source pilot capture did not arrive')
        time.sleep(.02)
    pilot=json.loads((OUT/'source-pilot.json').read_bytes());assert pilot['value'][0]['outcome']=='returned',pilot['value'][0]
    run_native('pilot',OUT/'source-pilot.json')
    (OUT/'continue.signal').write_text('First real Source/native pilot passed. Continue remaining four owners.\n')
    stdout,stderr=source.communicate(timeout=30)
    (OUT/'source.stdout.log').write_bytes(stdout);(OUT/'source.stderr.log').write_bytes(stderr)
    save(OUT/'source-command.json',{'argv':argv,'pid':source.pid,'exitCode':source.returncode,'timedOut':False,'elapsedSecondsIncludingNativePilotWait':time.perf_counter()-start,'stdoutSha256':hashlib.sha256(stdout).hexdigest(),'stderrSha256':hashlib.sha256(stderr).hexdigest(),'sourceProcessCount':1})
    assert source.returncode==0,stderr.decode()
    run_native('remaining',OUT/'source-final.json')
except Exception:
    if source.poll()is None:source.kill()
    stdout,stderr=source.communicate()
    (OUT/'source-aborted.stdout.log').write_bytes(stdout);(OUT/'source-aborted.stderr.log').write_bytes(stderr)
    raise
