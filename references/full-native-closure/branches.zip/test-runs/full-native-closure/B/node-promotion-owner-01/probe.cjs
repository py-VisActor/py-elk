const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),Module=require('node:module');
const[pkgArg,requestPath,outDir]=process.argv.slice(2),pkg=path.resolve(pkgArg),worker=path.join(pkg,'lib/elk-worker.js'),raw=fs.readFileSync(worker),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),requestRaw=fs.readFileSync(requestPath),request=JSON.parse(requestRaw);
if(sha(raw)!=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86')throw Error('worker differs');
const bridge=String.raw`
global.__promotionState=function(s){
 $clinit_LayeredOptions();$clinit_InternalProperties_1();$clinit_LNode$NodeType();$clinit_PortSide();$clinit_NodePromotionStrategy();
 const graph=new LGraph,layers=Array.from({length:s.layers},()=>new Layer(graph)),nodes=new Map,ports=new Map,names=new Map,edges=[];
 for(const layer of layers)$add_3(graph.layers,layer);
 $setProperty_0(graph,LAYERING_NODE_PROMOTION_STRATEGY_0,valueOf_58(s.strategy));
 $setProperty_0(graph,LAYERING_NODE_PROMOTION_MAX_ITERATIONS_0,valueOf_3(s.until));$setProperty_0(graph,SPACING_NODE_NODE_0,s.nodeSpacing);$setProperty_0(graph,SPACING_EDGE_NODE_BETWEEN_LAYERS_0,s.edgeNodeSpacing);
 for(const spec of s.nodes){const n=new LNode(graph);n.type_0=NORMAL;n.size_0.x_0=spec.width;n.size_0.y_0=spec.height;$setProperty_0(n,MODEL_ORDER_2,valueOf_3(spec.modelOrder));$setLayer_0(n,layers[spec.layer]);nodes.set(spec.name,n);names.set(n,spec.name);for(const kind of ['in','out']){const p=new LPort;$setNode(p,n);$setSide(p,kind==='in'?WEST_2:EAST_2);ports.set(spec.name+':'+kind,p);}}
 for(const[i,[a,b]]of s.edges.entries()){const e=new LEdge;e.id_0=i;$setSource_0(e,ports.get(a+':out'));$setTarget_0(e,ports.get(b+':in'));edges.push(e);}
 const snapshot=()=>({layers:graph.layers.array.map(l=>({id:l.id_0,nodes:l.nodes.array.map(n=>names.get(n))})),nodes:[...nodes].map(([name,n])=>({name,id:n.id_0,layer:graph.layers.array.indexOf(n.layer),modelOrder:$getProperty(n,MODEL_ORDER_2).value_0})),edges:edges.map(e=>({id:e.id_0,source:names.get(e.source.owner),target:names.get(e.target.owner)}))});
 const owner=new NodePromotion,monitor=new BasicProgressMonitor,before=snapshot(),events=[],promotions=[],callbacks=[],counts={prepare:0,prepareModel:0,magic:0,promote:0,model:0,promoteModel:0,newLayering:0,newLayeringModel:0};let depth=0;
 const originals=[$precalculateAndSetInformation,$precalculateAndSetInformationModelOrder,$promotionMagic,$promoteNode,$modelOrderNodePromotion,$promoteNodeByModelOrder,$setNewLayering,$setNewLayeringModelOrder];
 $precalculateAndSetInformation=function(o){counts.prepare++;const result=originals[0](o);events.push({helper:'prepare',dummyCount:o.dummyNodeCount,maxWidth:o.maxWidth,maxHeight:o.maxHeight});return result;};
 $precalculateAndSetInformationModelOrder=function(o){counts.prepareModel++;return originals[1](o);};
 $promotionMagic=function(o,callback){counts.magic++;events.push({helper:'magic',strategy:o.promotionStrategy.name_0});const original=callback.apply_0;callback.apply_0=function(pair){const result=original.call(callback,pair);callbacks.push({reduced:pair.first.value_0,iteration:pair.second.value_0,result});return result;};try{return originals[2](o,callback);}finally{callback.apply_0=original;}};
 $promoteNode=function(o,n){counts.promote++;const top=depth===0;depth++;try{const result=originals[3](o,n);if(top)promotions.push({node:names.get(n),delta:result.first.value_0,allowed:result.second});return result;}finally{depth--;}};
 $modelOrderNodePromotion=function(o,left){counts.model++;events.push({helper:'model',left});return originals[4](o,left);};
 $promoteNodeByModelOrder=function(o,n,left){counts.promoteModel++;return originals[5](o,n,left);};
 $setNewLayering=function(o,g){counts.newLayering++;return originals[6](o,g);};$setNewLayeringModelOrder=function(o,g){counts.newLayeringModel++;return originals[7](o,g);};
 try{owner.process(graph,monitor);return {id:s.id,outcome:'returned',selectedProperty:$getProperty(graph,LAYERING_NODE_PROMOTION_STRATEGY_0).name_0,finalStrategy:owner.promotionStrategy.name_0,before,after:snapshot(),counts,events,promotions,callbacks,monitor:{name:monitor.getTaskName(),running:monitor.isRunning(),closed:monitor.closed_0}};}
 catch(error){return{id:s.id,outcome:'threw',before,after:snapshot(),counts,events,promotions,callbacks,error:{name:String(error.name),message:String(error.message),stack:String(error.stack)}};}
 finally{[$precalculateAndSetInformation,$precalculateAndSetInformationModelOrder,$promotionMagic,$promoteNode,$modelOrderNodePromotion,$promoteNodeByModelOrder,$setNewLayering,$setNewLayeringModelOrder]=originals;}
};`;
const m=new Module(worker,module);m.filename=worker;m.paths=Module._nodeModulePaths(pkg);m._compile(raw.toString()+bridge,worker);
const values=[];function call(row){try{return global.__promotionState(row);}catch(e){return{id:row.id,outcome:'threw',error:{name:String(e.name),message:String(e.message),stack:String(e.stack)}};}}
function save(name){fs.writeFileSync(path.join(outDir,name),JSON.stringify({workerSha256:sha(raw),probeSha256:sha(fs.readFileSync(__filename)),requestSha256:sha(requestRaw),pid:process.pid,parentPid:process.ppid,value:values,logging:false},null,2)+'\n',{flag:'wx'});}
values.push(call(request.cases[0]));save('source-pilot.json');console.log(values[0].outcome);
const start=Date.now(),timer=setInterval(()=>{if(fs.existsSync(path.join(outDir,'continue.signal'))){clearInterval(timer);for(const row of request.cases.slice(1))values.push(call(row));save('source-final.json');console.log(JSON.stringify(values.map(v=>({id:v.id,outcome:v.outcome}))));}else if(Date.now()-start>120000){clearInterval(timer);process.exitCode=3;}},20);
