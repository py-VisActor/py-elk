from pathlib import Path
import copy,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'scripts'))
from pyelk.algorithms.layered.node_promotion import NodePromotion
from pyelk.algorithms.layered.graph import LGraph,LNode,LPort,LEdge,Layer,set_layer,set_port_owner,set_source,set_target
from pyelk.algorithms.layered.native_properties import CanonicalPropertyMap
from pyelk.algorithms.layered.ports import set_side
from pyelk.algorithms.layered.integer_box_tokens import value_of_integer_box
from pyelk.execution.diagnostics import BasicProgressMonitor
from layout_checks import diff
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
hashes=lambda:{p.relative_to(ROOT/'src/pyelk').as_posix():sha(p)for p in(ROOT/'src/pyelk').rglob('*.py')}
def execute(s):
 graph=LGraph(None,None,None,properties=CanonicalPropertyMap());layers=[Layer(graph)for _ in range(s['layers'])];graph.layers.extend(layers);nodes={};names={};ports={};edges=[]
 graph.properties['LAYERING_NODE_PROMOTION_STRATEGY']=s['strategy'];graph.properties.set_property('LAYERING_NODE_PROMOTION_MAX_ITERATIONS',s['until'],integer_box=value_of_integer_box(s['until']));graph.properties['SPACING_NODE_NODE']=s['nodeSpacing'];graph.properties['SPACING_EDGE_NODE_BETWEEN_LAYERS']=s['edgeNodeSpacing']
 for item in s['nodes']:
  node=LNode(graph,properties=CanonicalPropertyMap());node.size.x=item['width'];node.size.y=item['height'];node.properties.set_property('MODEL_ORDER',item['modelOrder'],integer_box=value_of_integer_box(item['modelOrder']));set_layer(node,layers[item['layer']]);nodes[item['name']]=node;names[id(node)]=item['name']
  for kind in('in','out'):
   port=LPort(properties=CanonicalPropertyMap());set_port_owner(port,node);set_side(port,'WEST'if kind=='in'else'EAST');ports[item['name']+':'+kind]=port
 for i,(a,b)in enumerate(s['edges']):
  edge=LEdge(id=i,properties=CanonicalPropertyMap());set_source(edge,ports[a+':out']);set_target(edge,ports[b+':in']);edges.append(edge)
 def snapshot():return {'layers':[{'id':layer.id,'nodes':[names[id(n)]for n in layer.nodes]}for layer in graph.layers],'nodes':[{'name':name,'id':n.id,'layer':graph.layers.index(n.layer),'modelOrder':n.properties.get('MODEL_ORDER')}for name,n in nodes.items()],'edges':[{'id':e.id,'source':names[id(e.source.owner)],'target':names[id(e.target.owner)]}for e in edges]}
 owner=NodePromotion();monitor=BasicProgressMonitor(False,False);before=snapshot();counts={name:0 for name in['prepare','prepareModel','magic','promote','model','promoteModel','newLayering','newLayeringModel']};events=[];promotions=[];callbacks=[]
 prepare,prepare_model,magic,promote,model,promote_model,new_layering=owner._prepare,owner._prepare_model,owner._magic,owner._promote,owner._model,owner._promote_model,owner._new_layering
 def observed_prepare(g):
  counts['prepare']+=1;value=prepare(g);events.append({'helper':'prepare','dummyCount':owner.dummy_count,'maxWidth':owner.max_width,'maxHeight':owner.max_height});return value
 def observed_prepare_model(g,left):counts['prepareModel']+=1;return prepare_model(g,left)
 def observed_magic(callback):
  counts['magic']+=1;events.append({'helper':'magic','strategy':owner.strategy})
  def condition(reduced,iteration):
   result=callback(reduced,iteration);callbacks.append({'reduced':reduced,'iteration':iteration,'result':result});return result
  return magic(condition)
 def observed_promote(node):
  counts['promote']+=1;value=promote(node);promotions.append({'node':names[id(node)],'delta':value[0],'allowed':value[1]});return value
 def observed_model(left):counts['model']+=1;events.append({'helper':'model','left':left});return model(left)
 def observed_promote_model(node,left):counts['promoteModel']+=1;return promote_model(node,left)
 def observed_new_layering(g):counts['newLayering']+=1;return new_layering(g)
 owner._prepare=observed_prepare;owner._prepare_model=observed_prepare_model;owner._magic=observed_magic;owner._promote=observed_promote;owner._model=observed_model;owner._promote_model=observed_promote_model;owner._new_layering=observed_new_layering
 try:
  owner.process(graph,monitor)
  return {'id':s['id'],'outcome':'returned','selectedProperty':graph.properties.get('LAYERING_NODE_PROMOTION_STRATEGY'),'finalStrategy':owner.strategy,'before':before,'after':snapshot(),'counts':counts,'events':events,'promotions':promotions,'callbacks':callbacks,'monitor':{'name':monitor.task_name,'running':monitor.is_running(),'closed':monitor._closed}}
 except Exception as error:return {'id':s['id'],'outcome':'threw','before':before,'after':snapshot(),'counts':counts,'events':events,'promotions':promotions,'callbacks':callbacks,'error':{'name':type(error).__name__,'message':str(error)}}
request=json.loads((OUT/'request.json').read_bytes());stage=sys.argv[1];sourcepath=OUT/('source-pilot.json'if stage=='pilot'else'source-final.json');source=json.loads(sourcepath.read_bytes());assert source['requestSha256']==sha(OUT/'request.json')and source['probeSha256']==sha(OUT/'probe.cjs')
indices=[0]if stage=='pilot'else list(range(1,len(request['cases'])));initial=hashes();actual=[];rows=[]
for i in indices:
 value=execute(request['cases'][i]);actual.append(value);expected=copy.deepcopy(source['value'][i]);projected=copy.deepcopy(value)
 # Source recursion and native explicit frames have different raw helper-call boundaries.
 # Compare top-level promote results and semantic prepare/magic/model call counts.
 for x in(expected,projected):
  x['counts'].pop('promote',None);x['counts'].pop('newLayeringModel',None)
 comparison=diff(expected,projected,tolerant=False);rows.append({'id':value['id'],'sourceIndex':i,'comparison':comparison})
assert hashes()==initial
record={'schema':'pyelk-node-promotion-owner-native/v1','passed':all(row['comparison']['passed']for row in rows),'actual':actual,'rows':rows,'sourceRawSha256':sha(sourcepath),'requestSha256':sha(OUT/'request.json'),'checkerSha256':sha(__file__),'sourceFilesSha256':initial,'sourceFilesUnchanged':True,'projection':'Raw helper chronology/counts retained. Compare semantic prepare/magic/model counts, top-level promote results; Source recursive promote vs nativeframes, and Source separate layer rebuild vs native inline rebuild are not asserted as identical function events.'}
(OUT/('native-'+stage+'.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(json.dumps({'passed':record['passed'],'cases':[{'id':row['id'],'differences':len(row['comparison']['differences'])}for row in rows]}));raise SystemExit(0 if record['passed']else 1)
