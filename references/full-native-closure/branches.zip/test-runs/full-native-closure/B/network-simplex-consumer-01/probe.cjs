const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),Module=require('node:module');
const[pkgArg,requestPath,outDir]=process.argv.slice(2),pkg=path.resolve(pkgArg),worker=path.join(pkg,'lib/elk-worker.js'),raw=fs.readFileSync(worker),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),requestRaw=fs.readFileSync(requestPath),request=JSON.parse(requestRaw);
if(sha(raw)!=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86')throw Error('worker differs');
global.__nsRequest=request;
const bridge=String.raw`

global.__nsConsumer=function(s){
 getInstance();$clinit_LayeredOptions();$clinit_InternalProperties_1();$clinit_LNode$NodeType();$clinit_PortSide();$clinit_NodeFlexibility();$clinit_PortConstraints();
 const g=new LGraph,nodes=[],ports=[],edges=[],names=new Map,monitor=new BasicProgressMonitor,events=[];
 const input=global.__nsRequest;$setProperty_0(g,NODE_PLACEMENT_FAVOR_STRAIGHT_EDGES_0,false);$setProperty_0(g,RANDOM_0,new Random_0(input.seed));
 $setProperty_0(g,NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY_DEFAULT_0,valueOf_56(s.scope==='default'?s.value:'NONE'));
 const layers=[new Layer(g),new Layer(g),new Layer(g)];for(const l of layers)$add_3(g.layers,l);
 for(let i=0;i<input.nodes.length;i++){const spec=input.nodes[i],n=new LNode(g);n.type_0=NORMAL;n.id_0=i;n.pos.x_0=spec.x;n.pos.y_0=spec.y;n.size_0.x_0=spec.width;n.size_0.y_0=spec.height;$setLayer_0(n,layers[spec.layer]);$setProperty_0(n,PORT_CONSTRAINTS_0,FIXED_SIDE);names.set(n,spec.name);nodes.push(n);
  if(s.scope==='local'&&i===2)$setProperty_0(n,NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY_0,valueOf_56(s.value));
  const pair=[];for(const side of[WEST_2,EAST_2]){const p=new LPort;$setNode(p,n);p.size_0.x_0=2;p.size_0.y_0=2;$setSide(p,side);p.pos.x_0=side===WEST_2?-2:n.size_0.x_0;p.pos.y_0=n.size_0.y_0/2-1;pair.push(p);}ports.push(pair);
 }
 for(let i=0;i<input.edges.length;i++){const[a,b]=input.edges[i],e=new LEdge;e.id_0=i;$setSource_0(e,ports[a][1]);$setTarget_0(e,ports[b][0]);edges.push(e);}
 $setProperty_0(g,SPACINGS,new Spacings(g));
 const snapshot=()=>({layers:g.layers.array.map(l=>l.nodes.array.map(n=>names.get(n))),nodes:nodes.map(n=>({name:names.get(n),xy:[n.pos.x_0,n.pos.y_0],wh:[n.size_0.x_0,n.size_0.y_0],ports:n.ports.array.map(p=>({side:p.side.name_0,xy:[p.pos.x_0,p.pos.y_0]})),flexibility:getNodeFlexibility(n)?.name_0??null,localPresent:$hasProperty(n,NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY_0)})),defaultFlexibility:$getProperty(g,NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY_DEFAULT_0)?.name_0??null});
 const before=snapshot(),originalFlexible=isFlexibleNode,originalCreate=$create_6;
 isFlexibleNode=function(n){const v=originalFlexible(n);events.push({helper:'isFlexibleNode',node:names.get(n),flexibility:getNodeFlexibility(n)?.name_0??null,result:v});return v;};
 $create_6=function(strategy){const p=originalCreate(strategy),fn=p.process;events.push({helper:'factory',strategy:strategy.name_0,className:p.constructor.name});p.process=function(graph,pm){events.push({helper:'placer.process',strategy:strategy.name_0,className:p.constructor.name});return fn.call(p,graph,pm);};return p;};
 try{if(s.kind==='flex'){const owner=new NetworkSimplexPlacer;owner.process(g,monitor);}else{$setProperty_0(g,NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY_RECOMPUTE_NODE_PLACEMENT_0,valueOf_57(s.value));const owner=new NodePlacementRepeater;owner.process(g,monitor);}return{id:s.id,outcome:'returned',before,after:snapshot(),events,monitor:{name:monitor.getTaskName(),running:monitor.isRunning(),closed:monitor.closed_0}};}
 catch(e){return{id:s.id,outcome:'threw',before,after:snapshot(),events,error:{name:String(e.name),message:String(e.message),stack:String(e.stack)}};}
 finally{isFlexibleNode=originalFlexible;$create_6=originalCreate;}
};
`;
const m=new Module(worker,module);m.filename=worker;m.paths=Module._nodeModulePaths(pkg);m._compile(raw.toString()+bridge,worker);
const values=[];function call(row){try{return global.__nsConsumer(row);}catch(e){return{id:row.id,outcome:'threw',error:{name:String(e.name),message:String(e.message),stack:String(e.stack)}};}}
function save(name){fs.writeFileSync(path.join(outDir,name),JSON.stringify({workerSha256:sha(raw),probeSha256:sha(fs.readFileSync(__filename)),requestSha256:sha(requestRaw),pid:process.pid,parentPid:process.ppid,value:values,logging:false},null,2)+'\n',{flag:'wx'});}
values.push(call(request.cases[0]));save('source-pilot.json');console.log(values[0].outcome);
const start=Date.now(),timer=setInterval(()=>{if(fs.existsSync(path.join(outDir,'continue.signal'))){clearInterval(timer);for(const row of request.cases.slice(1))values.push(call(row));save('source-final.json');console.log(JSON.stringify(values.map(v=>({id:v.id,outcome:v.outcome}))));}else if(Date.now()-start>120000){clearInterval(timer);process.exitCode=3;}},20);
