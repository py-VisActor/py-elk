from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'scripts'))
from layout_checks import diff
from pyelk.algorithms.layered.graph import LGraph,LNode,LPort,LEdge,Layer,Vec2,set_layer,set_source,set_target,set_port_owner
from pyelk.algorithms.layered.native_properties import CanonicalPropertyMap
from pyelk.algorithms.layered.ports import set_side
from pyelk.algorithms.layered.phases import JavaRandom
from pyelk.algorithms.layered.spacings import Spacings
from pyelk.algorithms.layered.property_access import read_layered_scalar
from pyelk.algorithms.layered import network_simplex_placement as ns
from pyelk.algorithms.layered.utility_processors import node_placement_repeater
from pyelk.algorithms.layered.phase_factories import NodePlacementStrategy
from pyelk.execution.diagnostics import BasicProgressMonitor
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
request=json.loads((OUT/'request.json').read_bytes())
def execute(case):
 g=LGraph(None,None,None,properties=CanonicalPropertyMap());g.properties['NODE_PLACEMENT_FAVOR_STRAIGHT_EDGES']=False;g.random=JavaRandom(request['seed']);g.properties['RANDOM']=g.random
 g.properties['NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY_DEFAULT']=case['value']if case.get('scope')=='default'else'NONE'
 layers=[Layer(g)for _ in range(3)];g.layers.extend(layers);nodes=[];ports=[];edges=[];events=[]
 for i,s in enumerate(request['nodes']):
  n=LNode(g,id=i,properties=CanonicalPropertyMap());n.pos=Vec2(s['x'],s['y']);n.size=Vec2(s['width'],s['height']);set_layer(n,layers[s['layer']]);nodes.append(n);n.properties['PORT_CONSTRAINTS']='FIXED_SIDE'
  if case.get('scope')=='local'and i==2:n.properties['NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY']=case['value']
  pair=[]
  for side in('WEST','EAST'):
   p=LPort(properties=CanonicalPropertyMap());set_port_owner(p,n);p.size=Vec2(2.,2.);set_side(p,side);p.pos=Vec2(-2. if side=='WEST'else n.size.x,n.size.y/2-1);pair.append(p)
  ports.append(pair)
 for i,(a,b)in enumerate(request['edges']):
  e=LEdge(id=i,properties=CanonicalPropertyMap());set_source(e,ports[a][1]);set_target(e,ports[b][0]);edges.append(e)
 g.properties['SPACINGS']=Spacings(g);names={id(n):request['nodes'][i]['name']for i,n in enumerate(nodes)}
 def snapshot():
  return {'layers':[[names[id(n)]for n in l.nodes]for l in g.layers],'nodes':[{'name':names[id(n)],'xy':[n.pos.x,n.pos.y],'wh':[n.size.x,n.size.y],'ports':[{'side':p.side,'xy':[p.pos.x,p.pos.y]}for p in n.ports],'flexibility':ns.get_node_flexibility(n),'localPresent':'NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY'in n.properties}for n in nodes],'defaultFlexibility':read_layered_scalar(g,'NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY_DEFAULT','NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY_DEFAULT_0')}
 before=snapshot();monitor=BasicProgressMonitor();old=ns.is_flexible_node;old_create=NodePlacementStrategy.create
 def flexible(n):
  v=old(n);events.append({'helper':'isFlexibleNode','node':names[id(n)],'flexibility':ns.get_node_flexibility(n),'result':v});return v
 def create(strategy):
  p=old_create(strategy);fn=p.process;name=getattr(p,'source_name',type(p).__name__);events.append({'helper':'factory','strategy':strategy.name,'className':name})
  def process(graph,monitor=None):
   events.append({'helper':'placer.process','strategy':strategy.name,'className':name});return fn(graph,monitor=monitor)
  p.process=process;return p
 ns.is_flexible_node=flexible;NodePlacementStrategy.create=create
 try:
  if case['kind']=='flex':ns.NetworkSimplexPlacer().process(g,monitor)
  else:
   g.properties['NODE_PLACEMENT_NETWORK_SIMPLEX_NODE_FLEXIBILITY_RECOMPUTE_NODE_PLACEMENT']=case['value'];node_placement_repeater(g,monitor=monitor)
  return {'id':case['id'],'outcome':'returned','before':before,'after':snapshot(),'events':events,'monitor':{'name':monitor.task_name,'running':monitor.is_running(),'closed':monitor._closed}}
 except Exception as e:return {'id':case['id'],'outcome':'threw','before':before,'after':snapshot(),'events':events,'error':{'name':type(e).__name__,'message':str(e)}}
 finally:ns.is_flexible_node=old;NodePlacementStrategy.create=old_create
stage=sys.argv[1];originalPath=OUT/('source-pilot.json'if stage=='pilot'else'source-final.json');original=json.loads(originalPath.read_bytes())
assert original['workerSha256']=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86'
assert original['probeSha256']==sha(OUT/'probe.cjs')and original['requestSha256']==sha(OUT/'request.json')
before={p.relative_to(ROOT/'src').as_posix():sha(p)for p in(ROOT/'src').rglob('*.py')}
indices=list(range(5,len(request['cases'])))
actual=[execute(request['cases'][i])for i in indices];expected=[original['value'][i]for i in indices]
rawComparison=diff(expected,actual,tolerant=False)
def project(rows):
 import copy
 result=copy.deepcopy(rows)
 for row in result:
  for event in row['events']:event.pop('className',None)
 return result
comparison=diff(project(expected),project(actual),tolerant=False)
assert before=={p.relative_to(ROOT/'src').as_posix():sha(p)for p in(ROOT/'src').rglob('*.py')}
r={'passed':comparison['passed'],'comparison':comparison,'rawComparison':rawComparison,'projection':'Only host constructor.name is excluded; GWT returns Object and Python exposes actual class names. All semantic events/strategies/states remain exact.','actual':actual,'indices':indices,'sourceFilesSha256':before,'sourceRawSha256':sha(originalPath),'checkerSha256':sha(Path(__file__)),'requestSha256':sha(OUT/'request.json')}
(OUT/'native-recompute-02.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'stage':stage,'passed':comparison['passed'],'differences':comparison['differences'][:8]}));raise SystemExit(0 if comparison['passed']else 1)
