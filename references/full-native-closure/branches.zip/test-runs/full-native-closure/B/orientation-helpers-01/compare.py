from pathlib import Path
import sys,json,hashlib,math
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'scripts'))
from layout_checks import diff
from pyelk.algorithms.layered.graph import LGraph,LNode,LPort,LEdge,Vec2,Insets,set_port_owner,set_source,set_target
from pyelk.algorithms.layered.native_properties import CanonicalPropertyMap
from pyelk.algorithms.layered.native_adapters import _has_property,_read_property
from pyelk.algorithms.layered.ports import set_side
from pyelk.algorithms.layered.directions_general import GraphTransformer
from pyelk.algorithms.layered.integer_box_tokens import value_of_integer_box
from pyelk.execution.node_micro import VectorChain
from pyelk.algorithms.layered.interactive_order import interactive_reference_point
from pyelk.algorithms.layered.graph_configurator import get_direction,GraphConfigurator
from pyelk.algorithms.layered.phase_factories import FactoryRegistry,IntermediateProcessorStrategy
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
request=json.loads((OUT/'request.json').read_bytes());original=json.loads((OUT/'source.json').read_bytes())
assert original['probeSha256']==sha(OUT/'probe.cjs') and original['requestSha256']==sha(OUT/'request.json')
assert original['workerSha256']=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86'
before={p.relative_to(ROOT/'src').as_posix():sha(p)for p in (ROOT/'src').rglob('*.py')}
def rotation(request):
    g=LGraph(None,None,None);g.properties=CanonicalPropertyMap({'DIRECTION':request['direction'],'DIRECTION_CONGRUENCY':request['congruency']})
    g.size=Vec2(100.0,80.0);g.offset=Vec2(2.0,3.0)
    n=LNode(g,properties=CanonicalPropertyMap());g.layerless_nodes.append(n);n.pos=Vec2(3.0,4.0);n.size=Vec2(20.0,10.0);n.padding=Insets(1.0,2.0,3.0,4.0)
    ports=[]
    for i,(index,side)in enumerate(zip(request['indices'],request['sides'])):
        p=LPort(properties=CanonicalPropertyMap());set_port_owner(p,n);p.size=Vec2(2.0,3.0);set_side(p,side);p.pos=Vec2(float(i+1),float(i+2));p.anchor=Vec2(.25,.75)
        p.properties.set_property('PORT_INDEX',index,integer_box=value_of_integer_box(index));ports.append(p)
    edge=LEdge(properties=CanonicalPropertyMap());set_source(edge,ports[0]);set_target(edge,ports[1])
    bend=Vec2(*map(float,request['bend']));edge.bend_points.append(bend)
    junction=Vec2(*map(float,request['junction']));chain=VectorChain([junction]);edge.properties['JUNCTION_POINTS']=chain
    presence=[_has_property(g,'NODE_LABELS_PADDING'),_has_property(n,'NODE_SIZE_MINIMUM')];events=[]
    class Monitor:
        def begin(self,name,work):events.append(['begin',name,work])
        def done(self):events.append(['done'])
    GraphTransformer(request['mode']).process(g,Monitor())
    point=lambda v:[v.x,v.y]
    insets=lambda v:[v.top,v.right,v.bottom,v.left]
    number=lambda v:'-0'if v==0 and math.copysign(1,v)<0 else v
    actual={'events':events,'graphSize':point(g.size),'graphOffset':point(g.offset),'nodePos':point(n.pos),'nodeSize':point(n.size),'nodePadding':insets(n.padding),
     'ports':[{'side':p.side,'pos':point(p.pos),'size':point(p.size),'anchor':point(p.anchor),'index':number(p.properties['PORT_INDEX'])}for p in ports],
     'zeroCached':ports[0].properties.integer_boxes['PORT_INDEX']is value_of_integer_box(0),'uncachedFresh':ports[1].properties.integer_boxes['PORT_INDEX']is not value_of_integer_box(-129),
     'typedChainSame':_read_property(edge,'JUNCTION_POINTS')is chain,'junctionSame':chain[0]is junction,'bendSame':edge.bend_points[0]is bend,'junction':point(junction),'bend':point(bend),
     'presenceBefore':presence,'presenceAfter':[_has_property(g,'NODE_LABELS_PADDING'),_has_property(n,'NODE_SIZE_MINIMUM')],'nodeMinimum':point(_read_property(n,'NODE_SIZE_MINIMUM')),'graphLabelPadding':insets(_read_property(g,'NODE_LABELS_PADDING')),
     'edgeLabelsSide':g.properties['EDGE_LABELS_SIDE_SELECTION'],'labelsEmpty':not n.labels and all(not p.labels for p in ports)and not edge.labels}
    return actual

def reference(name):
 g=LGraph(None,None,None);g.properties=CanonicalPropertyMap({'INTERACTIVE_REFERENCE_POINT':name})
 n=LNode(g,properties=CanonicalPropertyMap());n.pos=Vec2(*request['node']['pos']);n.size=Vec2(*request['node']['size']);v=interactive_reference_point(n)
 return {'selected':g.properties['INTERACTIVE_REFERENCE_POINT'],'pos':[n.pos.x,n.pos.y],'size':[n.size.x,n.size.y],'result':[v.x,v.y],'newVector':v is not n.pos}
def undefined(aspect):
 g=LGraph(None,None,None);g.properties=CanonicalPropertyMap({'DIRECTION':'UNDEFINED','ASPECT_RATIO':aspect});b=g.properties['DIRECTION'];v=get_direction(g)
 return {'aspect':aspect,'before':b,'result':v,'after':g.properties['DIRECTION']}
def unzip(name):
 g=LGraph(None,None,None);g.properties=CanonicalPropertyMap({'LAYER_UNZIPPING_STRATEGY':name});n=LNode(g,properties=CanonicalPropertyMap());g.layerless_nodes.append(n)
 c=GraphConfigurator(FactoryRegistry()).phase_independent_configuration(g)
 return {'selected':g.properties['LAYER_UNZIPPING_STRATEGY'],'nonemptyGraph':len(g.layerless_nodes),'beforeP4HasFactory':IntermediateProcessorStrategy.ALTERNATING_LAYER_UNZIPPER in c.get_list_item(3),'slot':3,'configurationReturned':c is not None}
actual=[]
def run(id,fn):
 try:actual.append({'id':id,'outcome':'returned','value':fn()})
 except Exception as e:actual.append({'id':id,'outcome':'threw','error':{'name':type(e).__name__,'message':str(e)}})
run('ROTATION-LEFT',lambda:rotation(request['rotation']))
for name in request['referencePoints']:run('reference-'+name,lambda name=name:reference(name))
for aspect in request['undefinedAspectRatios']:run('UNDEFINED-'+str(aspect),lambda aspect=aspect:undefined(aspect))
for name in request['unzipping']:run('unzipping-'+name,lambda name=name:unzip(name))
comparison=diff(original['value'],actual,tolerant=False)
assert before=={p.relative_to(ROOT/'src').as_posix():sha(p)for p in (ROOT/'src').rglob('*.py')}
report={'passed':comparison['passed'],'comparison':comparison,'actual':actual,'sourceFilesSha256':before,'sourceRawSha256':sha(OUT/'source.json'),'requestSha256':sha(OUT/'request.json'),'checkerSha256':sha(Path(__file__)),'publicLayoutExecuted':False}
(OUT/'native.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':comparison['passed'],'differences':comparison['differences'][:12]}));raise SystemExit(0 if comparison['passed']else 1)
