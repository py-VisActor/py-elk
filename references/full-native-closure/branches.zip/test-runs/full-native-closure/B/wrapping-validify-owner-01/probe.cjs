const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),Module=require('node:module');
const [packageArg,requestPath,out]=process.argv.slice(2),pkg=path.resolve(packageArg),worker=path.join(pkg,'lib/elk-worker.js'),raw=fs.readFileSync(worker),request=JSON.parse(fs.readFileSync(requestPath));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
if(sha(raw)!=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86')throw Error('worker differs');
const bridge=String.raw`

global.__wrappingState=function(input){
 getInstance();$clinit_LayeredOptions();$clinit_InternalProperties_1();$clinit_LNode$NodeType();$clinit_PortSide();
 const arr=x=>{const a=[],it=x.iterator_0();while(it.hasNext_0())a.push(it.next_1());return a;},ints=x=>arr(x).map(v=>v.value_0),array=a=>{const list=new ArrayList;for(const v of a)$add_3(list,valueOf_3(v));return list;};
 return input.cases.map(c=>{const g=new LGraph,nodes=[],ports=[],originalEdges=[],names=new Map,events=[],monitor=new BasicProgressMonitor;
 $setProperty_0(g,WRAPPING_CUTTING_STRATEGY_0,valueOf_39('MANUAL'));$setProperty_0(g,WRAPPING_CUTTING_CUTS_0,array(input.cuts));$setProperty_0(g,WRAPPING_VALIDIFY_STRATEGY_0,valueOf_65(c.validify));
 for(let i=0;i<input.layers;i++){const l=new Layer(g);$add_3(g.layers,l);const n=new LNode(g);n.type_0=NORMAL;n.size_0.x_0=20+i;n.size_0.y_0=15+i;$setLayer_0(n,l);nodes.push(n);names.set(n,'n'+i);const pair=[];for(const side of[WEST_2,EAST_2]){const p=new LPort;$setNode(p,n);$setSide(p,side);pair.push(p);}ports.push(pair);}
 for(const[a,b]of input.edges){const e=new LEdge;$setSource_0(e,ports[a][1]);$setTarget_0(e,ports[b][0]);originalEdges.push(e);}
 const node=n=>({name:names.get(n)??null,type:n.type_0.name_0}),snapshot=()=>({layers:g.layers.array.map(l=>l.nodes.array.map(node)),originalEdges:originalEdges.map(e=>({source:node(e.source.owner),target:node(e.target.owner),sourceSide:e.source.side.name_0,targetSide:e.target.side.name_0}))});
 const before=snapshot(),methods=[ICutIndexCalculator$ManualCutIndexCalculator.prototype.getCutIndexes,validifyIndexesGreedily,validifyIndexesLookingBack_0,$performCuts];
 ICutIndexCalculator$ManualCutIndexCalculator.prototype.getCutIndexes=function(graph,stats){const v=methods[0].call(this,graph,stats);events.push({helper:'manual',result:ints(v),layers:stats.longestPath});return v;};
 validifyIndexesGreedily=function(stats,cuts){const before=ints(cuts),v=methods[1](stats,cuts);events.push({helper:'validify',strategy:'GREEDY',before,result:ints(v),cutsAllowed:stats.cutsAllowed?Array.from(stats.cutsAllowed):null});return v;};
 validifyIndexesLookingBack_0=function(stats,cuts){const before=ints(cuts),v=methods[2](stats,cuts);events.push({helper:'validify',strategy:'LOOK_BACK',before,result:ints(v),cutsAllowed:stats.cutsAllowed?Array.from(stats.cutsAllowed):null});return v;};
 $performCuts=function(graph,stats,cuts){events.push({helper:'performCuts',cuts:ints(cuts)});return methods[3](graph,stats,cuts);};
 try{const owner=new SingleEdgeGraphWrapper;owner.process(g,monitor);return{id:c.id,outcome:'returned',strategy:$getProperty(g,WRAPPING_CUTTING_STRATEGY_0).name_0,validify:$getProperty(g,WRAPPING_VALIDIFY_STRATEGY_0).name_0,before,after:snapshot(),events,monitor:{name:monitor.getTaskName(),running:monitor.isRunning(),closed:monitor.closed_0}};}
 catch(e){return{id:c.id,outcome:'threw',before,after:snapshot(),events,error:{name:String(e.name),message:String(e.message),stack:String(e.stack)}};}
 finally{[ICutIndexCalculator$ManualCutIndexCalculator.prototype.getCutIndexes,validifyIndexesGreedily,validifyIndexesLookingBack_0,$performCuts]=methods;}
 });
};
`;
const m=new Module(worker,module);m.filename=worker;m.paths=Module._nodeModulePaths(pkg);m._compile(raw.toString()+bridge,worker);
const value=global.__wrappingState(request);
fs.writeFileSync(out,JSON.stringify({workerSha256:sha(raw),requestSha256:sha(fs.readFileSync(requestPath)),probeSha256:sha(fs.readFileSync(__filename)),pid:process.pid,value,publicLayoutExecuted:false},null,2)+'\n',{flag:'wx'});
