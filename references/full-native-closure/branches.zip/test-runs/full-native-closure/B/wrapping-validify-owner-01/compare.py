from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'scripts'))
from layout_checks import diff
from pyelk.algorithms.layered import wrapping as w
from pyelk.algorithms.layered.graph import LGraph,LNode,LPort,LEdge,Layer,Vec2,set_layer,set_source,set_target,set_port_owner
from pyelk.algorithms.layered.native_properties import CanonicalPropertyMap
from pyelk.algorithms.layered.ports import set_side
from pyelk.execution.diagnostics import BasicProgressMonitor
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
request=json.loads((OUT/'request.json').read_bytes());source=json.loads((OUT/'source.json').read_bytes());assert source['probeSha256']==sha(OUT/'probe.cjs')and source['requestSha256']==sha(OUT/'request.json')
beforeHash={p.relative_to(ROOT/'src').as_posix():sha(p)for p in(ROOT/'src').rglob('*.py')}
actual=[]
for c in request['cases']:
 g=LGraph(None,None,None,properties=CanonicalPropertyMap({'WRAPPING_CUTTING_STRATEGY':'MANUAL','WRAPPING_CUTTING_CUTS':list(request['cuts']),'WRAPPING_VALIDIFY_STRATEGY':c['validify']}));nodes=[];ports=[];original_edges=[];events=[];monitor=BasicProgressMonitor()
 for i in range(request['layers']):
  l=Layer(g);g.layers.append(l);n=LNode(g,properties=CanonicalPropertyMap());n.size=Vec2(20+i,15+i);set_layer(n,l);nodes.append(n);pair=[]
  for side in('WEST','EAST'):
   p=LPort(properties=CanonicalPropertyMap());set_port_owner(p,n);set_side(p,side);pair.append(p)
  ports.append(pair)
 for a,b in request['edges']:
  e=LEdge(properties=CanonicalPropertyMap());set_source(e,ports[a][1]);set_target(e,ports[b][0]);original_edges.append(e)
 names={id(n):'n'+str(i)for i,n in enumerate(nodes)}
 def node(n):return {'name':names.get(id(n)),'type':n.type}
 def snapshot():return {'layers':[[node(n)for n in l.nodes]for l in g.layers],'originalEdges':[{'source':node(e.source.owner),'target':node(e.target.owner),'sourceSide':e.source.side,'targetSide':e.target.side}for e in original_edges]}
 before=snapshot();old_cut=w.cut_indexes;old_validify=w.validify_cuts
 def cuts(graph,stats):
  v=old_cut(graph,stats);events.append({'helper':'manual','result':list(v),'layers':stats.longest_path});return v
 def validify(graph,stats,cuts):
  original=list(cuts);v=old_validify(graph,stats,cuts)
  if c['validify']!='NO':events.append({'helper':'validify','strategy':c['validify'],'before':original,'result':list(v),'cutsAllowed':stats.cuts_allowed})
  events.append({'helper':'performCuts','cuts':list(v)});return v
 w.cut_indexes=cuts;w.validify_cuts=validify
 try:
  w.single_edge_graph_wrapper(g,monitor=monitor);actual.append({'id':c['id'],'outcome':'returned','strategy':w.read(g,'WRAPPING_CUTTING_STRATEGY'),'validify':w.read(g,'WRAPPING_VALIDIFY_STRATEGY'),'before':before,'after':snapshot(),'events':events,'monitor':{'name':monitor.task_name,'running':monitor.is_running(),'closed':monitor._closed}})
 except Exception as e:actual.append({'id':c['id'],'outcome':'threw','before':before,'after':snapshot(),'events':events,'error':{'name':type(e).__name__,'message':str(e)}})
 finally:w.cut_indexes=old_cut;w.validify_cuts=old_validify
comparison=diff(source['value'],actual,tolerant=False);assert beforeHash=={p.relative_to(ROOT/'src').as_posix():sha(p)for p in(ROOT/'src').rglob('*.py')}
r={'passed':comparison['passed'],'comparison':comparison,'actual':actual,'sourceFilesSha256':beforeHash,'sourceRawSha256':sha(OUT/'source.json'),'checkerSha256':sha(Path(__file__))};(OUT/'native.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'passed':comparison['passed'],'differences':comparison['differences'][:12]}));raise SystemExit(0 if comparison['passed']else 1)
