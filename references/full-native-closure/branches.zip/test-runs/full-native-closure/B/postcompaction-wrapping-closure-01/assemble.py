from pathlib import Path
import json,hashlib,base64,sys
R=Path(__file__).resolve().parents[4];o=Path(__file__).parent;new=R/'test-runs/full-native-closure/B/wrapping-validify-owner-01';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bind=lambda p:{'path':p.relative_to(R).as_posix(),'sha256':sha(p)}
sys.path.insert(0,str(R/'scripts'));from layout_checks import diff
worker=R/'.local/npm-elkjs/package/lib/elk-worker.js';lines=worker.read_bytes().splitlines(keepends=True)
def span(a,b):
 z=b''.join(lines[a-1:b]);return {'firstLine':a,'lastLine':b,'sha256':hashlib.sha256(z).hexdigest(),'base64':base64.b64encode(z).decode()}
base=R/'test-runs/20261104-HOST-19/A';rows=[]
def strings(v,p=''):
 if isinstance(v,str):yield p,v
 elif isinstance(v,dict):
  for k,z in v.items():yield from strings(z,p+'/'+str(k).replace('~','~0').replace('/','~1'))
 elif isinstance(v,list):
  for i,z in enumerate(v):yield from strings(z,p+'/'+str(i))
def geometry(v,p=''):
 result=[]
 if isinstance(v,dict):
  for k,z in v.items():
   q=p+'/'+k
   if k in('x','y','width','height')and type(z)in(int,float):result.append({'pointer':q,'value':z})
   elif k!='logging':result+=geometry(z,q)
 elif isinstance(v,list):
  for i,z in enumerate(v):result+=geometry(z,p+'/'+str(i))
 return result
specs=[('compact-right','compaction.postCompaction.strategy','RIGHT','Horizontal Compaction','HorizontalGraphCompactor','horizontal_graph_compactor.py'),('compact-left-right-constraint-locking','compaction.postCompaction.strategy','LEFT_RIGHT_CONSTRAINT_LOCKING','Horizontal Compaction','HorizontalGraphCompactor','horizontal_graph_compactor.py'),('compact-left-right-connection-locking','compaction.postCompaction.strategy','LEFT_RIGHT_CONNECTION_LOCKING','Horizontal Compaction','HorizontalGraphCompactor','horizontal_graph_compactor.py'),('compact-quadratic','compaction.postCompaction.constraints','QUADRATIC','Horizontal Compaction','HorizontalGraphCompactor','horizontal_graph_compactor.py'),('compact-right','compaction.postCompaction.constraints','SCANLINE','Horizontal Compaction','HorizontalGraphCompactor','horizontal_graph_compactor.py'),('wrapping-single-edge-ard','wrapping.strategy','SINGLE_EDGE','Path-Like Graph Wrapping','SingleEdgeGraphWrapper','wrapping.py'),('wrapping-multi-edge-ard','wrapping.strategy','MULTI_EDGE','Breaking Point','BreakingPoint','breaking_points.py')]
for case,opt,val,task,className,module in specs:
 orig=next(base.glob('full-layered-*/'+case+'/reference.json'));native=orig.with_name('candidate.json');report=orig.with_name('comparison.json');req=R/'tests/fixtures/suites/full-native-layered/requests'/f'{case}.json';s=json.loads(orig.read_bytes());n=json.loads(native.read_bytes());d=json.loads(report.read_bytes());r=json.loads(req.read_bytes())
 assert s['outcome']==n['outcome']=='returned'and d['comparison']['passed']
 key='elk.layered.'+opt;assert r['graph']['layoutOptions'][key]==s['inputBefore']['layoutOptions'][key]==n['inputBefore']['layoutOptions'][key]==val
 assert s['engine']['entrypointSha256']=='b1032b7cfd2a57c54c6f0e8369d7665e19a579954f7cd20a6dae28f1912ea0d7'
 ts=[{'pointer':p,'value':v}for p,v in strings(s['result'],'/result')if p.endswith('/name')and task in v];tn=[{'pointer':p,'value':v}for p,v in strings(n['result'],'/result')if p.endswith('/name')and task in v];assert ts and tn
 slots=[{'pointer':p,'value':v}for p,v in strings(s['result'],'/result')if'Slot 'in v and className in v];assert slots
 gs=geometry(s['result'],'/result');gn=geometry(n['result'],'/result');gd=diff(gs,gn,tolerant=False);assert gd['passed']
 q=R/'src/pyelk/algorithms/layered'/module;assert sha(q)==n['engine']['sourceFilesSha256']['algorithms/layered/'+module]
 rows.append({'id':'option:org.eclipse.elk.layered.'+opt+':'+val,'kind':'source-route-state','historicalCase':case,'request':bind(req),'sourceRaw':bind(orig),'nativeRaw':bind(native),'comparisonReport':bind(report),'sourceInputValuePointer':'/inputBefore/layoutOptions/'+key,'nativeInputValuePointer':'/inputBefore/layoutOptions/'+key,'sourceTasks':ts,'nativeTasks':tn,'sourceActualSlots':slots,'geometryState':gs,'geometryStrictComparison':gd,'relevantNativeModule':{'file':q.relative_to(R).as_posix(),'historicalExecutionSha256':n['engine']['sourceFilesSha256']['algorithms/layered/'+module],'currentSha256':sha(q)},'historicalNativeVersion':n['engine']['version'],'scope':'Actual selected public processor task/slot, successful full output and fixed-source property-read/switch route. Enum read was not instrumented; not direct internal trace or causal geometry effect.'})
orig=base/'full-layered-01/direction-right/reference.json';native=orig.with_name('candidate.json');req=R/'tests/fixtures/suites/full-native-layered/requests/direction-right.json';s=json.loads(orig.read_bytes());n=json.loads(native.read_bytes());assert s['outcome']==n['outcome']=='returned'and s['result']['children'];assert 'elk.layered.wrapping.strategy'not in s['inputBefore']['layoutOptions']
observed=[]
for label,x in[('source',s),('native',n)]:
 ts=[{'pointer':p,'value':v}for p,v in strings(x['result'],'/result')if p.endswith('/name')];slots=[{'pointer':p,'value':v}for p,v in strings(x['result'],'/result')if'Slot 'in v]
 assert len(slots)>10 and not any(any(z in r['value']for z in('SingleEdgeGraphWrapper','BreakingPointInserter','BreakingPointProcessor','BreakingPointRemover','Path-Like Graph Wrapping','Breaking Point'))for r in ts+slots)
 observed.append({'role':label,'raw':bind(orig if label=='source'else native),'tasks':ts,'slots':slots,'wrappingTasksAndSlotsAbsent':True})
rows.append({'id':'option:org.eclipse.elk.layered.wrapping.strategy:OFF','kind':'actual-public-scheduler-exclusion-with-source-default-route','request':bind(req),'observations':observed,'sourceDefault':'Source48862 OFF_0 default and49130 actualalias; cfg28437..44 ordinal0 adds no wrapping factory. No owner.process(OFF) fake no-op.'})
ns=json.loads((new/'source.json').read_bytes());nn=json.loads((new/'native.json').read_bytes());assert nn['passed']and diff(ns['value'],nn['actual'],tolerant=False)['passed'];assert ns['probeSha256']==sha(new/'probe.cjs')and ns['requestSha256']==sha(new/'request.json')and ns['workerSha256']==sha(worker)
for i,sv in enumerate(ns['value']):
 assert sv['outcome']=='returned'and sv['strategy']=='MANUAL'
 rows.append({'id':'option:org.eclipse.elk.layered.wrapping.validify.strategy:'+sv['validify'],'kind':'actual-owner-helper-delegation-and-state','sourceFunction':'SingleEdgeGraphWrapper.process/$process_58 -> ManualCutIndexCalculator.getCutIndexes -> actual selected validify and $performCuts','nativeFunction':'single_edge_graph_wrapper -> cut_indexes -> validify_cuts -> actual layer/edge changes','sourceRaw':bind(new/'source.json'),'sourcePointer':f'/value/{i}','nativeRaw':bind(new/'native.json'),'nativePointer':f'/actual/{i}','actualEvents':sv['events'],'before':sv['before'],'after':sv['after'],'comparison':diff(sv,nn['actual'][i],tolerant=False)})
rows.append({'id':'option:org.eclipse.elk.layered.wrapping.cutting.strategy:MANUAL','kind':'actual-manual-calculator-original-owner-consumer','sourceRaw':bind(new/'source.json'),'sourcePointers':['/value/0/events/0','/value/1/events/0','/value/2/events/0'],'nativeRaw':bind(new/'native.json'),'nativePointers':['/actual/0/events/0','/actual/1/events/0','/actual/2/events/0'],'actualCutIndexes':[2,4],'performedCuts':{'NO':[2,4],'GREEDY':[3,5],'LOOK_BACK':[1,3]},'typedFixture':'Actual stored ArrayList<Integer> in Source; nativecanonical list. No claim public JSON reflection now supports it; real owner calls calculator and performs cuts.'})
assert len(rows)==12
for row in rows:
 if row['kind']=='source-route-state':
  case=row['historicalCase']
  row['sourceFunction']=('$process_53(HorizontalGraphCompactor)' if case.startswith('compact') else '$process_58(SingleEdgeGraphWrapper)' if 'single-edge'in case else '$process_55/$process_56/$process_57(BreakingPointInserter/Processor/Remover)')
  row['nativeFunction']=('HorizontalGraphCompactor.process' if case.startswith('compact') else 'single_edge_graph_wrapper' if 'single-edge'in case else 'breaking_point_inserter/processor/remover')
failed=base/'full-layered-01/wrapping-single-edge-manual/reference.json';f=json.loads(failed.read_bytes());assert f['outcome']=='threw'
pubpath=R/'docs/releases/evidence/published-0.1.0/wheel-installed.json';pub=json.loads(pubpath.read_bytes());assert all(nn['sourceFilesSha256'][k]==v for k,v in pub['runtimeFilesSha256'].items()if k.endswith('.py'))
result={'schema':'pyelk-postcompaction-wrapping-twelve-value-closure/v1','rows':rows,'historicalRouteStateValues':7,'historicalDefaultExclusionValues':1,'newTypedOwnerCases':3,'newTypedOwnerValues':4,'newSourceProcesses':1,'newSourceCalls':3,'newNativeCalls':3,'newSourcePid':ns['pid'],'newCasesFirstStrictPass':True,'pureAssembler':bind(Path(__file__)),'newRequest':bind(new/'request.json'),'newSourceProbe':bind(new/'probe.cjs'),'newNativeChecker':bind(new/'compare.py'),'newSourceCommand':bind(new/'source-command.json'),'newNativeCommand':bind(new/'native-command.json'),'sourceRouteSupportSpans':[span(a,b)for a,b in[(42553,42589),(28437,28444),(48862,48863),(49130,49130),(47953,47987),(47835,47847),(47095,47124),(47443,47452),(47504,47516)]],'oldManualJsonReflectionFailure':{'sourceRaw':bind(failed),'nativeRaw':bind(failed.with_name('candidate.json')),'outcome':f['outcome'],'error':f['error'],'notCountedAsMathExecution':True},'mathSourceModified':False,'all196SourceHashesEqualPublished':True,'publishedReceipt':bind(pubpath),'oldNormalCasesRerun':0,'claimLimits':['Historical7 rows are actual public processor-task + successful geometry-state + explicit fixedSource route. No fabricated internal enum-read event or output effect claim.','DefaultOFF proves actual nonempty public scheduler exclusion, not an owner no-op.','TypedMANUAL supplies the actual ArrayList<Integer> property that old JSON reflector could not instantiate. Old JSON failure remains.','Finite6layer graph exercises invalidcut2; no claim all arbitrary cuts/graphs are validated or source error behavior repaired.']}
p=o/'handoff.json';p.write_text(json.dumps(result,indent=2)+'\n');print('handoff',sha(p),'rows',len(rows))
