from pathlib import Path
import hashlib,json,sys,copy
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'scripts'))
from pyelk.algorithms.layered.graph import LGraph,LNode,LPort,Layer,set_layer,set_port_owner
from pyelk.algorithms.layered.native_properties import CanonicalPropertyMap
from pyelk.algorithms.layered.ports import set_side
from pyelk.algorithms.layered.phase_factories import IntermediateProcessorStrategy
from pyelk.algorithms.layered.integer_box_tokens import value_of_integer_box
from pyelk.algorithms.layered.model_order_nodes import ModelOrderNodeComparator
from pyelk.execution.diagnostics import BasicProgressMonitor
from layout_checks import diff
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
hashes=lambda:{p.relative_to(ROOT/'src/pyelk').as_posix():sha(p)for p in(ROOT/'src/pyelk').rglob('*.py')}
source=json.loads((OUT/'source.json').read_bytes());request=json.loads((OUT/'request.json').read_bytes())
assert source['workerSha256']=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86'
assert source['requestSha256']==sha(OUT/'request.json')and source['probeSha256']==sha(OUT/'probe.cjs')
initial=hashes();graph=LGraph(None,None,None,properties=CanonicalPropertyMap());layer=Layer(graph);graph.layers.append(layer);names={}
for i,name in enumerate(request['unzip']['names']):
 node=LNode(graph,properties=CanonicalPropertyMap());node.size.x=20+i;node.size.y=10+i;set_layer(node,layer);names[id(node)]=name
 if i==0:node.properties.set_property('LAYER_UNZIPPING_LAYER_SPLIT',request['unzip']['split'],integer_box=value_of_integer_box(request['unzip']['split']))
def snapshot():return {'layers':[[{'name':names.get(id(n)),'type':n.type}for n in l.nodes]for l in graph.layers],'nodeCount':sum(len(l.nodes)for l in graph.layers)}
before=snapshot();owner=IntermediateProcessorStrategy.ALTERNATING_LAYER_UNZIPPER.create();monitor=BasicProgressMonitor(False,False)
owner.process(graph,monitor)
actual=[{'id':'AlternatingLayerUnzipper','outcome':'returned','before':before,'after':snapshot(),'called':'registry AlternatingLayerUnzipper.process -> wrapping.alternating_layer_unzipper','monitor':{'name':monitor.task_name,'running':monitor.is_running(),'closed':monitor._closed}}]
assert len(before['layers'])==1 and len(actual[0]['after']['layers'])==2
assert actual[0]['after']['nodeCount']==len(request['unzip']['names'])
graph=LGraph(None,None,None,properties=CanonicalPropertyMap());node=LNode(graph,properties=CanonicalPropertyMap());port=LPort(properties=CanonicalPropertyMap());set_port_owner(port,node);set_side(port,'WEST')
owner=ModelOrderNodeComparator(graph,[],'PREFER_EDGES','EQUAL')
conditions={'portCount':len(node.ports),'incomingCount':sum(len(p.incoming_edges)for p in node.ports),'strategy':owner.long_edge_node_order}
value=owner._edge_model_order(node)
actual.append({'id':'equalNoIncomingFallback','outcome':'returned','before':conditions,'value':value,'called':'ModelOrderNodeComparator._edge_model_order'})
expected=copy.deepcopy(source['value']);projected=copy.deepcopy(actual)
for row in expected:row.pop('called',None)
for row in projected:row.pop('called',None)
source_events=expected[1].pop('fallbackEvents');assert source_events==[{'name':'EQUAL','ordinal':2}]
assert expected[1].pop('observerDelegatesOriginal')is True
assert conditions['incomingCount']==0 and value==0
comparison=diff(expected,projected,tolerant=False);assert hashes()==initial
record={'schema':'pyelk-unzip-equal-owner-native/v1','passed':comparison['passed'],'actual':actual,'sourceProjected':expected,'comparison':comparison,'sourceFallbackEvents':source_events,'sourceObserverDelegatesOriginal':True,'sourceRawSha256':sha(OUT/'source.json'),'requestSha256':sha(OUT/'request.json'),'checkerSha256':sha(__file__),'sourceFilesSha256':initial,'sourceFilesUnchanged':True,'ownerProcessCalls':1,'helperCalls':1,'publicLayoutExecuted':False,'rawObservationStructuresEqual':False,'projection':'Exclude role-specific callable names and keep Source-only fallback observer separately; all geometry/conditions/return/monitor exact'}
(OUT/'native.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps({'passed':comparison['passed'],'differences':comparison['differences']}));raise SystemExit(0 if comparison['passed']else 1)
