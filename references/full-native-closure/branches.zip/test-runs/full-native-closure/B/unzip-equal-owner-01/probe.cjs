const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),Module=require('node:module');
const[pkgArg,requestPath,outPath]=process.argv.slice(2),pkg=path.resolve(pkgArg),worker=path.join(pkg,'lib/elk-worker.js'),raw=fs.readFileSync(worker),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),requestRaw=fs.readFileSync(requestPath),request=JSON.parse(requestRaw);
if(sha(raw)!=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86')throw Error('worker differs');
const bridge=String.raw`
global.__unzipEqual=function(input){
 $clinit_LayeredOptions();$clinit_InternalProperties_1();$clinit_LNode$NodeType();$clinit_PortSide();$clinit_OrderingStrategy();$clinit_LongEdgeOrderingStrategy();
 const result=[];
 {const graph=new LGraph,layer=new Layer(graph),names=new Map,monitor=new BasicProgressMonitor;$add_3(graph.layers,layer);
 for(let i=0;i<input.unzip.names.length;i++){const n=new LNode(graph);n.type_0=NORMAL;n.size_0.x_0=20+i;n.size_0.y_0=10+i;$setLayer_0(n,layer);names.set(n,input.unzip.names[i]);if(i===0)$setProperty_0(n,LAYER_UNZIPPING_LAYER_SPLIT_0,valueOf_3(input.unzip.split));}
 const snapshot=()=>({layers:graph.layers.array.map(l=>l.nodes.array.map(n=>({name:names.get(n)??null,type:n.type_0.name_0}))),nodeCount:graph.layers.array.reduce((sum,l)=>sum+l.nodes.array.length,0)}),before=snapshot(),owner=new AlternatingLayerUnzipper;
 try{owner.process(graph,monitor);result.push({id:'AlternatingLayerUnzipper',outcome:'returned',before,after:snapshot(),called:'AlternatingLayerUnzipper.process',monitor:{name:monitor.getTaskName()??null,running:monitor.isRunning(),closed:monitor.closed_0}});}catch(e){result.push({id:'AlternatingLayerUnzipper',outcome:'threw',before,error:{name:String(e.name),message:String(e.message)}});}}
 {const graph=new LGraph,node=new LNode(graph),port=new LPort;node.type_0=NORMAL;$setNode(port,node);$setSide(port,WEST_2);const owner=new ModelOrderNodeComparator_0(graph,PREFER_EDGES,EQUAL,false),before={portCount:node.ports.array.length,incomingCount:node.ports.array.reduce((sum,p)=>sum+p.incomingEdges.array.length,0),strategy:owner.longEdgeNodeOrder.name_0},events=[],original=$returnValue;
 $returnValue=function(strategy){events.push({name:strategy.name_0,ordinal:strategy.ordinal});return original(strategy);};
 try{const value=$getModelOrderFromConnectedEdges(owner,node);result.push({id:'equalNoIncomingFallback',outcome:'returned',before,value,called:'$getModelOrderFromConnectedEdges',fallbackEvents:events,observerDelegatesOriginal:true});}catch(e){result.push({id:'equalNoIncomingFallback',outcome:'threw',before,error:{name:String(e.name),message:String(e.message)}});}finally{$returnValue=original;}}
 return result;
};`;
const m=new Module(worker,module);m.filename=worker;m.paths=Module._nodeModulePaths(pkg);m._compile(raw.toString()+bridge,worker);
fs.writeFileSync(outPath,JSON.stringify({workerSha256:sha(raw),requestSha256:sha(requestRaw),probeSha256:sha(fs.readFileSync(__filename)),pid:process.pid,parentPid:process.ppid,value:global.__unzipEqual(request),publicLayoutExecuted:false},null,2)+'\n',{flag:'wx'});
