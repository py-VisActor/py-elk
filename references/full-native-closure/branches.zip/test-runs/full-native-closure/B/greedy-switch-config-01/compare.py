from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'scripts'))
from layout_checks import diff
from pyelk.algorithms.layered.graph import LGraph,LNode
from pyelk.algorithms.layered.native_properties import CanonicalPropertyMap
from pyelk.algorithms.layered.graph_configurator import GraphConfigurator,activate_greedy_switch_for
from pyelk.algorithms.layered.phase_factories import FactoryRegistry,IntermediateProcessorStrategy as I
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
request=json.loads((OUT/'request.json').read_bytes());original=json.loads((OUT/'source.json').read_bytes());assert original['probeSha256']==sha(OUT/'probe.cjs')and original['requestSha256']==sha(OUT/'request.json')
before={p.relative_to(ROOT/'src').as_posix():sha(p)for p in(ROOT/'src').rglob('*.py')}
actual=[]
for s in request['cases']:
 try:
  g=LGraph(None,None,None,properties=CanonicalPropertyMap({'HIERARCHY_HANDLING':s['hierarchy'],'CROSSING_MINIMIZATION_GREEDY_SWITCH_TYPE':s['type'],'CROSSING_MINIMIZATION_GREEDY_SWITCH_HIERARCHICAL_TYPE':s['hierarchicalType']}));g.layerless_nodes.append(LNode(g,properties=CanonicalPropertyMap()));owner=GraphConfigurator(FactoryRegistry())
  def observe():
   active=activate_greedy_switch_for(g);cfg=owner.phase_independent_configuration(g);b=cfg.get_list_item(3)
   return {'parentPresent':getattr(g,'parent_node',None)is not None,'hierarchy':g.properties['HIERARCHY_HANDLING'],'normalType':g.properties['CROSSING_MINIMIZATION_GREEDY_SWITCH_TYPE'],'hierarchicalType':g.properties['CROSSING_MINIMIZATION_GREEDY_SWITCH_HIERARCHICAL_TYPE'],'graphNodeCount':len(g.layerless_nodes),'active':active,'beforeP4':{'one':I.ONE_SIDED_GREEDY_SWITCH in b,'two':I.TWO_SIDED_GREEDY_SWITCH in b}}
  root=observe();g.parent_node=LNode(LGraph(None,None,None));nested=observe();actual.append({'id':s['id'],'outcome':'returned','root':root,'nested':nested})
 except Exception as e:actual.append({'id':s['id'],'outcome':'threw','error':{'name':type(e).__name__,'message':str(e)}})
comparison=diff(original['value'],actual,tolerant=False);assert before=={p.relative_to(ROOT/'src').as_posix():sha(p)for p in(ROOT/'src').rglob('*.py')}
r={'passed':comparison['passed'],'comparison':comparison,'actual':actual,'sourceFilesSha256':before,'sourceRawSha256':sha(OUT/'source.json'),'checkerSha256':sha(Path(__file__))}
(OUT/'native.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'passed':comparison['passed'],'differences':comparison['differences'][:10]}));raise SystemExit(0 if comparison['passed']else 1)
