const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),Module=require('node:module');
const [packageArg,requestPath,out]=process.argv.slice(2),pkg=path.resolve(packageArg),worker=path.join(pkg,'lib/elk-worker.js'),raw=fs.readFileSync(worker),request=JSON.parse(fs.readFileSync(requestPath));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
if(sha(raw)!=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86')throw Error('worker differs');
const bridge=String.raw`

global.__greedyConfig=function(request){
 getInstance();$clinit_GraphConfigurator();$clinit_InternalProperties_1();$clinit_LayeredOptions();$clinit_IntermediateProcessorStrategy();
 return request.cases.map(s=>{try{const g=new LGraph,n=new LNode(g);$add_3(g.layerlessNodes,n);
 $setProperty_0(g,HIERARCHY_HANDLING,valueOf_107(s.hierarchy));$setProperty_0(g,CROSSING_MINIMIZATION_GREEDY_SWITCH_TYPE_0,valueOf_48(s.type));$setProperty_0(g,CROSSING_MINIMIZATION_GREEDY_SWITCH_HIERARCHICAL_TYPE_0,valueOf_48(s.hierarchicalType));
 const observe=()=>{const active=activateGreedySwitchFor(g),cfg=$getPhaseIndependentLayoutProcessorConfiguration(g),b=$getListItem(cfg,3);return{parentPresent:!!g.parentNode,hierarchy:$getProperty(g,HIERARCHY_HANDLING).name_0,normalType:$getProperty(g,CROSSING_MINIMIZATION_GREEDY_SWITCH_TYPE_0).name_0,hierarchicalType:$getProperty(g,CROSSING_MINIMIZATION_GREEDY_SWITCH_HIERARCHICAL_TYPE_0).name_0,graphNodeCount:g.layerlessNodes.array.length,active,beforeP4:{one:$contains_6(b,ONE_SIDED_GREEDY_SWITCH),two:$contains_6(b,TWO_SIDED_GREEDY_SWITCH)}};};
 const root=observe();g.parentNode=new LNode(new LGraph);const nested=observe();return{id:s.id,outcome:'returned',root,nested};}catch(e){return{id:s.id,outcome:'threw',error:{name:String(e.name),message:String(e.message),stack:String(e.stack)}};}});
};
`;
const m=new Module(worker,module);m.filename=worker;m.paths=Module._nodeModulePaths(pkg);m._compile(raw.toString()+bridge,worker);
const value=global.__greedyConfig(request);
fs.writeFileSync(out,JSON.stringify({workerSha256:sha(raw),requestSha256:sha(fs.readFileSync(requestPath)),probeSha256:sha(fs.readFileSync(__filename)),pid:process.pid,value,publicLayoutExecuted:false},null,2)+'\n',{flag:'wx'});
