import json,re
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
base=(ROOT/'tests/fixtures/suites/next-native/external-components-probe.cjs').read_text('utf-8')
bridge=base.split('const bridge=String.raw`',1)[1].split('`;',1)[0]
request={'components':{'cases':[{'name':'inside-port-side-groups','options':{'elk.direction':'RIGHT','elk.layered.considerModelOrder.components':'INSIDE_PORT_SIDE_GROUPS','elk.spacing.componentComponent':3},'sides':[['NORTH'],['NORTH'],['NORTH']]}]},'cb':['ONLY_WITHIN_GROUP','MODEL_ORDER','ENFORCED'],'cm':['MODEL_ORDER','ENFORCED'],'strategy':'NONE'}
(HERE/'request.json').write_text(json.dumps(request,indent=2)+'\n','utf-8')
extra=r'''
global.__orderFamily=function(request){
 registerLayoutAlgorithms(['layered']);$clinit_InternalProperties_1();$clinit_LayeredOptions();$clinit_GroupOrderStrategy();
 const enumValues=$getEnumConstants(Lorg_eclipse_elk_alg_layered_components_GroupOrderStrategy_2_classLit);
 const strategy=n=>enumValues.find(v=>v.name_0===n);
 function nodes(){const g=new LGraph,a=new LNode(g),b=new LNode(g);$add_3(g.layerlessNodes,a);$add_3(g.layerlessNodes,b);a.id_0=0;b.id_0=1;
  $setProperty_0(g,MAX_MODEL_ORDER_NODES,valueOf_3(10));$setProperty_0(g,CB_NUM_MODEL_ORDER_GROUPS,valueOf_3(3));
  $setProperty_0(a,MODEL_ORDER_2,valueOf_3(4));$setProperty_0(b,MODEL_ORDER_2,valueOf_3(0));return{g,a,b};}
 const cb=request.cb.map(name=>{const {g,a,b}=nodes();$setProperty_0(g,CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CB_GROUP_ORDER_STRATEGY_0,strategy(name));
  $setProperty_0(a,CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CYCLE_BREAKING_ID_0,valueOf_3(1));$setProperty_0(b,CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CYCLE_BREAKING_ID_0,valueOf_3(2));
  const owner=new GreedyModelOrderCycleBreaker;owner.layeredGraph=g;const candidates=new ArrayList;$add_3(candidates,a);$add_3(candidates,b);
  const reads=[],saved=$getProperty;$getProperty=function(h,p){const v=saved(h,p);if(h===g&&p===CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CB_GROUP_ORDER_STRATEGY_0)reads.push(v.name_0);return v;};
  let chosen;try{chosen=owner.chooseNodeWithMaxOutflow(candidates).id_0;}finally{$getProperty=saved;}
  return{strategy:name,chosen,strategyReads:reads};});
 const cm=request.cm.map(name=>{const {g,a,b}=nodes(),layer=new Layer(g);layer.id_0=0;$setLayer(a,0,layer);$setLayer(b,1,layer);
  $setProperty_0(g,CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CM_GROUP_ORDER_STRATEGY_0,strategy(name));
  $setProperty_0(a,CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CROSSING_MINIMIZATION_ID_0,valueOf_3(1));$setProperty_0(b,CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CROSSING_MINIMIZATION_ID_0,valueOf_3(2));
  const owner=new ModelOrderBarycenterHeuristic(null,null,null);owner.barycenterState=[[{barycenter:10},{barycenter:0}]];
  return{strategy:name,comparison:owner.barycenterStateComparator.compare_1(a,b),repeatedComparison:owner.barycenterStateComparator.compare_1(a,b)};});
 const g=new LGraph;new GraphConfigurator;$clinit_OrderingStrategy();$setProperty_0(g,CONSIDER_MODEL_ORDER_STRATEGY_0,NONE_11);
 const reads=[],saved=$getProperty;$getProperty=function(h,p){const v=saved(h,p);if(h===g&&p===CONSIDER_MODEL_ORDER_STRATEGY_0)reads.push(v.name_0);return v;};
 let config;try{config=$getPhaseIndependentLayoutProcessorConfiguration(g);}finally{$getProperty=saved;}
 const bucket=config.list.array[2],none={strategy:request.strategy,strategyReads:reads,sorterScheduled:bucket? $contains_6(bucket,SORT_BY_INPUT_ORDER_OF_MODEL):false};
 return{components:global.__externalComponents(request.components),cb,cm,none};
};
'''
# Enum class location is read from the actual compiled declaration, not guessed.
worker=(ROOT/'.local/npm-elkjs/package/lib/elk-worker.js').read_text('utf-8')
decl=worker[worker.index('function GroupOrderStrategy('):].split('\n',10)
lit=re.search(r'(L\w+_classLit) = createForEnum', '\n'.join(decl)).group(1)
extra=extra.replace('Lorg_eclipse_elk_alg_layered_components_GroupOrderStrategy_2_classLit',lit)
head=base.split('const bridge=String.raw`',1)[0]
tail="\nconst m=new Module(worker,module);m.filename=worker;m.paths=Module._nodeModulePaths(pkg);m._compile(raw.toString()+bridge,worker);\nconst observation=global.__orderFamily(JSON.parse(requestRaw));\nfs.writeFileSync(outPath,JSON.stringify({workerSha256:sha(raw),probeSha256:sha(fs.readFileSync(__filename)),requestSha256:sha(requestRaw),pid:process.pid,parentPid:process.ppid,node:process.version,observation,layoutExecuted:false,actualOwnerMethodsExecuted:true,candidateExecuted:false},null,2)+'\\n',{flag:'wx'});\n"
(HERE/'probe.cjs').write_text(head+'const bridge=String.raw`'+bridge+extra+'`;'+tail,'utf-8')
