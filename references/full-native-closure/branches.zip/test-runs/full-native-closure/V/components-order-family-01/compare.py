import hashlib,json,sys
from pathlib import Path
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts')]
from layout_checks import diff
from pyelk.algorithms.layered.graph import LGraph,LNode,Layer,set_layer
from pyelk.algorithms.layered.native_properties import CanonicalPropertyMap
from pyelk.algorithms.layered.integer_box_tokens import value_of_integer_box
from pyelk.algorithms.layered.cycles_general import GreedyModelOrderCycleBreaker
from pyelk.algorithms.layered.model_order_barycenter import ModelOrderBarycenterHeuristic
from pyelk.algorithms.layered.graph_configurator import GraphConfigurator
from pyelk.algorithms.layered.phase_factories import FactoryRegistry
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
request=json.loads((HERE/'request.json').read_bytes());original=json.loads((HERE/'source-02.json').read_bytes())
assert original['requestSha256']==sha(HERE/'request.json')
assert original['probeSha256']==sha(HERE/'probe.cjs')
assert original['workerSha256']==sha(ROOT/'.local/npm-elkjs/package/lib/elk-worker.js')
# Preserve the actual existing components comparator adapter verbatim inside a
# local namespace, with only its request/original bindings and output tail omitted.
old=(ROOT/'tests/fixtures/suites/next-native/compare_external_components.py').read_text('utf-8')
imports=old[old.index('from pyelk.algorithms.layered.graph'):old.index('sha=lambda')]
body=old[old.index('point=lambda'):old.index('comparison=diff')]
namespace={'request':request['components'],'metadata':None}
exec(imports,namespace)
namespace['metadata']=namespace['NativeMetadataService'](['layered'])
exec(body,namespace)
actual={'components':namespace['actual'],'cb':[],'cm':[]}
def nodes():
    g=LGraph(None,None,None,properties=CanonicalPropertyMap());a,b=LNode(g,id=0),LNode(g,id=1)
    g.layerless_nodes.extend((a,b));g.properties.update(MAX_MODEL_ORDER_NODES=10,CB_NUM_MODEL_ORDER_GROUPS=3)
    for n,order in ((a,4),(b,0)):
        n.properties=CanonicalPropertyMap();n.properties.set_property('MODEL_ORDER',order,integer_box=value_of_integer_box(order))
    return g,a,b
for strategy in request['cb']:
    g,a,b=nodes();key='CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CB_GROUP_ORDER_STRATEGY';g.properties[key]=strategy
    a.properties['CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CYCLE_BREAKING_ID']=1
    b.properties['CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CYCLE_BREAKING_ID']=2
    owner=GreedyModelOrderCycleBreaker();owner.layered_graph=g
    # Instrument the actual scalar reader by delegation; no manufactured getter counts.
    import pyelk.algorithms.layered.cycles_general as cycles
    saved=cycles.read_layered_scalar;reads=[]
    def read(h,k,s):
        value=saved(h,k,s)
        if h is g and k==key:reads.append(value)
        return value
    cycles.read_layered_scalar=read
    try:chosen=owner.choose_node_with_max_outflow([a,b]).id
    finally:cycles.read_layered_scalar=saved
    actual['cb'].append({'strategy':strategy,'chosen':chosen,'strategyReads':reads})
for strategy in request['cm']:
    g,a,b=nodes();layer=Layer(g);g.layers.append(layer);set_layer(a,layer);set_layer(b,layer)
    g.properties['CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CM_GROUP_ORDER_STRATEGY']=strategy
    for n,group in ((a,1),(b,2)):n.properties['CONSIDER_MODEL_ORDER_GROUP_MODEL_ORDER_CROSSING_MINIMIZATION_ID']=group
    owner=ModelOrderBarycenterHeuristic(None,None,None);owner.states={a:SimpleNamespace(barycenter=10),b:SimpleNamespace(barycenter=0)}
    actual['cm'].append({'strategy':strategy,'comparison':owner.compare(a,b),'repeatedComparison':owner.compare(a,b)})
g=LGraph(None,None,None,properties=CanonicalPropertyMap());g.properties['CONSIDER_MODEL_ORDER_STRATEGY']='NONE'
import pyelk.algorithms.layered.graph_configurator as configurator
saved=configurator._read;reads=[]
def read(h,s):
    value=saved(h,s)
    if h is g and s=='CONSIDER_MODEL_ORDER_STRATEGY_0':reads.append(value)
    return value
configurator._read=read
try:configuration=GraphConfigurator(FactoryRegistry()).phase_independent_configuration(g)
finally:configurator._read=saved
actual['none']={'strategy':'NONE','strategyReads':reads,'sorterScheduled':any(factory.name=='SORT_BY_INPUT_ORDER_OF_MODEL' for factory in configuration.get_list_item(2))}
comparison=diff(original['observation'],actual,tolerant=False)
bindings={}
for m in tuple(sys.modules.values()):
    file=getattr(m,'__file__',None)
    if file:
        p=Path(file).resolve()
        if p.is_relative_to(ROOT/'src') and p.suffix=='.py':bindings[p.relative_to(ROOT).as_posix()]=sha(p)
report={'passed':comparison['passed'],'actual':actual,'comparison':comparison,'bindings':bindings,'requestSha256':sha(HERE/'request.json'),'referenceSha256':sha(HERE/'source-02.json'),'checkerSha256':sha(Path(__file__)),'layoutExecuted':False,'scope':'Seven actual owner/helper or scheduler state objects; supplied component dimensions; not full layout'}
out=HERE/'native-01.json'
with out.open('x',encoding='utf-8')as f:json.dump(report,f,indent=2,allow_nan=False)
print(json.dumps({'passed':report['passed'],'differences':comparison['differences'][:10]}))
raise SystemExit(0 if report['passed']else 1)
