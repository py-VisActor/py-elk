import hashlib,json,subprocess,sys,time
from pathlib import Path
r=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out=r/'test-runs/20261104-HOST-18/A/label-management-owner-02'
if '--child' in sys.argv:
 sys.path.insert(0,str(r/'.local/migration-next/src'))
 from pyelk.algorithms.layered.graph import LGraph
 from pyelk.algorithms.layered.native_properties import CanonicalPropertyMap
 from pyelk.algorithms.layered.label_management_general import label_management_processor
 from pyelk.execution.diagnostics import BasicProgressMonitor
 results=[]
 for ident,value in [('absent',None),('false',False),('zero',0),('emptyString',''),('emptyList',[])]:
  graph=LGraph(None,None,None,properties=CanonicalPropertyMap());monitor=BasicProgressMonitor(logging=True)
  if ident!='absent':graph.properties['org.eclipse.elk.labels.labelManager']=value
  error=None
  try:label_management_processor(graph,monitor=monitor)
  except TypeError as caught:error=str(caught)
  assert monitor.task_name=='Label management'
  if ident=='absent':assert error is None and monitor._closed and 'org.eclipse.elk.labels.labelManager'not in graph.properties
  else:assert error is not None and not monitor._closed and graph.properties['org.eclipse.elk.labels.labelManager']is value
  results.append({'id':ident,'returned':error is None,'error':error,'monitorName':monitor.task_name,'done':monitor._closed})
 (out/'report.json').write_text(json.dumps({'passed':True,'cases':results,'sourceAcquisitions':0,'wholeLayouts':0},indent=2)+'\n',encoding='utf8',newline='\n')
 print(json.dumps({'passed':True,'changedCallbackCalls':len(results)}));raise SystemExit(0)
out.mkdir(parents=True,exist_ok=False)
files=[r/'.local/migration-next/src/pyelk/algorithms/layered'/n for n in ['label_management_general.py','native_adapters.py','native_properties.py','graph.py']];before={p.relative_to(r).as_posix():sha(p)for p in files}
argv=[sys.executable,str(Path(__file__).resolve()),'--child'];started=time.perf_counter();p=subprocess.Popen(argv,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=p.communicate();wall=time.perf_counter()-started
(out/'stdout.log').write_bytes(stdout);(out/'stderr.log').write_bytes(stderr)
assert before=={p.relative_to(r).as_posix():sha(p)for p in files}
(out/'command.json').write_text(json.dumps({'argv':argv,'cwd':str(r),'pid':p.pid,'exitCode':p.returncode,'wallSeconds':wall,'filesSha256':before,'runnerSha256':sha(Path(__file__)),'sourceAcquisitions':0,'wholeLayouts':0},indent=2)+'\n',encoding='utf8',newline='\n');print(stdout.decode());print(stderr.decode());raise SystemExit(p.returncode)
