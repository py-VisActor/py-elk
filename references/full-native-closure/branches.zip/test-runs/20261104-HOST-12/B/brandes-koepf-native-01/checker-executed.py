from pathlib import Path
import sys,json,hashlib
source,request,original,out=map(Path,sys.argv[1:]);sys.path.insert(0,str(source.absolute()));sys.path.insert(0,str(Path('scripts').absolute()))
from layout_checks import diff
from pyelk.algorithms.layered import brandes_koepf_general as bk
from pyelk.algorithms.layered.graph import LGraph,LNode,LPort,LEdge,Layer,set_source,set_target,set_layer
from pyelk.algorithms.layered.spacings import Spacings
from pyelk.execution.diagnostics import BasicProgressMonitor,layout_name
def hashes():return {str(p.relative_to(source)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in source.rglob('*')if p.is_file()and '__pycache__'not in p.parts}
before=hashes();actual=[]
for s in json.loads(request.read_text(encoding='utf8'))['cases']:
    saved=json.loads(json.dumps(s));graph=LGraph(None,None,None);nodes=[LNode(graph)for _ in s['nodes']]
    for item in s['nodes']:
        node=nodes[item['id']];node.size.x=item['width'];node.size.y=item['height']
        for key,value in item['margin'].items():setattr(node.margin,key,value)
        while len(graph.layers)<=item['layer']:graph.layers.append(Layer(graph))
        set_layer(node,graph.layers[item['layer']])
        if item['individual']:node.properties['SPACING_INDIVIDUAL']=dict(item['individual'])
    for item in s['edges']:
        p=LPort(nodes[item['source']]);q=LPort(nodes[item['target']]);p.owner.ports.append(p);q.owner.ports.append(q)
        p.pos.y=item['sourceY'];p.anchor.y=item['sourceAnchorY'];q.pos.y=item['targetY'];q.anchor.y=item['targetAnchorY']
        edge=LEdge();set_source(edge,p);set_target(edge,q);edge.properties['PRIORITY_STRAIGHTNESS']=item['priority']
    graph.properties.update(SPACING_NODE_NODE=s['spacingNodeNode'],SPACING_EDGE_NODE=s['spacingEdgeNode'],SPACING_EDGE_EDGE=s['spacingEdgeEdge'],
                            NODE_PLACEMENT_BK_FIXED_ALIGNMENT=s['alignment'],NODE_PLACEMENT_FAVOR_STRAIGHT_EDGES=s['favorStraight'],NODE_PLACEMENT_BK_EDGE_STRAIGHTENING=s['straightening'])
    graph.properties['SPACINGS']=Spacings(graph)
    observed={'compactions':[],'balancedCalls':0,'feasibility':[]}
    compact,balance,feasible=bk._Compactor.compact,bk._balanced_layout,bk._feasible
    def watch_compact(self,layout):
        result=compact(self,layout)
        observed['compactions'].append({'name':layout_name(layout),'strategy':'SIMPLE'if self.improve else'NULL',
                                        'y':[layout.y[n]for n in nodes],'inner':[layout.inner[n]for n in nodes]})
        return result
    def watch_balance(*args):observed['balancedCalls']+=1;return balance(*args)
    def watch_feasible(layout,**kwargs):
        result=feasible(layout,**kwargs);observed['feasibility'].append({'name':layout_name(layout),'feasible':result});return result
    bk._Compactor.compact,bk._balanced_layout,bk._feasible=watch_compact,watch_balance,watch_feasible
    monitor=BasicProgressMonitor(logging=True)
    try:bk.bk_node_placer(graph,monitor=monitor)
    finally:bk._Compactor.compact,bk._balanced_layout,bk._feasible=compact,balance,feasible
    if s!=saved:raise AssertionError('Request modified')
    actual.append({'id':s['id'],'value':{'positions':[[n.pos.x,n.pos.y]for n in nodes],
                  'nodeIds':[n.id for n in nodes],'logs':list(monitor._messages),**observed}})
expected=json.loads(original.read_text(encoding='utf8'))['results'];delta=diff(expected,actual);after=hashes()
report={'passed':delta['passed']and before==after,'expected':expected,'actual':actual,'differences':delta,
        'sourceFilesSha256':before,'sourceTreeUnchanged':before==after,'originalSha256':hashlib.sha256(original.read_bytes()).hexdigest(),
        'requestSha256':hashlib.sha256(request.read_bytes()).hexdigest(),'scope':'Seven new prepared BK phase objects; 12 nodes each, explicit anchors/priority/individual spacing, all selection variants, no full/public layout execution'}
out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf8');print(json.dumps({'passed':report['passed'],'cases':len(actual),'differences':len(delta['differences'])}));raise SystemExit(0 if report['passed']else 1)
