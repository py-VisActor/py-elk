const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),Module=require('node:module');
const [pkgArg,requestPath,outPath]=process.argv.slice(2),pkg=path.resolve(pkgArg),worker=path.join(pkg,'lib/elk-worker.js');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),raw=fs.readFileSync(worker),request=fs.readFileSync(requestPath);
if(sha(raw)!=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86')throw Error('worker differs');
const bridge=String.raw`
global.__generalBK=function(s){
 getInstance();$clinit_LayeredOptions();$clinit_FixedAlignment();$clinit_EdgeStraighteningStrategy();$clinit_InternalProperties_1();
 const array=list=>{const out=[],it=list.iterator_0();while(it.hasNext_0())out.push(it.next_1());return out;};
 const g=new LGraph,nodes=s.nodes.map(()=>new LNode(g)),ids=new Map(nodes.map((n,i)=>[n,i])),layers=[];
 for(const item of s.nodes){const n=nodes[item.id];n.size_0.x_0=item.width;n.size_0.y_0=item.height;Object.assign(n.margin,{top_0:item.margin.top,right:item.margin.right,bottom:item.margin.bottom,left:item.margin.left});
  while(layers.length<=item.layer){const l=new Layer(g);layers.push(l);$add_3(g.layers,l);}$setLayer(n,layers[item.layer].nodes.array.length,layers[item.layer]);
  if(Object.keys(item.individual).length){const p=new IndividualSpacings;for(const [name,value]of Object.entries(item.individual)){if(name!=='org.eclipse.elk.spacing.nodeNode')throw Error('Unexpected property');p.setProperty(SPACING_NODE_NODE_0,value);}$setProperty_0(n,SPACING_INDIVIDUAL_0,p);}
 }
 for(const e of s.edges){const edge=new LEdge,p=new LPort,q=new LPort;$setNode(p,nodes[e.source]);$setNode(q,nodes[e.target]);p.pos.y_0=e.sourceY;p.anchor.y_0=e.sourceAnchorY;q.pos.y_0=e.targetY;q.anchor.y_0=e.targetAnchorY;$setSource_0(edge,p);$setTarget_0(edge,q);$setProperty_0(edge,PRIORITY_STRAIGHTNESS_0,valueOf_3(e.priority));}
 $setProperty_0(g,SPACING_NODE_NODE_0,s.spacingNodeNode);$setProperty_0(g,SPACING_EDGE_NODE,s.spacingEdgeNode);$setProperty_0(g,SPACING_EDGE_EDGE,s.spacingEdgeEdge);$setProperty_0(g,SPACINGS,new Spacings(g));
 const modes={NONE:NONE_4,LEFTUP,RIGHTUP,LEFTDOWN,RIGHTDOWN,BALANCED};$setProperty_0(g,NODE_PLACEMENT_BK_FIXED_ALIGNMENT_0,modes[s.alignment]);$setProperty_0(g,NODE_PLACEMENT_FAVOR_STRAIGHT_EDGES_0,s.favorStraight);$setProperty_0(g,NODE_PLACEMENT_BK_EDGE_STRAIGHTENING_0,s.straightening==='NONE'?NONE_3:IMPROVE_STRAIGHTNESS);
 const observations={compactions:[],balancedCalls:0,feasibility:[]},compact=$horizontalCompaction,balance=$createBalancedLayout,feasible=$checkOrderConstraint;
 $horizontalCompaction=function(comp,bal){const strategy=instanceOf(comp.threshStrategy,1863)?'NULL':'SIMPLE';const r=compact(comp,bal);observations.compactions.push({name:bal.toString_0(),strategy,y:nodes.map(n=>bal.y_0[n.id_0]),inner:nodes.map(n=>bal.innerShift[n.id_0])});return r;};
 $createBalancedLayout=function(...args){observations.balancedCalls++;return balance(...args);};
 $checkOrderConstraint=function(g,bal,m){const r=feasible(g,bal,m);observations.feasibility.push({name:bal.toString_0(),feasible:r});return r;};
 const monitor=$withLogging(new BasicProgressMonitor,true);
 try{$process_82(new BKNodePlacer,g,monitor);}finally{$horizontalCompaction=compact;$createBalancedLayout=balance;$checkOrderConstraint=feasible;}
 return {positions:nodes.map(n=>[n.pos.x_0,n.pos.y_0]),nodeIds:nodes.map(n=>n.id_0),logs:array(monitor.logMessages),...observations};
};`;
const m=new Module(worker,module);m.filename=worker;m.paths=Module._nodeModulePaths(pkg);m._compile(raw.toString()+bridge,worker);
fs.writeFileSync(outPath,JSON.stringify({schema:'py-elk-general-bk-original-objects/v1',workerSha256:sha(raw),probeSha256:sha(fs.readFileSync(__filename)),requestSha256:sha(request),pid:process.pid,parentPid:process.ppid,node:process.version,results:JSON.parse(request).cases.map(s=>({id:s.id,value:global.__generalBK(s)})),delegatedObservation:true,providerExecuted:false,nativeExecuted:false},null,2)+'\n',{flag:'wx'});
