from pathlib import Path
import hashlib,json,sys,copy,math
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'scripts'))
from pyelk.algorithms import mrtree as m,radial as r
from pyelk.execution.diagnostics import BasicProgressMonitor
from pyelk.execution.json_transfer import JsonLayoutSession
from layout_checks import diff
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
hashes=lambda:{p.relative_to(ROOT/'src/pyelk').as_posix():sha(p)for p in(ROOT/'src/pyelk').rglob('*.py')}
def execute(s):
 if s['kind']!='radial':
  graph=m.TGraph(None,properties={});nodes=[];edges=[]
  for i,item in enumerate(s['nodes']):
   n=m.TNode(i,graph,'n'+str(i));n.pos=m.Vec2(*item.get('pos',[0,0]));n.size=m.Vec2(*item['size']);graph.nodes.append(n);nodes.append(n)
   if i==0:n.properties['ROOT']=True
   if 'constraint'in item:n.properties['mrtree.positionConstraint']=item['constraint']
  for spec in s['edges']:
   edge=m.TEdge(nodes[spec[0]],nodes[spec[1]]);graph.edges.append(edge);edges.append(edge);edge.source.outgoing_edges.append(edge);edge.target.incoming_edges.append(edge)
   edge.bend_points.extend(m.Vec2(*p)for p in(spec[2]if len(spec)>2 else []))
  def snapshot():return {'nodes':[{'id':n.id,'position':[n.pos.x,n.pos.y],'outgoing':[e.target.id for e in n.outgoing_edges],'fan':n.properties.get('FAN',0),'descendants':n.properties.get('DESCENDANTS',0),'order':n.properties.get('POSITION',0)}for n in nodes],'edges':[{'source':e.source.id,'target':e.target.id,'bends':[[p.x,p.y]for p in e.bend_points]}for e in edges]}
  monitor=BasicProgressMonitor(False,False)
  if s['kind']=='tree':
   graph.properties['mrtree.weighting']=s['weighting'];m.calculate_fan(graph,BasicProgressMonitor(False,False));before=snapshot();m.order_nodes(graph,monitor);selected=s['weighting'];called='mrtree.order_nodes'
  else:
   graph.properties['mrtree.edgeRoutingMode']='NONE';before=snapshot();m.route_edges(graph,monitor);selected='NONE';called='mrtree.route_edges'
  return {'id':s['id'],'before':before,'after':snapshot(),'selected':selected,'called':called,'monitor':{'name':monitor.task_name,'running':monitor.is_running(),'closed':monitor._closed}}
 raw={'id':'container','layoutOptions':{'elk.algorithm':'radial','elk.radial.radius':s['radius'],'elk.radial.optimizationCriteria':s['strategy'],'elk.radial.sorter':'NONE','elk.radial.wedgeCriteria':'NODE_SIZE'},'children':[{k:v for k,v in n.items()if k!='position'}for n in s['nodes']],'edges':[{'id':'e'+str(i),'sources':['n'+str(a)],'targets':['n'+str(b)]}for i,(a,b)in enumerate(s['edges'])]}
 for n,item in zip(raw['children'],s['nodes']):n['layoutOptions']={'elk.position':'('+str(item['position'][0])+','+str(item['position'][1])+')'}
 state=JsonLayoutSession(raw);graph=state.graph;nodes=graph['children'];state.computed_options.setdefault(id(graph),{})['root']=nodes[0]
 def snapshot():
  result=[]
  for n in nodes:
   p=state.get_native_property(n,'position');result.append({'id':n['id'],'x':n['x'],'y':n['y'],'width':n['width'],'height':n['height'],'position':[p.x,p.y]})
  return result
 events=[];values=[];original=r.create_optimizer;types=[];before=snapshot();monitor=BasicProgressMonitor(False,False)
 def observing_factory(owner,strategy):
  obj=original(owner,strategy);events.append({'strategy':strategy,'isNull':obj is None});types.append(None if obj is None else type(obj).__name__)
  if obj is not None:
   evaluate=obj.evaluate
   def observing_evaluate(root):
    value=evaluate(root);values.append(value);return value
   obj.evaluate=observing_evaluate
  return obj
 r.create_optimizer=observing_factory
 try:r.eades_layout(state,graph,monitor)
 finally:r.create_optimizer=original
 return {'id':s['id'],'before':before,'after':snapshot(),'factoryEvents':events,'evaluations':values,'called':'radial.eades_layout','observerDelegatesOriginal':True,'monitor':{'name':monitor.task_name,'running':monitor.is_running(),'closed':monitor._closed},'nativeOptimizerTypes':types}
request=json.loads((OUT/'request.json').read_bytes());stage=sys.argv[1];sourcepath=OUT/('source-pilot.json'if stage=='pilot'else'source-final.json');source=json.loads(sourcepath.read_bytes())
assert source['workerSha256']=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86'and source['requestSha256']==sha(OUT/'request.json')and source['probeSha256']==sha(OUT/'probe.cjs')
indices=[0]if stage=='pilot'else list(range(1,len(request['cases'])));before=hashes();actual=[];rows=[]
for i in indices:
 try:value={'outcome':'returned','value':execute(request['cases'][i])}
 except Exception as error:value={'outcome':'threw','id':request['cases'][i]['id'],'error':{'name':type(error).__name__,'message':str(error)}}
 actual.append(value);expected=copy.deepcopy(source['value'][i]);projected=copy.deepcopy(value)
 if expected['outcome']=='returned':expected['value'].pop('called',None)
 if projected['outcome']=='returned':projected['value'].pop('called',None);projected['value'].pop('nativeOptimizerTypes',None)
 comparison=diff(expected,projected,tolerant=False);rows.append({'id':request['cases'][i]['id'],'comparison':comparison,'sourceIndex':i})
assert hashes()==before
record={'schema':'pyelk-e17-enum-owner-native/v1','passed':all(row['comparison']['passed']for row in rows),'actual':actual,'rows':rows,'sourceFilesSha256':before,'sourceFilesUnchanged':True,'sourceRawSha256':sha(sourcepath),'checkerSha256':sha(__file__),'requestSha256':sha(OUT/'request.json'),'scope':'Seven new enum-owner cases only; no old layout matrix or provider/public claim','roleSpecificCallableNamesProjected':True}
(OUT/('native-'+stage+'.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps({'passed':record['passed'],'cases':[{'id':row['id'],'differences':len(row['comparison']['differences'])}for row in rows]}));raise SystemExit(0 if record['passed']else 1)
