from pathlib import Path
import copy,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'scripts'))
from layout_checks import diff
load=lambda p:json.loads(Path(p).read_bytes())
def bind(p):
 p=Path(p);return {'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
source=load(OUT/'source-final.json');corrected=load(OUT/'source-constraint-corrected.json');pilot=load(OUT/'native-pilot.json');remaining=load(OUT/'native-remaining.json');request=load(OUT/'request.json')
publishedpath=ROOT/'docs/releases/evidence/published-0.1.0/wheel-installed.json';published=load(publishedpath)
assert pilot['sourceFilesUnchanged']and remaining['sourceFilesUnchanged']and len(remaining['sourceFilesSha256'])==196
for name,sha in remaining['sourceFilesSha256'].items():assert published['runtimeFilesSha256']['pyelk/'+name]==sha
assert source['requestSha256']==bind(OUT/'request.json')['sha256']and source['probeSha256']==bind(OUT/'probe.cjs')['sha256']
assert corrected['requestSha256']==bind(OUT/'constraint-request-corrected.json')['sha256']and corrected['probeSha256']==bind(OUT/'probe-constraint-corrected.cjs')['sha256']
rows=[]
for i,config in enumerate(request['cases']):
 src=corrected['value'][0]if i==1 else source['value'][i]
 nat=pilot['actual'][0]if i==0 else remaining['actual'][i-1]
 assert src['outcome']==nat['outcome']=='returned'
 expected=copy.deepcopy(src);actual=copy.deepcopy(nat)
 expected['value'].pop('called');actual['value'].pop('called');types=actual['value'].pop('nativeOptimizerTypes',None)
 full=diff(expected,actual,tolerant=False);v=src['value'];a=nat['value']
 row={'id':config['id'],'sourceRaw':bind(OUT/('source-constraint-corrected.json'if i==1 else'source-final.json')),'sourcePointer':'/value/0'if i==1 else'/value/'+str(i),'nativeRaw':bind(OUT/('native-pilot.json'if i==0 else'native-remaining.json')),'nativePointer':'/actual/'+str(0 if i==0 else i-1),'strictAllNumericComparison':full,'runtimeSelectionWitnessed':True}
 if config['kind']=='tree':
  assert full['passed']and not diff(v['before'],v['after'],tolerant=False)['passed']
  row.update(sourceFunction='NodeOrderer.process -> $process_99',nativeFunction='mrtree.order_nodes',rootChildrenBefore=v['before']['nodes'][0]['outgoing'],rootChildrenAfter=v['after']['nodes'][0]['outgoing'],monitor=v['monitor'],selectedFieldAloneIsNotEvidence=True)
 elif config['kind']=='routing':
  assert full['passed']and diff(v['before'],v['after'],tolerant=False)['passed']
  row.update(sourceFunction='$process_101 EdgeRouter NONE',nativeFunction='mrtree.route_edges',intentionalNoop=True,existingBendsRetained=v['after']['edges'][0]['bends'],monitor=v['monitor'])
 else:
  values=v['evaluations'];actual_values=a['evaluations'];count=0 if config['strategy']=='NONE'else 360
  assert v['factoryEvents']==a['factoryEvents']and len(values)==len(actual_values)==count
  expected['value'].pop('evaluations');actual['value'].pop('evaluations');geometry=diff(expected,actual,tolerant=False);assert geometry['passed']
  errors=[abs(x-y)for x,y in zip(values,actual_values)]
  first=min(range(count),key=lambda j:values[j])if count else None
  second=min(range(count),key=lambda j:actual_values[j])if count else None
  assert first==second
  row.update(sourceFunction='EadesRadial.process -> actual $create_12 and optimizer.evaluate',nativeFunction='radial.eades_layout -> actual create_optimizer and optimizer.evaluate',factoryEvents=v['factoryEvents'],nativeOptimizerTypes=types,evaluationCount=count,sourceObjectiveRange=[min(values),max(values)]if count else None,maximumObjectiveAbsoluteDifference=max(errors,default=0),minimumOffsetIndexSource=first,minimumOffsetIndexNative=second,finalGeometryAndControlStateStrict=geometry,objectivesExact=full['passed'],numericProfileUpgradeClaimed=False,objectiveDifferenceClassification='Exact'if full['passed']else'Finite binary64 edge-length sum roundoff; strict differences retained; final geometry and chosen offset exact',monitor=v['monitor'])
 rows.append(row)
result={'schema':'pyelk-e17-enum-runtime-handoff/v1','runtimeSelectionWitnesses':7,'rows':rows,'request':bind(OUT/'request.json'),'probe':bind(OUT/'probe.cjs'),'nativeChecker':bind(OUT/'compare.py'),'runner':bind(OUT/'run.py'),'savedChecker':bind(__file__),'sourceBatch':bind(OUT/'source-final.json'),'sourceBatchCommand':bind(OUT/'source-command.json'),'nativePilotCommand':bind(OUT/'native-pilot-command.json'),'nativeRemainingCommand':bind(OUT/'native-remaining-command.json'),'nativeRemainingFirstStrictExitCode':load(OUT/'native-remaining-command.json')['exitCode'],'sourceBatchFirstOutcomes':[{'id':c['id'],'outcome':r['outcome']}for c,r in zip(request['cases'],source['value'])],'sourceConstraintCorrection':{'request':bind(OUT/'constraint-request-corrected.json'),'probe':bind(OUT/'probe-constraint-corrected.cjs'),'raw':bind(OUT/'source-constraint-corrected.json'),'command':bind(OUT/'source-constraint-corrected-command/command.json'),'savedComparison':bind(OUT/'constraint-corrected-comparison.json'),'nativeRerun':False,'reason':'POSITION_CONSTRAINT_0 declares Integer; correct prepared setter valueOf_3, product unchanged'},'acceptedDistinctCases':7,'sourceBatchCalls':7,'sourceCorrectionCalls':1,'nativeCalls':7,'oldSamplesRerun':False,'publishedWheelPayloadBinding':{'receipt':bind(publishedpath),'artifactSha256':published['artifactSha256'],'all196ModuleHashesEqual':True,'distributionName':published.get('distributionName')},'allNewFilesIgnored':True,'runtimeSourceChanged':False,'exactObjectiveFailuresNotHidden':True,'universalOptionCombinationsClaimed':False}
(OUT/'handoff.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({'handoff':bind(OUT/'handoff.json'),'publishedArtifact':published['artifactSha256'],'rows':[{'id':r['id'],'fullExact':r['strictAllNumericComparison']['passed'],'objectiveError':r.get('maximumObjectiveAbsoluteDifference')}for r in rows]},indent=2))
