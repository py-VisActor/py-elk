const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),Module=require('node:module');
const[pkgArg,requestPath,outDir]=process.argv.slice(2),pkg=path.resolve(pkgArg),worker=path.join(pkg,'lib/elk-worker.js'),raw=fs.readFileSync(worker),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),requestRaw=fs.readFileSync(requestPath),request=JSON.parse(requestRaw);
if(sha(raw)!=='275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86')throw Error('worker differs');
const bridge=String.raw`
global.__e17case=function(s){
 const list=l=>{const a=[],it=l.iterator_0();while(it.hasNext_0())a.push(it.next_1());return a;},number=v=>v&&typeof v==='object'&&'value_0'in v?v.value_0:v;
 if(s.kind!=='radial'){
 $clinit_MrTreeOptions();$clinit_InternalProperties_2();$clinit_OrderWeighting();$clinit_EdgeRoutingMode();
 const g=new TGraph,nodes=[],edges=[];
 for(const[i,item]of s.nodes.entries()){const n=new TNode(i,g,'n'+i);[n.pos.x_0,n.pos.y_0]=item.pos||[0,0];[n.size_0.x_0,n.size_0.y_0]=item.size;if(i===0)$setProperty_0(n,ROOT_0,true);if(item.constraint!==undefined)$setProperty_0(n,POSITION_CONSTRAINT_0,valueOf_3(item.constraint));nodes.push(n);$add_7(g.nodes,n);}
 for(const[i,[a,b,bends]]of s.edges.entries()){const e=new TEdge_0(nodes[a],nodes[b]);$add_7(g.edges,e);$add_7(e.source.outgoingEdges,e);$add_7(e.target.incomingEdges,e);edges.push(e);for(const point of bends||[])$addLast_0(e.bendPoints,new KVector_1(...point));}
 const snapshot=()=>({nodes:nodes.map(n=>({id:n.id_0,position:[n.pos.x_0,n.pos.y_0],outgoing:list(n.outgoingEdges).map(e=>e.target.id_0),fan:number($getProperty(n,FAN)),descendants:number($getProperty(n,DESCENDANTS)),order:number($getProperty(n,POSITION_0))})),edges:edges.map(e=>({source:e.source.id_0,target:e.target.id_0,bends:list(e.bendPoints).map(p=>[p.x_0,p.y_0])}))});
 const monitor=new BasicProgressMonitor;
 if(s.kind==='tree'){$setProperty_0(g,WEIGHTING_0,s.weighting==='DESCENDANTS'?DESCENDANTS_0:CONSTRAINT);$process_89(new FanProcessor,g,new BasicProgressMonitor);const before=snapshot();const owner=new NodeOrderer;owner.process(g,monitor);return{id:s.id,before,after:snapshot(),selected:s.weighting,called:'NodeOrderer.process',monitor:{name:monitor.getTaskName()??null,running:monitor.isRunning(),closed:monitor.closed_0}};}
 $setProperty_0(g,EDGE_ROUTING_MODE_0,NONE_12);const before=snapshot();$process_101(g,monitor);return{id:s.id,before,after:snapshot(),selected:$getProperty(g,EDGE_ROUTING_MODE_0).name_0,called:'$process_101',monitor:{name:monitor.getTaskName()??null,running:monitor.isRunning(),closed:monitor.closed_0}};
 }
 $clinit_CoreOptions();$clinit_RadialOptions();$clinit_InternalProperties_3();$clinit_RadialTranslationStrategy();$clinit_SortingStrategy();$clinit_AnnulusWedgeCriteria();
 const graph=new ElkNodeImpl,nodes=s.nodes.map(item=>{const n=new ElkNodeImpl;n.x_0=item.x;n.y_0=item.y;n.width_0=item.width;n.height=item.height;$getChildren(graph).add_2(n);$setProperty_1(n,POSITION_2,new KVector_1(...item.position));return n;});
 for(const[a,b]of s.edges){const e=new ElkEdgeImpl;$getSources(e).add_2(nodes[a]);$getTargets(e).add_2(nodes[b]);}
 $setProperty_1(graph,ROOT_NODE,nodes[0]);$setProperty_1(graph,RADIUS_0,s.radius);$setProperty_1(graph,SORTER_0,NONE_15);$setProperty_1(graph,WEDGE_CRITERIA_0,NODE_SIZE_0);
 const strategy={NONE:NONE_14,EDGE_LENGTH:EDGE_LENGTH_0,EDGE_LENGTH_BY_POSITION,CROSSING_MINIMIZATION_BY_POSITION}[s.strategy];$setProperty_1(graph,OPTIMIZATION_CRITERIA_0,strategy);
 const snapshot=()=>nodes.map((n,i)=>({id:s.nodes[i].id,x:n.x_0,y:n.y_0,width:n.width_0,height:n.height,position:[castTo($getProperty_0(n,POSITION_2),8).x_0,castTo($getProperty_0(n,POSITION_2),8).y_0]}));
 const events=[],values=[],original=$create_12,before=snapshot(),owner=new EadesRadial,monitor=new BasicProgressMonitor;
 $create_12=function(value){const optimizer=original(value);events.push({strategy:value.name_0,isNull:optimizer===null});if(optimizer){const evaluate=optimizer.evaluate;optimizer.evaluate=function(root){const v=evaluate.call(optimizer,root);values.push(v);return v;};}return optimizer;};
 try{owner.process(graph,monitor);}finally{$create_12=original;}
 return{id:s.id,before,after:snapshot(),factoryEvents:events,evaluations:values,called:'EadesRadial.process',observerDelegatesOriginal:true,monitor:{name:monitor.getTaskName()??null,running:monitor.isRunning(),closed:monitor.closed_0}};
};`;
const m=new Module(worker,module);m.filename=worker;m.paths=Module._nodeModulePaths(pkg);m._compile(raw.toString()+bridge,worker);
const values=[];
function invoke(row){try{return{outcome:'returned',value:global.__e17case(row)};}catch(e){return{outcome:'threw',id:row.id,error:{name:String(e.name),message:String(e.message),stack:String(e.stack)}};}}
function save(name){fs.writeFileSync(path.join(outDir,name),JSON.stringify({workerSha256:sha(raw),probeSha256:sha(fs.readFileSync(__filename)),requestSha256:sha(requestRaw),pid:process.pid,parentPid:process.ppid,logging:false,value:values},null,2)+'\n',{flag:'wx'});}
values.push(invoke(request.cases[0]));save('source-constraint-corrected.json');console.log(JSON.stringify(values));
