"""Native async facade and instance-local metadata for the bounded ELK slice."""
from collections.abc import Mapping

from ._errors import (OptionValidationError, ResourceClosedError,
                      UnsupportedAlgorithmError, UnsupportedFeatureError,
                      UnsupportedWorkerError)
from ._json import clone_json, pointer
from .metadata import MetadataRegistry, classify_algorithm


class ELK:
    """Native bounded layered layout with isolated, cancellable execution.

    ``max_pending`` includes the running task; ``timeout`` covers submission
    through result, including queueing and process startup. The full reference
    catalogue is separate from this instance's implemented capability registry.
    """

    def __init__(self, options=None, *, max_pending=16, timeout=None):
        options = {} if options is None else options
        if not isinstance(options, Mapping):
            raise OptionValidationError("INVALID_OPTION_CONTAINER", "/constructor", "Expected a mapping")
        for key in options:
            if type(key) is not str:
                raise OptionValidationError("INVALID_JSON", "/constructor", "JSON object keys must be strings")
            if key in ("workerUrl", "workerFactory"):
                raise UnsupportedWorkerError("UNSUPPORTED_WORKER", pointer("/constructor", key),
                                             "JavaScript worker construction is unavailable in the native host")
            if key not in ("defaultLayoutOptions", "algorithms"):
                raise UnsupportedFeatureError("UNSUPPORTED_SLICE", pointer("/constructor", key),
                                              "Constructor capability is outside the reviewed slice")
        if "algorithms" in options and type(options["algorithms"]) is not list:
            raise OptionValidationError("INVALID_OPTION_VALUE", "/constructor/algorithms", "Expected a list of algorithm strings")
        self._options = clone_json(options, path="/constructor", error_type=OptionValidationError)
        self._registry = MetadataRegistry(self._options.get("algorithms", ["layered"]))
        if "algorithms" in self._options:
            self._options["algorithms"] = ["layered"] if self._registry.has_layered else []
        from .execution import ExecutionController

        self._controller = ExecutionController(self._options, max_pending=max_pending, timeout=timeout)
        self._closed = False
        self._last_trace = []
        self._submission = 0

    @property
    def last_trace(self):
        """An independent development trace, never part of returned ELK JSON."""
        return clone_json(self._last_trace)

    async def layout(self, graph, args=None):
        self._last_trace = []
        self._submission += 1
        submission = self._submission
        self._require_open()
        if not self._registry.has_layered:
            raise UnsupportedAlgorithmError("ALGORITHM_NOT_REGISTERED", "/constructor/algorithms",
                                            "The instance has no registered native layout algorithm")
        self._check_selected_algorithm(graph, args)
        result = await self._controller.execute(graph, args)
        if submission == self._submission and not self._closed:
            self._last_trace = clone_json(result.trace)
        return result.graph

    def _require_open(self):
        if self._closed:
            raise ResourceClosedError("RESOURCE_CLOSED", "", "The native instance is closed")

    def _check_selected_algorithm(self, graph, args):
        # Narrow error classification only. Existing resolver/context remain
        # responsible for containers, ambiguity, precedence and all other data.
        arguments = {} if args is None else args
        if not isinstance(arguments, Mapping):
            return
        defaults = self._options.get("defaultLayoutOptions", {})
        global_options = arguments.get("layoutOptions", defaults)
        local = graph.get("layoutOptions", {}) if isinstance(graph, Mapping) else {}
        scopes = [(global_options, "/layoutArguments/layoutOptions" if "layoutOptions" in arguments
                   else "/constructor/defaultLayoutOptions"), (local, "/local")]
        # Both selected scopes are parsed by the existing resolver, even when
        # a local value later replaces the global value. Only an explicit
        # call layoutOptions mapping removes the constructor defaults entirely.
        if any(not isinstance(options, Mapping) for options, _ in scopes):
            return
        for options, path in scopes:
            selectors = [key for key in ("elk.algorithm", "org.eclipse.elk.algorithm") if key in options]
            if len(selectors) > 1:
                return  # Keep the resolver's AMBIGUOUS_OPTION error.
            if selectors:
                key = selectors[0]
                classify_algorithm(options[key], pointer(path, key))

    async def knownLayoutAlgorithms(self):
        """Return independent descriptions of algorithms registered here."""
        self._require_open()
        return self._registry.algorithms()

    async def knownLayoutOptions(self):
        """Return nine implemented parser descriptions and layout restrictions."""
        self._require_open()
        return self._registry.options()

    async def knownLayoutCategories(self):
        """Return categories related to this instance's registered algorithms."""
        self._require_open()
        return self._registry.categories()

    def terminateWorker(self):
        """Close idempotently and synchronously reclaim native execution work."""
        self._closed = True
        self._submission += 1
        self._last_trace = []
        self._controller.close()
