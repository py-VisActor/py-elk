# SPDX-License-Identifier: EPL-2.0 OR GPL-3.0-or-later
# Mechanical port from elkjs 0.12.1 generated lib/elk-worker.js.
# Upstream commit: 624ae90aa37110033a8af59c5ccbb292708b4317
# Worker SHA256: 275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86
# Sources: references/e07-source-components-A.json, direction:mirror-x/y/transpose.
# Exact external Java build is unresolved. See _licenses/NOTICE-E07.md.
"""Reviewed READING_DIRECTION GraphTransformer pre/post kernels.

The generated factory deliberately assigns TO_INPUT_DIRECTION to PRE and
TO_INTERNAL_LTR to POST. Both operate on the real intermediate graph; no final
JSON rotation, graph-DIRECTION rewrite or component packing happens here.
"""
from __future__ import annotations

import math

from ..._errors import UnsupportedFeatureError
from .graph import Insets, LGraph, LNode, Vec2
from .long_edges import get_junction_points

_ASPECT_RATIO_DEFAULT = 1.600000023841858
_DIRECTIONS = {"RIGHT", "LEFT", "DOWN", "UP"}


def _outside(message):
    raise UnsupportedFeatureError("UNSUPPORTED_PHASE_INPUT", "", message)


def _finite(value):
    try:
        return type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        return False


def _vector(value):
    return isinstance(value, Vec2) and _finite(value.x) and _finite(value.y)


def _insets(value):
    return isinstance(value, Insets) and all(
        _finite(getattr(value, key)) for key in ("top", "right", "bottom", "left")
    )


def resolve_direction(direction: str) -> str:
    """Source getDirection_1 with the reviewed, fixed Layered aspect default."""
    if direction == "UNDEFINED":
        return "RIGHT" if _ASPECT_RATIO_DEFAULT >= 1 else "DOWN"
    if direction not in _DIRECTIONS:
        _outside("Unknown layout direction")
    return direction


def from_direction(direction: str) -> str:
    """Source PortSide.fromDirection; importer resolves UNDEFINED first."""
    result = {"RIGHT": "EAST", "LEFT": "WEST", "DOWN": "SOUTH", "UP": "NORTH",
              "UNDEFINED": "UNDEFINED"}
    if direction not in result:
        _outside("Unknown layout direction")
    return result[direction]


def get_node_labels_padding(element: LGraph | LNode) -> Insets:
    """Concrete ElkPadding default clone/store; current object stays shared."""
    if not isinstance(element, (LGraph, LNode)):
        _outside("Label padding requires a graph or node property holder")
    value = element.properties.get("NODE_LABELS_PADDING")
    if value is None:
        value = Insets(5, 5, 5, 5)
        element.properties["NODE_LABELS_PADDING"] = value
    if not _insets(value):
        _outside("Label padding must be a finite Insets object")
    return value


def get_node_size_minimum(node: LNode) -> Vec2:
    """Concrete KVector(0,0) default clone/store, independently per holder."""
    if not isinstance(node, LNode):
        _outside("Minimum size requires a node property holder")
    value = node.properties.get("NODE_SIZE_MINIMUM")
    if value is None:
        value = Vec2(0, 0)
        node.properties["NODE_SIZE_MINIMUM"] = value
    if not _vector(value):
        _outside("Minimum size must be a finite Vec2 object")
    return value


def _nodes(graph):
    if not isinstance(graph, LGraph):
        _outside("Direction transformation requires LGraph")
    nodes = list(graph.layerless_nodes)
    for layer in graph.layers:
        if layer.graph is not graph:
            _outside("Layer ownership differs")
        nodes.extend(layer.nodes)
    if len(nodes) > 8 or len(set(nodes)) != len(nodes):
        _outside("Direction PRE/POST requires at most eight restored original nodes")
    if graph.properties.get("DIRECTION") not in _DIRECTIONS:
        _outside("Direction must have been resolved by global prepare")
    if graph.properties.get("DIRECTION_CONGRUENCY", "READING_DIRECTION") != "READING_DIRECTION":
        _outside("Only default READING_DIRECTION congruency is reviewed")
    if not _vector(graph.size) or not _vector(graph.offset) or not _insets(graph.padding):
        _outside("Graph frame must be finite")
    if "NODE_LABELS_PADDING" in graph.properties and not _insets(graph.properties["NODE_LABELS_PADDING"]):
        _outside("Stored graph label padding must be finite")
    if graph.properties.get("EDGE_LABELS_SIDE_SELECTION", "SMART_DOWN") not in {"SMART_DOWN", "SMART_UP"}:
        _outside("Only default-derived edge label side selection is reviewed")
    members, ports, edges = set(nodes), set(), set()
    for node in nodes:
        if node.graph is not graph or node.type != "NORMAL":
            _outside("Direction PRE/POST requires restored NORMAL nodes")
        if not all(_vector(v) for v in (node.pos, node.size)) or not all(_insets(v) for v in (node.margin, node.padding)):
            _outside("Node geometry must be finite")
        if node.size.x < 0 or node.size.y < 0:
            _outside("Node sizes must be nonnegative")
        if "POSITION" in node.properties or node.properties.get("ALIGNMENT", "UNDEFINED") != "UNDEFINED":
            _outside("Explicit node position/alignment is outside the reviewed direction domain")
        if "NODE_LABELS_PLACEMENT" in node.properties:
            placement = node.properties["NODE_LABELS_PLACEMENT"]
            if type(placement) not in (set, frozenset) or placement:
                _outside("Only absent or empty node label placement is reviewed")
        if "NODE_SIZE_MINIMUM" in node.properties and not _vector(node.properties["NODE_SIZE_MINIMUM"]):
            _outside("Stored node minimum must be a finite vector")
        for port in node.ports:
            if port in ports or port.owner is not node or port.origin is not None:
                _outside("Each implicit port must retain one node owner")
            ports.add(port)
            if port.side not in {"NORTH", "EAST", "SOUTH", "WEST"} or "PORT_INDEX" in port.properties:
                _outside("Only implicit default-index ports are reviewed")
            if not all(_vector(v) for v in (port.pos, port.size, port.anchor)) or port.size.x != 0 or port.size.y != 0:
                _outside("Only finite zero-size implicit ports are reviewed")
            if len(port.incoming_edges) + len(port.outgoing_edges) != 1:
                _outside("Implicit endpoint ports must have exactly one edge")
            for edge in port.outgoing_edges:
                if edge in edges or edge.source is not port or edge.target is None:
                    _outside("Outgoing adjacency differs")
                if edge.target.owner not in members or edge.target not in edge.target.owner.ports or edge not in edge.target.incoming_edges:
                    _outside("Target endpoint differs")
                if not all(_vector(point) for point in edge.bend_points):
                    _outside("Bend points must be finite vectors")
                if "JUNCTION_POINTS" in edge.properties:
                    points = edge.properties["JUNCTION_POINTS"]
                    if type(points) is not list or not all(_vector(point) for point in points):
                        _outside("Stored junction points must be a vector chain")
                edges.add(edge)
            for edge in port.incoming_edges:
                if edge.target is not port or edge.source is None or edge.source.owner not in members or edge.source not in edge.source.owner.ports or edge not in edge.source.outgoing_edges:
                    _outside("Incoming endpoint differs")
    if len(edges) > 28 or len(ports) != 2 * len(edges):
        _outside("Direction PRE/POST requires at most 28 restored original edges")
    return nodes


def _set_side(port, side):
    # Generated LPort.explicitlySuppliedPortAnchor=false for this admitted domain.
    # Source setter changes no owner, adjacency or side-index cache.
    port.side = side
    if side == "NORTH":
        port.anchor.x, port.anchor.y = port.size.x / 2, 0
    elif side == "EAST":
        port.anchor.x, port.anchor.y = port.size.x, port.size.y / 2
    elif side == "SOUTH":
        port.anchor.x, port.anchor.y = port.size.x / 2, port.size.y
    elif side == "WEST":
        port.anchor.x, port.anchor.y = 0, port.size.y / 2


def _mirror_insets(value, axis):
    if axis == "x":
        old_left, old_right = value.left, value.right
        value.left, value.right = old_right, old_left
    else:
        old_top, old_bottom = value.top, value.bottom
        value.top, value.bottom = old_bottom, old_top


def _mirror(graph, nodes, axis):
    offset = 0
    if getattr(graph.size, axis) == 0:
        for node in nodes:
            margin = node.margin.right if axis == "x" else node.margin.bottom
            offset = max(offset, getattr(node.pos, axis) + getattr(node.size, axis) + margin)
    else:
        offset = getattr(graph.size, axis) - getattr(graph.offset, axis)
    offset -= getattr(graph.offset, axis)
    sides = {"EAST": "WEST", "WEST": "EAST"} if axis == "x" else {"NORTH": "SOUTH", "SOUTH": "NORTH"}
    for node in nodes:
        setattr(node.pos, axis, (offset - getattr(node.size, axis)) - getattr(node.pos, axis))
        _mirror_insets(node.padding, axis)
        for port in node.ports:
            setattr(port.pos, axis, (getattr(node.size, axis) - getattr(port.size, axis)) - getattr(port.pos, axis))
            setattr(port.anchor, axis, getattr(port.size, axis) - getattr(port.anchor, axis))
            _set_side(port, sides.get(port.side, port.side))
            for edge in port.outgoing_edges:
                for point in edge.bend_points:
                    setattr(point, axis, offset - getattr(point, axis))
                for point in get_junction_points(edge):
                    setattr(point, axis, offset - getattr(point, axis))
    _mirror_insets(graph.padding, axis)
    _mirror_insets(get_node_labels_padding(graph), axis)


def _transpose_vector(value):
    old_x = value.x
    value.x = value.y
    value.y = old_x


def _transpose_insets(value):
    old_top, old_bottom, old_left, old_right = value.top, value.bottom, value.left, value.right
    value.top, value.bottom, value.left, value.right = old_left, old_right, old_top, old_bottom


def _transpose(graph, nodes):
    sides = {"NORTH": "WEST", "WEST": "NORTH", "SOUTH": "EAST", "EAST": "SOUTH"}
    for node in nodes:
        _transpose_vector(node.pos)
        _transpose_vector(node.size)
        _transpose_insets(node.padding)
        minimum = get_node_size_minimum(node)
        node.properties["NODE_SIZE_MINIMUM"] = Vec2(minimum.y, minimum.x)
        for port in node.ports:
            _transpose_vector(port.pos)
            _transpose_vector(port.anchor)
            _transpose_vector(port.size)
            _set_side(port, sides[port.side])
            for edge in port.outgoing_edges:
                for point in edge.bend_points:
                    _transpose_vector(point)
                for point in get_junction_points(edge):
                    _transpose_vector(point)
    old_side = graph.properties.get("EDGE_LABELS_SIDE_SELECTION", "SMART_DOWN")
    graph.properties["EDGE_LABELS_SIDE_SELECTION"] = {"SMART_DOWN": "SMART_UP", "SMART_UP": "SMART_DOWN"}[old_side]
    _transpose_vector(graph.offset)
    _transpose_vector(graph.size)
    _transpose_insets(graph.padding)
    _transpose_insets(get_node_labels_padding(graph))


def direction_preprocessor(graph: LGraph) -> None:
    """Source strategy ordinal0: actual GraphTransformer(TO_INPUT_DIRECTION)."""
    nodes = _nodes(graph)
    direction = graph.properties["DIRECTION"]
    if direction == "LEFT":
        _mirror(graph, nodes, "x")
    elif direction == "DOWN":
        _transpose(graph, nodes)
    elif direction == "UP":
        _mirror(graph, nodes, "y")
        _transpose(graph, nodes)


def direction_postprocessor(graph: LGraph) -> None:
    """Source strategy ordinal58: actual GraphTransformer(TO_INTERNAL_LTR)."""
    nodes = _nodes(graph)
    direction = graph.properties["DIRECTION"]
    if direction == "LEFT":
        _mirror(graph, nodes, "x")
    elif direction == "DOWN":
        _transpose(graph, nodes)
    elif direction == "UP":
        _transpose(graph, nodes)
        _mirror(graph, nodes, "y")
