"""Exact bounded registry, ownership and native metadata contract checks."""
import asyncio
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from pyelk import ELK
from pyelk._errors import (OptionValidationError, ResourceClosedError,
                           UnknownAlgorithmError, UnsupportedAlgorithmError,
                           UnsupportedWorkerError, UnsupportedFeatureError,
                           ValidationError)


def expected(mode="default"):
    return json.loads((ROOT / "references/e08-metadata-schema.json").read_bytes())["expectedQueries"][mode]


async def queries(instance):
    return {"algorithms": await instance.knownLayoutAlgorithms(),
            "options": await instance.knownLayoutOptions(),
            "categories": await instance.knownLayoutCategories()}


class NativeMetadataTests(unittest.TestCase):
    def instance(self, options=None, **kwargs):
        instance = ELK(options, **kwargs)
        self.addCleanup(instance.terminateWorker)
        return instance

    def test_default_queries_exact_frozen_native_shapes_and_reference_order(self):
        actual = asyncio.run(queries(self.instance()))
        self.assertEqual(actual, expected())
        self.assertEqual([len(actual[key]) for key in ("algorithms", "options", "categories")], [1, 9, 1])
        self.assertEqual(len(actual["algorithms"][0]["knownOptions"]), 8)
        self.assertNotIn("org.eclipse.elk.algorithm", actual["algorithms"][0]["knownOptions"])

    def test_empty_algorithm_instance_is_metadata_only_without_polluting_other_instances(self):
        empty = self.instance({"algorithms": []})
        full = self.instance()
        self.assertEqual(asyncio.run(queries(empty)), expected("algorithmsEmpty"))
        self.assertEqual(asyncio.run(queries(full)), expected())
        with self.assertRaises(UnsupportedAlgorithmError) as caught:
            asyncio.run(empty.layout(None))
        self.assertEqual((caught.exception.code, caught.exception.path),
                         ("ALGORITHM_NOT_REGISTERED", "/constructor/algorithms"))
        self.assertEqual(asyncio.run(queries(empty)), expected("algorithmsEmpty"))

    def test_aliases_and_duplicate_registration_are_normalized_without_changing_input(self):
        options = {"algorithms": ["layered", "org.eclipse.elk.layered", "layered"]}
        instance = self.instance(options)
        self.assertEqual(options["algorithms"], ["layered", "org.eclipse.elk.layered", "layered"])
        self.assertEqual(asyncio.run(queries(instance)), expected())
        options["algorithms"].clear()
        self.assertEqual(asyncio.run(queries(instance)), expected())

    def test_all_query_children_are_independent_across_calls_and_instances(self):
        first, second = self.instance(), self.instance()
        result = asyncio.run(queries(first))
        result["algorithms"][0]["knownOptions"].clear()
        result["algorithms"][0]["native"]["constraints"]["originalChildNodes"]["maximum"] = 999
        result["options"][0]["native"]["constraints"].clear()
        result["categories"][0]["knownLayouters"].append("invented")
        for instance in (first, second):
            self.assertEqual(asyncio.run(queries(instance)), expected())

    def test_closed_instance_rejects_all_queries_and_clears_trace(self):
        instance = self.instance()
        self.assertEqual(asyncio.run(queries(instance)), expected())
        instance.terminateWorker()
        for method in (instance.knownLayoutAlgorithms, instance.knownLayoutOptions, instance.knownLayoutCategories):
            with self.assertRaises(ResourceClosedError) as caught:
                asyncio.run(method())
            self.assertEqual((caught.exception.code, caught.exception.path), ("RESOURCE_CLOSED", ""))
        with self.assertRaises(ResourceClosedError):
            asyncio.run(instance.layout({"id": "g"}))
        self.assertEqual(instance.last_trace, [])
        self.assertIsNone(instance.terminateWorker())

    def test_metadata_excludes_unimplemented_features_and_separates_parsing_from_layout(self):
        result = asyncio.run(queries(self.instance()))
        algorithm = result["algorithms"][0]
        self.assertEqual(algorithm["supportedFeatures"], ["SELF_LOOPS", "MULTI_EDGES"])
        self.assertFalse(algorithm["native"]["constraints"]["compound"])
        self.assertEqual(algorithm["native"]["constraints"]["originalEdges"]["maximum"], 28)
        by_id = {row["id"]: row for row in result["options"]}
        seed = by_id["org.eclipse.elk.randomSeed"]["native"]
        self.assertEqual(seed["defaultValue"], 1)
        self.assertEqual(seed["constraints"]["layout"]["excludedValues"], [0])
        padding = by_id["org.eclipse.elk.padding"]["native"]
        self.assertTrue(padding["constraints"]["parsing"]["objectOrFourSideString"])
        self.assertTrue(padding["constraints"]["layout"]["fourSideStringOnly"])

    def test_reference_catalogue_denominators_remain_separate(self):
        for kind, count in (("algorithms", 12), ("options", 243), ("categories", 8)):
            self.assertEqual(len(json.loads((ROOT / ("references/metadata/" + kind + ".json")).read_bytes())), count)

    def test_constructor_algorithms_distinguish_unknown_known_unsupported_and_invalid(self):
        for values, category, code, path in ((["invented"], UnknownAlgorithmError, "UNKNOWN_ALGORITHM", "/constructor/algorithms/0"),
                (["layered", "force"], UnsupportedAlgorithmError, "UNSUPPORTED_ALGORITHM", "/constructor/algorithms/1"),
                (["org.eclipse.elk.box"], UnsupportedAlgorithmError, "UNSUPPORTED_ALGORITHM", "/constructor/algorithms/0"),
                ([1], OptionValidationError, "INVALID_OPTION_VALUE", "/constructor/algorithms/0"),
                (None, OptionValidationError, "INVALID_OPTION_VALUE", "/constructor/algorithms"),
                ("layered", OptionValidationError, "INVALID_OPTION_VALUE", "/constructor/algorithms")):
            with self.subTest(values=values), self.assertRaises(category) as caught:
                ELK({"algorithms": values})
            self.assertEqual((caught.exception.code, caught.exception.path), (code, path))

    def test_explicit_worker_fields_fail_without_invoking_user_functions(self):
        called = []
        for key, value in (("workerFactory", lambda: called.append(True)), ("workerUrl", None)):
            with self.assertRaises(UnsupportedWorkerError) as caught:
                ELK({key: value})
            self.assertIsInstance(caught.exception, NotImplementedError)
            self.assertIsInstance(caught.exception, UnsupportedFeatureError)
            self.assertIsInstance(caught.exception, ValidationError)
            self.assertEqual(caught.exception.path, "/constructor/" + key)
        self.assertEqual(called, [])

    def test_unknown_constructor_field_uses_escaped_json_pointer(self):
        with self.assertRaises(UnsupportedFeatureError) as caught:
            ELK({"a/b~c": 1})
        self.assertEqual(caught.exception.path, "/constructor/a~1b~0c")


if __name__ == "__main__":
    unittest.main()
