"""Public diagnostics checked against fixed official observations, not itself."""
import copy
from pathlib import Path
import sys
import time
import unittest

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
if not sys.flags.isolated:sys.path.insert(0,str(ROOT/'src'))
from pyelk import ELK
from layout_checks import load
from validate_e09_coverage import RECORD, SUITE, decode_capture, unb64, digest, compare_case


class E09LoggingContractTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        cls.reference={x['definition']['id']:x for x in load(ROOT/RECORD)['cases']}

    async def observation(self,request_bytes):
        import json
        request=json.loads(request_bytes);graph=copy.deepcopy(request['graph']);options=copy.deepcopy(request['constructor']);args=copy.deepcopy(request['layoutArguments'])
        result={'schema':'py-elk-layout-observation/v1','requestSha256':digest(request_bytes),'engine':{'name':'pyelk'},
            'inputBefore':copy.deepcopy(graph),'constructorBefore':copy.deepcopy(options),'argumentsBefore':copy.deepcopy(args),
            'clock':{'startMs':time.time_ns()//1_000_000}}
        elk=ELK(options)
        try:result.update(outcome='returned',result=await elk.layout(graph,args))
        except Exception as error:result.update(outcome='threw',error={'name':type(error).__name__,'message':str(error)},
            errorDetails={k:getattr(error,k,None) for k in ('code','path','message')})
        finally:elk.terminateWorker()
        result['clock']['endMs']=time.time_ns()//1_000_000
        result.update(inputAfter=graph,constructorAfter=options,argumentsAfter=args,termination={'outcome':'returned'})
        return result

    async def test_four_flags_preserve_business_fields_and_match_fixed_source_tree(self):
        for suffix in ('00','10','01','11'):
            with self.subTest(flags=suffix):
                captured=self.reference['reserved-object-'+suffix];raw=unb64(captured['requestBytesBase64'])
                observed=await self.observation(raw)
                result=compare_case(captured['definition'],raw,decode_capture(captured['captures'][0]),observed)
                self.assertIs(result['passed'],True)
                self.assertEqual(observed['result']['executionTime'],321)
                self.assertEqual(observed['result']['business']['logging']['executionTime'],765)
                self.assertEqual(observed['result']['children'][0]['logging']['executionTime'],123)
                self.assertEqual(observed['result']['edges'][0]['logging']['executionTime'],456)

    async def test_all_three_negative_master_cases_keep_named_host_error_contract(self):
        for identifier in ('error-unknown-endpoint','error-unknown-algorithm','error-missing-graph'):
            with self.subTest(case=identifier):
                captured=self.reference[identifier];raw=unb64(captured['requestBytesBase64']);observed=await self.observation(raw)
                result=compare_case(captured['definition'],raw,decode_capture(captured['captures'][0]),observed)
                self.assertEqual(result['classification'],'expected-error')
                self.assertIs(result['passed'],True)
                self.assertIs(result['rawStrictPassed'],False)

    async def test_boolean_like_values_do_not_silently_enable_diagnostics(self):
        request=load(ROOT/SUITE/'host-checks.json')
        for definition in request['publicCases']:
            if not definition['id'].startswith(('logging-','measureExecutionTime-')):continue
            with self.subTest(case=definition['id']):
                elk=ELK();data=copy.deepcopy(definition['request'])
                try:
                    with self.assertRaises(Exception) as caught:await elk.layout(data['graph'],data['layoutArguments'])
                finally:elk.terminateWorker()
                error=caught.exception
                self.assertEqual({'name':type(error).__name__,**{k:getattr(error,k,None) for k in ('code','path','message')}},definition['expected']['error'])

if __name__=='__main__':unittest.main()
