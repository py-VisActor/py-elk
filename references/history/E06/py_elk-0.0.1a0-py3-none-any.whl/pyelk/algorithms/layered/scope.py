"""Host admission for the reviewed slice; historical E04 policy stays explicit."""
from dataclasses import dataclass

from ..._errors import UnsupportedFeatureError
from ..._json import pointer

MAX_NODES = 4
MAX_MEASURE = 1_000_000


@dataclass(frozen=True)
class SliceAdmission:
    node_count: int
    edge_count: int
    direction: str


def _outside(path, message):
    raise UnsupportedFeatureError("UNSUPPORTED_SLICE", path, message)


def _validate(context, *, maximum_nodes, dag, cyclic=False):
    """Reject unreviewed branches independently of fixture IDs or coordinates."""
    graph = context.original_graph
    options = context.resolved_options.values
    if options["org.eclipse.elk.direction"] not in ("RIGHT", "UNDEFINED"):
        _outside("/layoutOptions/elk.direction", "This slice reviews RIGHT and default direction only")
    if not options["org.eclipse.elk.separateConnectedComponents"]:
        _outside("/layoutOptions/elk.separateConnectedComponents", "This slice requires default component handling")
    if options["org.eclipse.elk.randomSeed"] == 0:
        _outside("/layoutOptions/elk.randomSeed", "This slice requires an explicit deterministic seed branch")
    for key, value in options.items():
        if "spacing." in key and value > MAX_MEASURE:
            _outside("/layoutOptions/" + key, "Spacing exceeds the reviewed numeric domain")
    padding = options["org.eclipse.elk.padding"]
    # E03's Mapping parser is a host convenience. The fixed JSON importer
    # rejects an object-valued padding option, so this same-byte slice does too.
    raw_padding = context.resolved_options.raw_values.get("org.eclipse.elk.padding")
    if raw_padding is not None and type(raw_padding) is not str:
        _outside("/layoutOptions/elk.padding", "This slice requires the reference-compatible padding string")
    if any(getattr(padding, side) > MAX_MEASURE for side in ("top", "right", "bottom", "left")):
        _outside("/layoutOptions/elk.padding", "Padding exceeds the reviewed numeric domain")
    for key, value in context.original_arguments.items():
        if key in ("logging", "measureExecutionTime") and (type(value) is not bool or value):
            _outside("/layoutArguments/" + key, "Logging/timing is outside this slice acceptance")
        if key not in ("layoutOptions", "logging", "measureExecutionTime"):
            _outside("/layoutArguments/" + key, "Unknown call argument is not reviewed for this slice")
    constructor = context.original_constructor
    if "algorithms" in constructor and constructor["algorithms"] != ["layered"]:
        _outside("/constructor/algorithms", "This slice only registers the reviewed layered slice")
    for key in constructor:
        if key not in ("defaultLayoutOptions", "algorithms"):
            _outside("/constructor/" + key, "Constructor capability is outside this slice")
    nodes, edges = graph.get("children", []), graph.get("edges", [])
    if cyclic and len(edges) > 28:
        _outside("/edges", "The reviewed multigraph domain has at most 28 original edges")
    if len(nodes) > maximum_nodes:
        _outside("/children", "The reviewed domain has at most " + str(maximum_nodes) + " child nodes")
    for key in ("x", "y", "width", "height"):
        if key in graph:
            _outside("/" + key, "Pre-existing root geometry uses a separate source branch")
    if "logging" in graph:
        _outside("/logging", "Existing log cleanup is outside the reviewed source slice")
    for owner, path in [(graph, ""), *[(node, "/children/" + str(i)) for i, node in enumerate(nodes)]]:
        if type(owner["id"]) is not str or not owner["id"]:
            _outside(pointer(path, "id"), "This slice requires nonempty string identities")
        if "$H" in owner:
            _outside(pointer(path, "$H"), "Existing reference identity-cache fields are outside this slice")
        if "properties" in owner:
            _outside(pointer(path, "properties"), "Legacy option containers require a separate source branch")
        for key in ("ports", "labels"):
            if owner.get(key):
                _outside(pointer(path, key), "Explicit shape capability is outside this slice")
        if path:
            for key in ("children", "edges", "layoutOptions"):
                if owner.get(key):
                    _outside(pointer(path, key), "Child-local capability is outside this slice")
            for key in ("width", "height"):
                if key not in owner or owner[key] > MAX_MEASURE:
                    _outside(pointer(path, key), "Given dimensions must lie within the reviewed domain")
            for key in ("x", "y"):
                if key in owner:
                    _outside(pointer(path, key), "Pre-existing node positions are outside this slice")
    by_id = {node["id"] for node in nodes}
    outgoing, incoming, pairs = {}, {}, set()
    for index, edge in enumerate(edges):
        path = "/edges/" + str(index)
        if type(edge["id"]) is not str or not edge["id"]:
            _outside(pointer(path, "id"), "This slice requires nonempty edge identities")
        if "properties" in edge:
            _outside(pointer(path, "properties"), "Legacy option containers are outside this slice")
        for key in ("sections", "junctionPoints", "bendPoints", "startPoint", "endPoint", "sourcePoint", "targetPoint", "container"):
            if key in edge:
                _outside(pointer(path, key), "Pre-existing edge geometry requires a different source branch")
        for key in ("labels", "layoutOptions"):
            if edge.get(key):
                _outside(pointer(path, key), "Existing routing or edge-local capability is outside this slice")
        sources, targets = edge["sources"], edge["targets"]
        if len(sources) != 1 or len(targets) != 1 or sources[0] not in by_id or targets[0] not in by_id:
            _outside(path, "This slice requires child-node single-source/target edges")
        source, target = sources[0], targets[0]
        if not cyclic and (source == target or (source, target) in pairs):
            _outside(path, "Self loops and parallel edges require a different source branch")
        pairs.add((source, target))
        if not dag and not cyclic and (source in outgoing or target in incoming):
            _outside(path, "This slice requires a simple directed path")
        outgoing.setdefault(source, []).append(target)
        incoming.setdefault(target, []).append(source)
    if not dag and not cyclic and len(edges) != max(0, len(nodes) - 1):
        _outside("/edges", "This slice requires one connected path, or an empty graph")
    if nodes and (dag or cyclic):
        # Boolean admission only: no ranks/layers are produced or consumed by
        # the actual NETWORK_SIMPLEX implementation.
        if dag:
            degrees = {node["id"]: len(incoming.get(node["id"], [])) for node in nodes}
            queue = [node["id"] for node in nodes if degrees[node["id"]] == 0]
            cursor = 0
            while cursor < len(queue):
                current = queue[cursor]
                cursor += 1
                for target in outgoing.get(current, []):
                    degrees[target] -= 1
                    if degrees[target] == 0:
                        queue.append(target)
            if cursor != len(nodes):
                _outside("/edges", "E05 excludes directed cycles")
        visited, pending = set(), [nodes[0]["id"]]
        while pending:
            current = pending.pop()
            if current not in visited:
                visited.add(current)
                pending.extend(outgoing.get(current, []))
                pending.extend(incoming.get(current, []))
        if visited != by_id:
            _outside("/edges", "This slice reviews a single weakly connected component")
    elif nodes:
        starts = [identity for identity in by_id if identity not in incoming]
        if len(starts) != 1:
            _outside("/edges", "This slice excludes cycles and disconnected nodes")
        visited, current = set(), starts[0]
        while current not in visited:
            visited.add(current)
            if current not in outgoing:
                break
            current = outgoing[current][0]
        if visited != by_id:
            _outside("/edges", "This slice requires a connected acyclic path")
    return SliceAdmission(len(nodes), len(edges), options["org.eclipse.elk.direction"])


def validate_e04_slice(context):
    """Frozen E04 admission policy, retained for its historical controls."""
    return _validate(context, maximum_nodes=4, dag=False)


def validate_e05_slice(context):
    """Source-reviewed E05 host admission; this function computes no layout."""
    return _validate(context, maximum_nodes=8, dag=True)


def validate_e06_slice(context):
    """Source-reviewed multigraph admission; this function computes no layout."""
    return _validate(context, maximum_nodes=8, dag=False, cyclic=True)


def validate_slice(context):
    """Current admission after the complete 27-component E06 source gate."""
    return validate_e06_slice(context)
