"""Native Python ELK port with an experimental source-reviewed layered slice.

The target behavior is elkjs 0.12.1. No Node/JVM/renderer is imported, and no
full algorithm/API/release compatibility is implied by this experimental slice.
"""

__version__ = "0.0.1a0"

from .api import ELK

__all__ = ["__version__", "ELK"]
