"""Experimental E04 host connection, exported only with a real accepted slice.

The async method runs the bounded CPU work on its caller's thread. It does not
claim scheduling isolation, CPU parallelism or cancellation guarantees.
"""
from collections.abc import Mapping

from ._errors import OptionValidationError, UnsupportedFeatureError
from ._json import clone_json
from .execution import create_context
from .algorithms.layered.scope import validate_slice


class ELK:
    """Native, worker-free experimental facade for the reviewed E04 slice."""

    def __init__(self, options=None):
        options = {} if options is None else options
        if not isinstance(options, Mapping):
            raise OptionValidationError("INVALID_OPTION_CONTAINER", "/constructor", "Expected a mapping")
        for key in options:
            if key not in ("defaultLayoutOptions", "algorithms"):
                raise UnsupportedFeatureError("UNSUPPORTED_SLICE", "/constructor/" + str(key),
                                              "Constructor capability is outside E04")
        if "algorithms" in options and (type(options["algorithms"]) is not list or options["algorithms"] != ["layered"]):
            raise UnsupportedFeatureError("UNSUPPORTED_SLICE", "/constructor/algorithms", "Only the reviewed layered slice is available")
        self._options = clone_json(options, path="/constructor", error_type=OptionValidationError)
        self._closed = False
        self._last_trace = []

    @property
    def last_trace(self):
        """An independent development trace, never part of returned ELK JSON."""
        return clone_json(self._last_trace)

    async def layout(self, graph, args=None):
        self._last_trace = []
        if self._closed:
            raise UnsupportedFeatureError("RESOURCE_CLOSED", "", "The native instance is closed")
        context = create_context(graph, constructor=self._options, layout_arguments=args)
        validate_slice(context)
        # The implementation is imported only when real layout is requested.
        # Missing implementation remains an error, never an oracle fallback.
        from .algorithms.layered.pipeline import layout_context

        trace = []
        self._last_trace = trace
        return layout_context(context, trace=trace)

    def terminateWorker(self):
        """Idempotent local close; there is no worker or background process."""
        self._closed = True
