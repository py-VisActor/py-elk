# SPDX-License-Identifier: EPL-2.0 OR GPL-3.0-or-later
# Dispatch of the reviewed elkjs 0.12.1 generated-worker default chain.
# Source commit: 624ae90aa37110033a8af59c5ccbb292708b4317
# Worker SHA256: 275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86
# Source order: references/layered-default-path.json; component approvals:
# references/e04-component-approvals.json. See pyelk/_licenses/NOTICE.md.
"""Real source-reviewed dispatch; traces observe work and never choose layout."""
from .graph import Insets, LEdge, LNode, LPort, Layer, Vec2
from .scope import validate_slice

PROCESSOR_SEQUENCE = (
    "EdgeAndLayerConstraintEdgeReverser", "GreedyCycleBreaker", "LayerConstraintPreprocessor",
    "NetworkSimplexLayerer", "LayerConstraintPostprocessor", "LongEdgeSplitter", "PortSideProcessor",
    "PortListSorter", "LayerSweepCrossingMinimizer", "LayerSweepCrossingMinimizer",
    "InLayerConstraintProcessor", "LabelAndNodeSizeProcessor", "InnermostNodeMarginCalculator",
    "BKNodePlacer", "LayerSizeAndGraphHeightCalculator", "OrthogonalEdgeRouter", "LongEdgeJoiner",
    "EndLabelSorter", "ReversedEdgeRestorer",
)


def _node_name(node):
    return node.origin.id if node.origin is not None else "temporary:" + str(node.id)


def _trace_value(value):
    if value is None or type(value) in (str, int, float, bool):
        return value
    if isinstance(value, Vec2):
        return {"x": value.x, "y": value.y}
    if isinstance(value, Insets):
        return {side: getattr(value, side) for side in ("top", "right", "bottom", "left")}
    if isinstance(value, LNode):
        return {"node": _node_name(value)}
    if isinstance(value, LPort):
        return {"port": value.id, "node": _node_name(value.owner) if value.owner else None}
    if isinstance(value, LEdge):
        return {"edge": value.origin.id if value.origin else value.id}
    if isinstance(value, Layer):
        return {"layer": value.id}
    if isinstance(value, dict):
        return {key if type(key) is str else str(_trace_value(key)): _trace_value(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [_trace_value(child) for child in value]
    # Development-only markers for other support objects; never repr addresses.
    return {"supportType": type(value).__name__}


def snapshot(graph):
    nodes, seen = [], set()
    for node in [*graph.layerless_nodes, *(node for layer in graph.layers for node in layer.nodes)]:
        if id(node) not in seen:
            nodes.append(node)
            seen.add(id(node))
    return {"layerless": [_node_name(node) for node in graph.layerless_nodes],
            "layers": [{"id": layer.id, "nodes": [_node_name(node) for node in layer.nodes], "size": _trace_value(layer.size)}
                       for layer in graph.layers],
            "nodes": [{"originId": _node_name(node), "id": node.id, "type": node.type,
                       "pos": _trace_value(node.pos), "size": _trace_value(node.size), "margin": _trace_value(node.margin),
                       "properties": _trace_value(node.properties), "portSidesCached": node.port_sides_cached,
                       "portSideIndices": _trace_value(node.port_side_indices),
                       "ports": [{"id": port.id, "side": port.side, "pos": _trace_value(port.pos),
                                  "size": _trace_value(port.size), "anchor": _trace_value(port.anchor),
                                  "incoming": [edge.origin.id if edge.origin else edge.id for edge in port.incoming_edges],
                                  "outgoing": [edge.origin.id if edge.origin else edge.id for edge in port.outgoing_edges]}
                                 for port in node.ports]} for node in nodes],
            "size": _trace_value(graph.size), "offset": _trace_value(graph.offset), "padding": _trace_value(graph.padding),
            "random": None if graph.random is None else {"state48": graph.random.state48, "primitiveDraws": graph.random.primitive_draws}}


def layout_context(context, *, trace=None):
    from .import_export import export_layout, import_graph
    from .phases import (JavaRandom, bk_node_placer, greedy_cycle_breaker, layer_sweep,
                         network_simplex_layerer, orthogonal_edge_router)
    from .processors import INTERMEDIATE_PROCESSORS

    admitted = validate_slice(context)
    work = import_graph(context, None if admitted.node_count == 0 else JavaRandom(context.seed))
    if admitted.node_count == 0:
        # The fixed recursion does not invoke LayeredLayoutProvider for a leaf.
        # The exporter still transfers default Ecore geometry for this branch.
        return export_layout(work)
    expected_intermediates = set(PROCESSOR_SEQUENCE) - {
        "GreedyCycleBreaker", "NetworkSimplexLayerer", "LayerSweepCrossingMinimizer", "BKNodePlacer", "OrthogonalEdgeRouter"}
    if set(INTERMEDIATE_PROCESSORS) != expected_intermediates:
        raise RuntimeError("Intermediate registry differs from reviewed default chain")
    main = {"GreedyCycleBreaker": greedy_cycle_breaker, "NetworkSimplexLayerer": network_simplex_layerer,
            "BKNodePlacer": bk_node_placer, "OrthogonalEdgeRouter": orthogonal_edge_router}
    sweep = 0
    for index, name in enumerate(PROCESSOR_SEQUENCE):
        strategy = None
        if name == "LayerSweepCrossingMinimizer":
            strategy = ("BARYCENTER", "TWO_SIDED_GREEDY_SWITCH")[sweep]
            sweep += 1
            operation = lambda graph, mode=strategy: layer_sweep(graph, strategy=mode)
        else:
            operation = main[name] if name in main else INTERMEDIATE_PROCESSORS[name]
        entry = None
        if trace is not None:
            entry = {"index": index, "processor": name, "strategy": strategy, "before": snapshot(work)}
            trace.append(entry)
        try:
            operation(work)
        except Exception as error:
            if entry is not None:
                entry.update(outcome="threw", error={"type": type(error).__name__, "message": str(error)})
            raise
        if entry is not None:
            entry.update(outcome="returned", after=snapshot(work))
    # Export owns cleanup, single-component merge/offset and source-order resize.
    return export_layout(work)
