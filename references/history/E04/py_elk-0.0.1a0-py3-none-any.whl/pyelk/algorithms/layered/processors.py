# SPDX-License-Identifier: EPL-2.0 OR GPL-3.0-or-later
# Constrained port of elkjs 0.12.1 generated lib/elk-worker.js.
# Upstream commit: 624ae90aa37110033a8af59c5ccbb292708b4317
# Worker SHA256: 275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86
# Component/guard map: references/e04-source-components-A.json
# Exact external Java build is unresolved. See pyelk/_licenses/NOTICE.md.
"""Thirteen real intermediate branches admitted by ADR-0003.

Inactive constraint/dummy/label branches are checked explicitly. Port side,
ordering/cache, fixed-size placement, margins and bounds retain their real
source writes. The reviewed node-spacing def-use reduction is not a no-op.
"""
import math

from ..._errors import UnsupportedFeatureError
from .graph import Layer

_SIDE_ORDER = {"NORTH": 0, "EAST": 1, "SOUTH": 2, "WEST": 3}


def _outside(message):
    raise UnsupportedFeatureError("UNSUPPORTED_PROCESSOR_INPUT", "", message)


def _nodes(graph):
    if graph.properties.get("DIRECTION", "RIGHT") != "RIGHT" or graph.properties.get("GRAPH_PROPERTIES"):
        _outside("Direction transforms/advanced graph properties require another source slice")
    nodes = [*graph.layerless_nodes, *(node for layer in graph.layers for node in layer.nodes)]
    if len(nodes) > 4 or len({id(n) for n in nodes}) != len(nodes):
        _outside("The reviewed representation has at most four distinct nodes")
    for node in nodes:
        if node.type != "NORMAL" or node.graph is not graph:
            _outside("The reviewed branch has original normal nodes in one graph")
        if any(type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 1_000_000
               for value in (node.size.x, node.size.y)):
            _outside("Given dimensions exceed the reviewed numeric domain")
        if node.properties.get("LAYER_CONSTRAINT", "NONE") != "NONE":
            _outside("Layer constraints require their full source branches")
        for port in node.ports:
            if port.owner is not node or port.origin is not None:
                _outside("Only correctly owned implicit ports are reviewed")
    return nodes


def edge_and_layer_constraint_edge_reverser(graph):
    remaining = []
    for node in _nodes(graph):
        if node.properties.get("LAYER_CONSTRAINT", "NONE") == "NONE":
            remaining.append(node)
    for node in remaining:
        if node.properties.get("PORT_CONSTRAINTS", "FREE") not in ("FREE", "UNDEFINED"):
            _outside("Pre-layout fixed ports require the full reversal branch")
        # Both actual node passes execute. No layer constraint and free ports
        # guard out reverseEdges, rather than replacing the whole stage by pass.


def layer_constraint_preprocessor(graph):
    hidden = []
    for node in _nodes(graph):
        constraint = node.properties.get("LAYER_CONSTRAINT", "NONE")
        if constraint in ("FIRST_SEPARATE", "LAST_SEPARATE"):
            _outside("Hidden constrained nodes require a wider source slice")
    if hidden:
        graph.properties["HIDDEN_NODES"] = hidden


def layer_constraint_postprocessor(graph):
    _nodes(graph)
    if graph.layers:
        # The real source creates these temporary layers even when no node
        # constraint requests a move into them.
        first_labels, last_labels = Layer(graph), Layer(graph)
        for layer in list(graph.layers):
            for node in list(layer.nodes):
                if node.properties.get("LAYER_CONSTRAINT", "NONE") != "NONE":
                    _outside("First/last constraint node moves are not reviewed")
        if first_labels.nodes:
            graph.layers.insert(0, first_labels)
        if last_labels.nodes:
            graph.layers.append(last_labels)
        graph.layers[:] = [layer for layer in graph.layers if layer.nodes]
    if "HIDDEN_NODES" in graph.properties:
        _outside("Hidden node restoration is outside this slice")


def long_edge_splitter(graph):
    _nodes(graph)
    if len(graph.layers) <= 2:
        return  # Worker process35 has this exact early return.
    for layer, next_layer in zip(graph.layers, graph.layers[1:]):
        for node in layer.nodes:
            for port in node.ports:
                for edge in port.outgoing_edges:
                    if edge.target.owner.layer not in (layer, next_layer):
                        _outside("A nonadjacent edge requires actual dummy splitting")


def _set_side(port, side):
    port.side = side
    if side == "EAST":
        port.anchor.x, port.anchor.y = port.size.x, port.size.y / 2
    elif side == "WEST":
        port.anchor.x, port.anchor.y = 0.0, port.size.y / 2
    else:
        _outside("Only flow-side implicit ports are reviewed")


def port_side_processor(graph):
    for node in _nodes(graph):
        constraint = node.properties.get("PORT_CONSTRAINTS", "FREE")
        if constraint not in ("FREE", "UNDEFINED", "FIXED_SIDE", "FIXED_ORDER"):
            _outside("Fixed-ratio/position ports require another source branch")
        fixed = constraint in ("FIXED_SIDE", "FIXED_ORDER")
        for port in node.ports:
            if port.properties.get("PORT_DUMMY") is not None:
                _outside("Dummy ports require another source branch")
            if not fixed or port.side == "UNDEFINED":
                side = "EAST" if len(port.incoming_edges) - len(port.outgoing_edges) < 0 else "WEST"
                _set_side(port, side)
        if not fixed:
            node.properties["PORT_CONSTRAINTS"] = "FIXED_SIDE"


def port_list_sorter(graph):
    for node in _nodes(graph):
        if node.properties.get("PORT_CONSTRAINTS") != "FIXED_SIDE":
            _outside("This source branch expects the real side processor first")
        if any(port.side not in ("EAST", "WEST") for port in node.ports):
            _outside("Only implicit east/west side sorting is reviewed")
        node.ports.sort(key=lambda port: _SIDE_ORDER[port.side])
        for side in ("WEST", "SOUTH"):
            indices = [i for i, port in enumerate(node.ports) if port.side == side]
            if indices:
                lo, hi = indices[0], indices[-1] + 1
                node.ports[lo:hi] = reversed(node.ports[lo:hi])
        node.port_sides_cached = True
        ranges, first, current = {}, 0, "NORTH"
        for index, port in enumerate(node.ports):
            if port.side != current:
                if first != index:
                    ranges[current] = (first, index)
                current, first = port.side, index
        ranges[current] = (first, len(node.ports))
        node.port_side_indices = ranges


def in_layer_constraint_processor(graph):
    _nodes(graph)
    for layer in graph.layers:
        top_insertion, bottom = -1, []
        for index, node in enumerate(list(layer.nodes)):
            constraint = node.properties.get("IN_LAYER_CONSTRAINT", "NONE")
            if constraint != "NONE":
                _outside("TOP/BOTTOM reordering requires another source branch")
            if top_insertion == -1 and constraint != "TOP":
                top_insertion = index
        if bottom:
            _outside("Unexpected bottom-constrained nodes")


def label_and_node_size_processor(graph):
    for node in _nodes(graph):
        if (node.properties.get("NODE_SIZE_CONSTRAINTS")
                or node.properties.get("NODE_SIZE_OPTIONS", {"DEFAULT_MINIMUM_SIZE"}) != {"DEFAULT_MINIMUM_SIZE"}):
            _outside("The reviewed node-spacing def-use needs fixed given sizes")
        if node.properties.get("PORT_CONSTRAINTS") not in ("FIXED_SIDE", "FIXED_ORDER"):
            _outside("Side/order processing must precede node spacing")
        if any(sum(port.side == side for port in node.ports) > 1 for side in _SIDE_ORDER):
            _outside("The reviewed cell reduction has at most one port per side")
        width, height = node.size.x, node.size.y
        for index, port in enumerate(node.ports):
            if port.side not in ("EAST", "WEST") or port.size.x != 0 or port.size.y != 0:
                _outside("Only zero-size implicit flow-side ports are reviewed")
            if any(key in port.properties for key in ("PORT_BORDER_OFFSET", "PORT_ANCHOR")):
                _outside("Port border/anchor overrides require their full source branches")
            port.id = index  # Source createPortContexts sets volatile IDs per node.
            # NS-G1..G5: false contribution flags prevent the nonzero scratch
            # DISTRIBUTED minimum from enlarging the middle row. Single-port
            # normalization subtracts its two gaps, then the real CENTER branch
            # uses the given height, including zero.
            current_y = 0.0 + 0.0
            current_y += (height - 0.0) / 2
            port.pos.x = width if port.side == "EAST" else -port.size.x
            port.pos.y = current_y + 0.0
        node.size.x, node.size.y = width, height  # Real fixed-size setSize write.
        # No COMPUTE_PADDING: source setNodePadding returns without a write.


def innermost_node_margin_calculator(graph):
    for node in _nodes(graph):
        left, top = node.pos.x, node.pos.y
        right, bottom = left + node.size.x, top + node.size.y
        for port in node.ports:
            x, y = port.pos.x + node.pos.x, port.pos.y + node.pos.y
            left, top = min(left, x), min(top, y)
            right, bottom = max(right, x + port.size.x), max(bottom, y + port.size.y)
        node.margin.top = max(0.0, node.pos.y - top)
        node.margin.bottom = max(0.0, bottom - (node.pos.y + node.size.y))
        node.margin.left = max(0.0, node.pos.x - left)
        node.margin.right = max(0.0, right - (node.pos.x + node.size.x))


def layer_size_and_graph_height_calculator(graph):
    _nodes(graph)
    minimum_y, maximum_y, found = math.inf, -math.inf, False
    for layer in graph.layers:
        layer.size.x, layer.size.y = 0.0, 0.0
        if not layer.nodes:
            continue
        found = True
        for node in layer.nodes:
            layer.size.x = max(layer.size.x, node.size.x + node.margin.left + node.margin.right)
        first, last = layer.nodes[0], layer.nodes[-1]
        top = first.pos.y - first.margin.top
        bottom = last.pos.y + last.size.y + last.margin.bottom
        layer.size.y = bottom - top
        minimum_y, maximum_y = min(minimum_y, top), max(maximum_y, bottom)
    if not found:
        minimum_y, maximum_y = 0.0, 0.0
    graph.size.y = maximum_y - minimum_y
    graph.offset.y -= minimum_y


def long_edge_joiner(graph):
    for node in _nodes(graph):
        if node.type == "LONG_EDGE":
            _outside("Long-edge joining requires a wider source slice")


def end_label_sorter(graph):
    for node in _nodes(graph):
        if "END_LABELS" in node.properties:
            _outside("End-label cell initialization/sorting is not admitted")


def reversed_edge_restorer(graph):
    for node in _nodes(graph):
        for port in node.ports:
            for edge in list(port.outgoing_edges):
                if edge.properties.get("REVERSED", False):
                    _outside("Reversed-edge restoration needs a different source branch")


INTERMEDIATE_PROCESSORS = {
    "EdgeAndLayerConstraintEdgeReverser": edge_and_layer_constraint_edge_reverser,
    "LayerConstraintPreprocessor": layer_constraint_preprocessor,
    "LayerConstraintPostprocessor": layer_constraint_postprocessor,
    "LongEdgeSplitter": long_edge_splitter,
    "PortSideProcessor": port_side_processor,
    "PortListSorter": port_list_sorter,
    "InLayerConstraintProcessor": in_layer_constraint_processor,
    "LabelAndNodeSizeProcessor": label_and_node_size_processor,
    "InnermostNodeMarginCalculator": innermost_node_margin_calculator,
    "LayerSizeAndGraphHeightCalculator": layer_size_and_graph_height_calculator,
    "LongEdgeJoiner": long_edge_joiner,
    "EndLabelSorter": end_label_sorter,
    "ReversedEdgeRestorer": reversed_edge_restorer,
}
