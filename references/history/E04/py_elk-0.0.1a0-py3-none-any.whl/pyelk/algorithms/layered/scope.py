"""Host admission checks for the source-reviewed E04 slice, not a layout."""
from dataclasses import dataclass

from ..._errors import UnsupportedFeatureError
from ..._json import pointer

MAX_NODES = 4
MAX_MEASURE = 1_000_000


@dataclass(frozen=True)
class SliceAdmission:
    node_count: int
    edge_count: int
    direction: str


def _outside(path, message):
    raise UnsupportedFeatureError("UNSUPPORTED_SLICE", path, message)


def validate_slice(context):
    """Reject unreviewed branches independently of fixture IDs or coordinates."""
    graph = context.original_graph
    options = context.resolved_options.values
    if options["org.eclipse.elk.direction"] not in ("RIGHT", "UNDEFINED"):
        _outside("/layoutOptions/elk.direction", "E04 reviews RIGHT and default direction only")
    if not options["org.eclipse.elk.separateConnectedComponents"]:
        _outside("/layoutOptions/elk.separateConnectedComponents", "E04 requires default component handling")
    if options["org.eclipse.elk.randomSeed"] == 0:
        _outside("/layoutOptions/elk.randomSeed", "E04 requires an explicit deterministic seed branch")
    for key, value in options.items():
        if "spacing." in key and value > MAX_MEASURE:
            _outside("/layoutOptions/" + key, "Spacing exceeds the E04 reviewed numeric domain")
    padding = options["org.eclipse.elk.padding"]
    # E03's Mapping parser is a host convenience. The fixed JSON importer
    # rejects an object-valued padding option, so this same-byte slice does too.
    raw_padding = context.resolved_options.raw_values.get("org.eclipse.elk.padding")
    if raw_padding is not None and type(raw_padding) is not str:
        _outside("/layoutOptions/elk.padding", "E04 requires the reference-compatible padding string")
    if any(getattr(padding, side) > MAX_MEASURE for side in ("top", "right", "bottom", "left")):
        _outside("/layoutOptions/elk.padding", "Padding exceeds the E04 reviewed numeric domain")
    for key, value in context.original_arguments.items():
        if key in ("logging", "measureExecutionTime") and (type(value) is not bool or value):
            _outside("/layoutArguments/" + key, "Logging/timing is outside E04 acceptance")
        if key not in ("layoutOptions", "logging", "measureExecutionTime"):
            _outside("/layoutArguments/" + key, "Unknown call argument is not reviewed by E04")
    constructor = context.original_constructor
    if "algorithms" in constructor and constructor["algorithms"] != ["layered"]:
        _outside("/constructor/algorithms", "E04 only registers the reviewed layered slice")
    for key in constructor:
        if key not in ("defaultLayoutOptions", "algorithms"):
            _outside("/constructor/" + key, "Constructor capability is outside E04")
    nodes, edges = graph.get("children", []), graph.get("edges", [])
    if len(nodes) > MAX_NODES:
        _outside("/children", "E04 reviews at most four child nodes")
    for key in ("x", "y", "width", "height"):
        if key in graph:
            _outside("/" + key, "Pre-existing root geometry uses a separate source branch")
    if "logging" in graph:
        _outside("/logging", "Existing log cleanup is outside the E04 source slice")
    for owner, path in [(graph, ""), *[(node, "/children/" + str(i)) for i, node in enumerate(nodes)]]:
        if type(owner["id"]) is not str or not owner["id"]:
            _outside(pointer(path, "id"), "E04 requires nonempty string identities")
        if "$H" in owner:
            _outside(pointer(path, "$H"), "Existing reference identity-cache fields are outside E04")
        if "properties" in owner:
            _outside(pointer(path, "properties"), "Legacy option containers require a separate source branch")
        for key in ("ports", "labels"):
            if owner.get(key):
                _outside(pointer(path, key), "Explicit shape capability is outside E04")
        if path:
            for key in ("children", "edges", "layoutOptions"):
                if owner.get(key):
                    _outside(pointer(path, key), "Child-local capability is outside E04")
            for key in ("width", "height"):
                if key not in owner or owner[key] > MAX_MEASURE:
                    _outside(pointer(path, key), "Given dimensions must lie within the E04 reviewed domain")
            for key in ("x", "y"):
                if key in owner:
                    _outside(pointer(path, key), "Pre-existing node positions are outside E04")
    by_id = {node["id"] for node in nodes}
    outgoing, incoming = {}, {}
    for index, edge in enumerate(edges):
        path = "/edges/" + str(index)
        if type(edge["id"]) is not str or not edge["id"]:
            _outside(pointer(path, "id"), "E04 requires nonempty edge identities")
        if "properties" in edge:
            _outside(pointer(path, "properties"), "Legacy option containers are outside E04")
        for key in ("sections", "junctionPoints", "bendPoints", "startPoint", "endPoint", "sourcePoint", "targetPoint", "container"):
            if key in edge:
                _outside(pointer(path, key), "Pre-existing edge geometry requires a different source branch")
        for key in ("labels", "layoutOptions"):
            if edge.get(key):
                _outside(pointer(path, key), "Existing routing or edge-local capability is outside E04")
        sources, targets = edge["sources"], edge["targets"]
        if len(sources) != 1 or len(targets) != 1 or sources[0] not in by_id or targets[0] not in by_id:
            _outside(path, "E04 requires child-node single-source/target edges")
        source, target = sources[0], targets[0]
        if source == target or source in outgoing or target in incoming:
            _outside(path, "E04 requires a simple directed path")
        outgoing[source], incoming[target] = target, source
    if len(edges) != max(0, len(nodes) - 1):
        _outside("/edges", "E04 requires one connected path, or an empty graph")
    if nodes:
        starts = [identity for identity in by_id if identity not in incoming]
        if len(starts) != 1:
            _outside("/edges", "E04 excludes cycles and disconnected nodes")
        visited, current = set(), starts[0]
        while current not in visited:
            visited.add(current)
            if current not in outgoing:
                break
            current = outgoing[current]
        if visited != by_id:
            _outside("/edges", "E04 requires a connected acyclic path")
    return SliceAdmission(len(nodes), len(edges), options["org.eclipse.elk.direction"])
