# SPDX-License-Identifier: EPL-2.0 OR GPL-3.0-or-later
# Constrained mechanical port from elkjs 0.12.1 generated lib/elk-worker.js.
# Upstream commit: 624ae90aa37110033a8af59c5ccbb292708b4317
# Worker SHA256: 275e6caf4af71c06f5afd673939bdb4c9a0edf6ad97b32476cb7bc6cfdc09d86
# Source/branch map: references/e04-source-components-B.json
# Exact external Java build is unresolved. See pyelk/_licenses/NOTICE.md.
"""Source-reviewed kernels for a bounded directed path, never general layered.

The caller admits ADR0003 inputs and runs the real intervening processors.
These kernels also check their own structural and numeric preconditions.
Singleton-layer reductions preserve graph mutations and random consumption;
they do not dispatch on public IDs or read oracle/reference data.
"""
from collections import deque
import math

from ..._errors import UnsupportedFeatureError
from .graph import Layer, set_layer

_MASK48 = (1 << 48) - 1
_MULTIPLIER = 0x5DEECE66D
_P = "org.eclipse.elk."


def _signed(value, bits):
    value &= (1 << bits) - 1
    return value - (1 << bits) if value >= (1 << (bits - 1)) else value


class JavaRandom:
    """Seeded fixed generated java.util.Random, including its GWT arithmetic.

    This is the seeded constructor only; it does not implement the pipeline's
    seed-zero Date.now/uniqueSeed path. Diagnostics never determine geometry.
    """
    def __init__(self, seed):
        self._primitive_draws = 0
        self.set_seed(seed)

    @property
    def state48(self):
        return self._state

    @property
    def primitive_draws(self):
        return self._primitive_draws

    @property
    def seedhi(self):
        return self._state >> 24

    @property
    def seedlo(self):
        return self._state & 0xFFFFFF

    def set_seed(self, seed):
        if type(seed) is not int or not -(1 << 63) <= seed < (1 << 63):
            raise ValueError("A signed 64-bit seed is required")
        self._state = (seed ^ _MULTIPLIER) & _MASK48

    def next(self, bits):
        if type(bits) is not int or not 1 <= bits <= 32:
            raise ValueError("Primitive random width must be between 1 and 32")
        self._state = (self._state * _MULTIPLIER + 11) & _MASK48
        self._primitive_draws += 1
        value = self._state >> (48 - bits)
        return _signed(value, 32) if bits == 32 else value

    def next_int(self, bound):
        if type(bound) is not int or not 1 <= bound < (1 << 31):
            raise ValueError("A positive signed 32-bit bound is required")
        if (bound & -bound) == bound:
            return (bound * self.next(31)) >> 31
        while True:
            bits = self.next(31)
            value = bits % bound
            # Worker $nextInt uses JS number addition, with no int32 cast here.
            if bits - value + bound - 1 >= 0:
                return value

    def next_long(self):
        return _signed((self.next(32) << 32) + self.next(32), 64)

    def next_float(self):
        return self.next(24) * (2.0 ** -24)

    def next_double(self):
        return self.next(26) * (2.0 ** -26) + self.next(27) * (2.0 ** -53)


def _outside(message):
    raise UnsupportedFeatureError("UNSUPPORTED_PHASE_INPUT", "", message)


def _measure(value):
    try:
        return type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1_000_000
    except OverflowError:
        return False


def _zero(value):
    return type(value) in (int, float) and value == 0


def _path(graph, *, layered):
    """Validate adjacency independently of array order, return ordered path."""
    if layered:
        if graph.layerless_nodes or any(len(layer.nodes) != 1 for layer in graph.layers):
            _outside("This stage requires singleton layers and no layerless nodes")
        if any(layer.graph is not graph or layer.nodes[0].layer is not layer for layer in graph.layers):
            _outside("Layer/node membership is inconsistent")
        nodes = [layer.nodes[0] for layer in graph.layers]
    else:
        if graph.layers:
            _outside("This stage requires a layerless input")
        nodes = list(graph.layerless_nodes)
    if len(nodes) > 4 or len({id(node) for node in nodes}) != len(nodes):
        _outside("The reviewed phase slice has at most four distinct nodes")
    by_identity = {id(node): node for node in nodes}
    incoming, outgoing, edges = {node: [] for node in nodes}, {node: [] for node in nodes}, []
    seen_edges, seen_ports = set(), set()
    for node in nodes:
        if node.graph is not graph or node.type != "NORMAL" or not all(_measure(value) for value in (node.size.x, node.size.y)):
            _outside("Only normal nodes with bounded finite given dimensions are reviewed")
        if node.properties.get("LAYER_CONSTRAINT", "NONE") != "NONE" or node.properties.get("IN_LAYER_CONSTRAINT", "NONE") != "NONE":
            _outside("Non-default node constraints are outside this phase slice")
        for port in node.ports:
            if id(port) in seen_ports or port.owner is not node or port.origin is not None:
                _outside("Ports must be distinct implicit ports with correct owners")
            seen_ports.add(id(port))
            if any(len({id(edge) for edge in entries}) != len(entries) for entries in (port.incoming_edges, port.outgoing_edges)):
                _outside("Duplicate edge adjacency is outside the reviewed representation")
            for edge in port.outgoing_edges:
                if id(edge) in seen_edges or edge.source is not port or edge.target is None:
                    _outside("Outgoing adjacency is inconsistent")
                seen_edges.add(id(edge)); edges.append(edge)
                target = edge.target.owner
                if id(target) not in by_identity or edge not in edge.target.incoming_edges or edge.target not in target.ports:
                    _outside("Target adjacency is inconsistent")
                if target is node or edge.properties.get("REVERSED", False):
                    _outside("Self/reversed edges require a different source branch")
                if any(type(edge.properties.get(key, 0)) is not int or edge.properties.get(key, 0) != 0
                       for key in ("PRIORITY_DIRECTION", "PRIORITY_SHORTNESS", "PRIORITY_STRAIGHTNESS")):
                    _outside("Non-default priorities require a separate phase review")
                outgoing[node].append(edge); incoming[target].append(edge)
            for edge in port.incoming_edges:
                if edge.target is not port or edge.source is None or edge not in edge.source.outgoing_edges:
                    _outside("Incoming adjacency is inconsistent")
                if id(edge.source.owner) not in by_identity or edge.source not in edge.source.owner.ports:
                    _outside("Incoming source is outside the reviewed graph")
    if len(edges) != max(0, len(nodes) - 1) or any(len(incoming[node]) > 1 or len(outgoing[node]) > 1 for node in nodes):
        _outside("The reviewed topology is one directed path")
    if not nodes:
        return nodes, edges, incoming, outgoing
    starts = [node for node in nodes if not incoming[node]]
    if len(starts) != 1:
        _outside("A directed path needs one source")
    ordered, seen, current = [], set(), starts[0]
    while id(current) not in seen:
        ordered.append(current); seen.add(id(current))
        if not outgoing[current]:
            break
        current = outgoing[current][0].target.owner
    if len(ordered) != len(nodes) or (layered and ordered != nodes):
        _outside("All nodes must belong to the same forward layered path")
    return ordered, edges, incoming, outgoing


def _implicit_sides(nodes, *, centered=False):
    for node in nodes:
        if node.properties.get("PORT_CONSTRAINTS") not in ("FIXED_SIDE", "FIXED_ORDER"):
            _outside("The real side/sort processors must run before this stage")
        if node.port_sides_cached is not True:
            _outside("The real port-side range cache must be prepared")
        sides = set()
        for port in node.ports:
            if port.side not in ("EAST", "WEST") or port.side in sides:
                _outside("A path has at most one implicit port on each flow side")
            sides.add(port.side)
            if not all(_zero(value) for value in (port.size.x, port.size.y, port.anchor.x, port.anchor.y)):
                _outside("Only zero-size zero-anchor implicit ports are reviewed")
            if ((port.side == "EAST" and (len(port.outgoing_edges) != 1 or port.incoming_edges))
                    or (port.side == "WEST" and (len(port.incoming_edges) != 1 or port.outgoing_edges))):
                _outside("Implicit path ports must have their expected edge direction")
            if centered and (not _measure(port.pos.x) or not _measure(port.pos.y)
                             or port.pos.y != node.size.y / 2 or port.pos.x != (node.size.x if port.side == "EAST" else 0)):
                _outside("The reviewed placement branch needs centered side ports")
        for side in sides:
            indexes = [index for index, port in enumerate(node.ports) if port.side == side]
            if node.port_side_indices.get(side) != (indexes[0], indexes[-1] + 1):
                _outside("Cached implicit-port side ranges are inconsistent")


def _rng(graph):
    if not isinstance(graph.random, JavaRandom):
        _outside("A verified generated JavaRandom stream is required")
    return graph.random


def greedy_cycle_breaker(graph):
    """Worker $process_62/$updateNeighbors: real sink/source degree draining."""
    _, edges, incoming, outgoing = _path(graph, layered=False)
    nodes = list(graph.layerless_nodes)
    indegree, outdegree, marks = [], [], [0] * len(nodes)
    sinks, sources = deque(), deque()
    for index, node in enumerate(nodes):
        node.id = index
        indegree.append(len(incoming[node])); outdegree.append(len(outgoing[node]))
        if outdegree[index] == 0:
            sinks.append(node)
        elif indegree[index] == 0:
            sources.append(node)
    _rng(graph)  # Real source reads the stream, although this guarded DAG draws none.

    def update_neighbors(node):
        for port in node.ports:
            for edge in [*port.incoming_edges, *port.outgoing_edges]:
                connected = edge.target if edge.source is port else edge.source
                neighbor = connected.owner
                if neighbor is node or marks[neighbor.id] != 0:
                    continue
                if edge.target is connected:
                    indegree[neighbor.id] -= 1
                    if indegree[neighbor.id] <= 0 and outdegree[neighbor.id] > 0:
                        sources.append(neighbor)
                else:
                    outdegree[neighbor.id] -= 1
                    if outdegree[neighbor.id] <= 0 and indegree[neighbor.id] > 0:
                        sinks.append(neighbor)
    remaining, next_right, next_left = len(nodes), -1, 1
    while remaining:
        while sinks:
            node = sinks.popleft(); marks[node.id] = next_right; next_right -= 1
            update_neighbors(node); remaining -= 1
        while sources:
            node = sources.popleft(); marks[node.id] = next_left; next_left += 1
            update_neighbors(node); remaining -= 1
        if remaining:
            _outside("The random max-outflow cycle branch is outside the DAG slice")
    shift = len(nodes) + 1
    marks = [mark + shift if mark < 0 else mark for mark in marks]
    for edge in edges:
        if marks[edge.source.owner.id] > marks[edge.target.owner.id]:
            _outside("Path draining unexpectedly requested an edge reversal")


def network_simplex_layerer(graph):
    """Unit-path specialization of worker NetworkSimplex, with real ranking."""
    ordered, edges, incoming, outgoing = _path(graph, layered=False)
    if not ordered:  # The generated layerer has this actual early return.
        return
    original = list(graph.layerless_nodes)
    for index, node in enumerate(original):
        node.id = index
    # Preserve connectedComponentsDFS's port/connected-edge traversal order.
    component, visited = [], set()
    def visit(node):
        visited.add(node); component.append(node)
        for port in node.ports:
            for edge in [*port.incoming_edges, *port.outgoing_edges]:
                other = edge.target.owner if edge.source is port else edge.source.owner
                if other not in visited:
                    visit(other)
    visit(original[0])
    ranks = {node: 0 for node in component}
    incident = {node: len(incoming[node]) for node in component}
    sources = deque(node for node in component if incident[node] == 0)
    while sources:
        node = sources.popleft()
        for edge in outgoing[node]:
            target = edge.target.owner
            ranks[target] = max(ranks[target], ranks[node] + 1)
            incident[target] -= 1
            if incident[target] == 0:
                sources.append(target)
    # Every unit path edge is tight and belongs to its unique spanning tree.
    # The cut-value recurrence reduces to weight1 on every forward path edge;
    # hence leaveEdge has no negative-cut edge and the exchange loop is empty.
    if any(ranks[edge.target.owner] - ranks[edge.source.owner] != 1 for edge in edges):
        _outside("The unit-path feasible-tree proof does not apply")
    cutvalues = [1 for _ in edges]
    if any(value < 0 for value in cutvalues):
        _outside("The unreviewed network-simplex exchange branch was requested")
    minimum = min(ranks.values())
    ranks = {node: rank - minimum for node, rank in ranks.items()}
    filling = [0] * (max(ranks.values()) + 1)
    for rank in ranks.values():
        filling[rank] += 1
    # Source balance/minimalSpan: internal nodes have no feasible vacant rank;
    # source/sink degree imbalance excludes them, singleton can only stay at0.
    for node in component:
        if len(incoming[node]) == len(outgoing[node]):
            low = ranks[incoming[node][0].source.owner] + 1 if incoming[node] else 0
            high = ranks[outgoing[node][0].target.owner] - 1 if outgoing[node] else len(filling) - 1
            new_rank = ranks[node]
            for rank in range(low, high + 1):
                if filling[rank] < filling[new_rank]:
                    new_rank = rank
            if filling[new_rank] < filling[ranks[node]]:
                filling[ranks[node]] -= 1; filling[new_rank] += 1; ranks[node] = new_rank
    for node in component:
        while len(graph.layers) <= ranks[node]:
            graph.layers.append(Layer(graph))
        set_layer(node, graph.layers[ranks[node]])
    graph.layerless_nodes.clear()


def layer_sweep(graph, *, strategy):
    """Real singleton-layer ordering writes and source-ordered random draws."""
    if strategy not in ("BARYCENTER", "TWO_SIDED_GREEDY_SWITCH"):
        _outside("Unreviewed crossing-minimization strategy")
    nodes, _, _, _ = _path(graph, layered=True)
    if len(nodes) <= 1:
        return  # Worker $process_76 returns before initialize_5 on this branch.
    _implicit_sides(nodes)
    random = _rng(graph)
    saved_seed = random.next_long()  # initialize_5 before GraphInfoHolder.
    if strategy == "BARYCENTER":
        node_relative = random.next(1) != 0  # create_15 distributor choice.
    port_id = 0
    for layer_index, layer in enumerate(graph.layers):
        layer.id = layer_index
        for node_index, node in enumerate(layer.nodes):
            node.id = node_index
            for port in node.ports:
                port.id = port_id; port_id += 1
    current_order = [list(layer.nodes) for layer in graph.layers]
    port_orders = [[list(node.ports) for node in layer] for layer in current_order]
    if strategy == "BARYCENTER":
        random.set_seed(saved_seed)  # compareDifferentRandomizedLayouts reset.
        forward = random.next(1) != 0
        first = current_order[0 if forward else -1][0]
        first_weight = random.next_double()  # setFirstLayerOrder.
        barycenters = {first: {"degree": 1, "summedWeight": first_weight,
                               "barycenter": first_weight, "visited": False}}
        indexes = range(1, len(nodes)) if forward else range(len(nodes) - 2, -1, -1)
        for index in indexes:
            node = current_order[index][0]
            # One connected adjacent-layer port yields degree1. Its jitter is
            # still evaluated even though a singleton list cannot be reordered.
            port_rank = 0.5 if node_relative else 1.0
            weight = port_rank + (random.next_float() * 0.07000000029802322 - 0.03500000014901161)
            barycenters[node] = {"degree": 1, "summedWeight": weight,
                                 "barycenter": weight / 1, "visited": True}
        # The one-node-per-layer adjacent path has exactly zero crossings, so
        # compareDifferentRandomizedLayouts saves this first sweep and stops.
    else:
        forward = random.next(1) != 0
        indexes = range(len(nodes)) if forward else range(len(nodes) - 1, -1, -1)
        for index in indexes:
            # This is the actual adjacent-pair loop, with no pair in length1.
            for _ in range(len(current_order[index]) - 1):
                _outside("Greedy-switch pair evaluation needs a wider source slice")
    # transferNodeAndPortOrdersToGraph_0: restore copied order and fix constraints.
    for layer_index, layer in enumerate(graph.layers):
        layer.nodes[:] = current_order[layer_index]
        for node_index, node in enumerate(layer.nodes):
            node.id = node_index
            node.ports[:] = port_orders[layer_index][node_index]
            if node.properties["PORT_CONSTRAINTS"] != "FIXED_ORDER":
                node.properties["PORT_CONSTRAINTS"] = "FIXED_ORDER"


def bk_node_placer(graph):
    """Four actual alignment-block candidates reduced to the reviewed path."""
    nodes, edges, _, _ = _path(graph, layered=True)
    if not nodes:
        _outside("Empty graphs use the outer recursive-engine early return")
    _implicit_sides(nodes, centered=True)
    if graph.properties.get("NODE_PLACEMENT_FAVOR_STRAIGHT_EDGES") is not True or graph.properties.get("NODE_PLACEMENT_BK_FIXED_ALIGNMENT", "NONE") != "NONE":
        _outside("BK requires the reviewed ORTHOGONAL/fixed-alignment defaults")
    if graph.properties.get("GRAPH_PROPERTIES"):
        _outside("Advanced graph properties require a wider BK source slice")
    if any(not _zero(value) for node in nodes for value in (node.margin.top, node.margin.right, node.margin.bottom, node.margin.left)):
        _outside("The reviewed BK block has zero no-label margins")
    for layer_index, layer in enumerate(graph.layers):
        layer.id = layer_index
        layer.nodes[0].id = layer_index  # NeighborhoodInformation.buildFor.
    edge_by_pair = {(edge.source.owner, edge.target.owner): edge for edge in edges}
    candidates = []
    # Fixed worker candidate list is RIGHTDOWN, RIGHTUP, LEFTDOWN, LEFTUP.
    for horizontal in ("RIGHT", "LEFT"):
        for vertical in ("DOWN", "UP"):
            order = nodes if horizontal == "RIGHT" else list(reversed(nodes))
            root = order[0]
            inner = {root: 0.0}
            space_above, space_below = root.margin.top, root.size.y + root.margin.bottom
            for current, following in zip(order, order[1:]):
                edge = edge_by_pair[(current, following)] if horizontal == "RIGHT" else edge_by_pair[(following, current)]
                if horizontal == "LEFT":
                    difference = edge.target.pos.y + edge.target.anchor.y - edge.source.pos.y - edge.source.anchor.y
                else:
                    difference = edge.source.pos.y + edge.source.anchor.y - edge.target.pos.y - edge.target.anchor.y
                inner[following] = inner[current] + difference
                space_above = max(space_above, following.margin.top - inner[following])
                space_below = max(space_below, inner[following] + following.size.y + following.margin.bottom)
            for node in order:
                inner[node] += space_above
            # A single aligned block has no same-layer neighboring block/class
            # constraint: horizontalCompaction places its root at0 and copies
            # that block y to all members. layoutSize equals its blockSize.
            block_size = space_above + space_below
            feasible = all(math.isfinite(inner[node]) and math.isfinite(inner[node] + node.size.y) for node in nodes)
            if feasible:
                candidates.append((block_size, horizontal, vertical, inner))
    if not candidates:
        _outside("BK produced no feasible reviewed alignment")
    chosen = candidates[0]
    for candidate in candidates[1:]:
        if chosen[0] > candidate[0]:
            chosen = candidate
    for node in nodes:
        node.pos.y = 0.0 + chosen[3][node]


def orthogonal_edge_router(graph):
    """Source zero-slot single-segment branch, with its epsilon checked."""
    nodes, edges, _, _ = _path(graph, layered=True)
    _implicit_sides(nodes, centered=True)
    if any(not _zero(value) for node in nodes for value in (node.margin.top, node.margin.right, node.margin.bottom, node.margin.left)):
        _outside("The reviewed route has zero no-label margins")
    spacing = graph.options.values[_P + "layered.spacing.nodeNodeBetweenLayers"]
    if not _measure(spacing):
        _outside("Layer spacing exceeds the reviewed numeric domain")
    for layer, node in zip(graph.layers, nodes):
        # $process_84/placeNodesHorizontally read the singleton layer width.
        # They do not read its height. The preceding calculator obtains height
        # as (node.y + node.height + margin.bottom) - (node.y - margin.top),
        # which need not equal node.height in binary64 even for zero margins.
        if not _measure(layer.size.x) or layer.size.x != node.size.x:
            _outside("The real layer-size processor must prepare singleton widths")
        if type(node.pos.y) not in (int, float) or not math.isfinite(node.pos.y):
            _outside("Routing requires finite placed node coordinates")
    for edge in edges:
        if edge.bend_points:
            _outside("Existing bend points are outside the zero-slot route")
        source_y = edge.source.owner.pos.y + edge.source.pos.y + edge.source.anchor.y
        target_y = edge.target.owner.pos.y + edge.target.pos.y + edge.target.anchor.y
        if not math.isfinite(source_y) or not math.isfinite(target_y) or abs(source_y - target_y) >= 0.001:
            _outside("The general non-aligned orthogonal routing branch is not reviewed")
    # routeEdges_0's sole aligned segment creates no dependency pair, draws no
    # random value, adds no bends and returns rankCount(-1)+1 ==0 slots.
    xpos, left = 0.0, None
    for right in [*graph.layers, None]:
        if left is not None:
            left.nodes[0].pos.x = xpos
            xpos += left.size.x
        if left is not None and right is not None:
            xpos += spacing
        left = right
    graph.size.x = xpos
