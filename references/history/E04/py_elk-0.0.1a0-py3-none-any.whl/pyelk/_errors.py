"""Internal host validation errors; not the future public ELK error mapping."""


class ValidationError(ValueError):
    """A stable category and JSON Pointer identifying invalid host input."""

    def __init__(self, code: str, path: str, message: str):
        self.code = code
        self.path = path
        self.message = message
        super().__init__(f"{code} at {path or '/'}: {message}")


class ModelValidationError(ValidationError):
    """Invalid graph data or a structural mutation that would break its index."""


class OptionValidationError(ValidationError):
    """Invalid option containers, aliases or supported values."""


class UnknownOptionError(OptionValidationError):
    """An option identifier absent from the fixed reference catalogue."""


class UnsupportedOptionError(OptionValidationError):
    """A reference option known by name but not parsed by this slice."""


class UnsupportedFeatureError(ValidationError):
    """An explicitly supplied capability outside this native host slice."""
